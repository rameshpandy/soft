*-----------------------------------------------------------------------------
* <Rating>0</Rating>
*-----------------------------------------------------------------------------
* @desc
* @author Alin
* @create 20120731

    SUBROUTINE CHECK.OFS.ERR.RTN

    $INSERT I_COMMON
    $INSERT I_EQUATE

    ETEXT = "THIS BUTTON DOESN'T WORK :)"
    CALL STORE.END.ERROR

 
    RETURN
