* Version 1 13/04/00  GLOBUS Release No. 200508 30/06/05
*-----------------------------------------------------------------------------
* <Rating>0</Rating>
*-----------------------------------------------------------------------------
      SUBROUTINE TOOL.PERF.TABLE.CHECK
*-----------------------------------------------------------------------------
* Dror Traub 2017-01-13
*-----------------------------------------------------------------------------
$INSERT I_COMMON
$INSERT I_EQUATE
$INSERT I_BATCH.FILES

*-----------------------------------------------------------------------------
    OPEN 'F.TOOL.TEST.PERF.TABLE' TO F.TOOL.TEST.PERF.TABLE THEN
         EXECUTE 'CLEAR-FILE F.TOOL.TEST.PERF.TABLE'
    END ELSE
         EXECUTE 'CREATE-FILE F.TOOL.TEST.PERF.TABLE TYPE=XMLORACLE' CAPTURING tmpOut SETTING statVar
    END
    
	RETURN
	
   END
 
