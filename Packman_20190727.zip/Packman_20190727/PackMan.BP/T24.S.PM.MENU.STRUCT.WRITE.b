* Version 007 12/34/56  GLOBUS Release No. G1X.X.XX 29/06/00
*-----------------------------------------------------------------------------
* <Rating>-25</Rating>
*-----------------------------------------------------------------------------
*    $PACKAGE Tool_Packman
    
    SUBROUTINE T24.S.PM.MENU.STRUCT.WRITE(ID.HELPTEXT.MENU, DESC.HELPTEXT.MENU, DEPTH.HELPTEXT.MENU, TEXT.HELPTEXT.MENU, DL.DEFINE)
*===================================================================================
*===================================================================================
* Modification History :
* dd/mm/yyy    - CD_REFERENCE - author
*              Description of modification. 
*-----------------------------------------------------------------------------------
*   Date            who                      Reference            Description
* 07/09/2009   ssenthamil@temenos.com    ODR-2009-09-0006     Initial Version
*-----------------------------------------------------------------------------------
*===================================================================================
*
    $INSERT I_COMMON
    $INSERT I_ENQUIRY.COMMON
    $INSERT I_EQUATE
    $INSERT I_F.HELPTEXT.MENU
*
*===================================================================================
* 
    GOSUB INITIALISE

    IF ID.HELPTEXT.MENU NE '*' THEN
        GOSUB PROCESS
    END

    RETURN
*
*===================================================================================
*
PROCESS:
*
    TEXT.HELPTEXT.MENU := STR(CHAR(9),DEPTH.HELPTEXT.MENU):DESC.HELPTEXT.MENU:CHARX(9)

    M.HELPTEXT.MENU.ID = ID.HELPTEXT.MENU
    CALL F.READ(FN.HELPTEXT.MENU, M.HELPTEXT.MENU.ID, R.HELPTEXT.MENU, F.HELPTEXT.MENU, ETEXT)
    IF ETEXT THEN
        ETEXT = ''

        PA.CNT = DCOUNT(ID.HELPTEXT.MENU, ',')
        IF PA.CNT GT 1 THEN
            TEXT.HELPTEXT.MENU := FIELD(ID.HELPTEXT.MENU, ' ', 1):CHARX(9):'(Version)'
            DL.DEFINE := 'VERSION>':FIELD(ID.HELPTEXT.MENU, ' ', 1)
        END ELSE
            IF ID.HELPTEXT.MENU[1,4] EQ 'ENQ ' THEN
                TEXT.HELPTEXT.MENU := FIELD(ID.HELPTEXT.MENU, ' ', 2):CHARX(9):'(Enquiry)'
                DL.DEFINE := 'ENQUIRY>':FIELD(ID.HELPTEXT.MENU, ' ', 2)
            END ELSE
                TEXT.HELPTEXT.MENU := ID.HELPTEXT.MENU:CHARX(9):'(Application)'
            END
        END

        TEXT.HELPTEXT.MENU := FM
        DL.DEFINE := FM

    END ELSE
        TEXT.HELPTEXT.MENU := ID.HELPTEXT.MENU:CHARX(9):'(Menu)':FM
        DL.DEFINE := 'HELPTEXT.MENU>':ID.HELPTEXT.MENU:FM
        PA.CNT = DCOUNT(R.HELPTEXT.MENU<EB.MEN.APPLICATION>, VM)
        FOR PA.I = 1 TO PA.CNT
            CALL T24.S.PM.MENU.STRUCT.WRITE(R.HELPTEXT.MENU<EB.MEN.APPLICATION, PA.I>, R.HELPTEXT.MENU<EB.MEN.DESCRIPT, PA.I>, DEPTH.HELPTEXT.MENU+1, TEXT.HELPTEXT.MENU,DL.DEFINE)
        NEXT PA.I
    END
*
    RETURN
*
*===================================================================================
*
INITIALISE:
*
    F.HELPTEXT.MENU = ''
    FN.HELPTEXT.MENU = 'F.HELPTEXT.MENU'
    CALL OPF(FN.HELPTEXT.MENU, F.HELPTEXT.MENU)
*
    RETURN
*===================================================================================
END
