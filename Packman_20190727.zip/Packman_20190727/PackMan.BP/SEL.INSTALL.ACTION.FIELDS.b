*-----------------------------------------------------------------------------
* <Rating>55</Rating>
*-----------------------------------------------------------------------------
*    $PACKAGE Tool_Packman
    
    SUBROUTINE SEL.INSTALL.ACTION.FIELDS
***<region name=Description> 
***
* @author TM
* @date 17/01/2014
*
* Definition des champs de la table des actions a executer a l'installation avec PACK MAN.
***</region>
***<region name=changelog>
***
***</region>
***<region name=Header>
***<desc>Inserts and control logic</desc>
    $INSERT I_COMMON
    $INSERT I_EQUATE
***</region>

    GOSUB INITIALISE
    GOSUB PROCESS

    RETURN
***<region name=Initialisation>
***
INITIALISE:

    MAT F = "" ; MAT N = "" ; MAT T = "" ; ID.T = ""
    MAT CHECKFILE = "" ; MAT CONCATFILE = ""
    ID.CHECKFILE = "" ; ID.CONCATFILE = ""

    RETURN
***</region>
***<region name=Process>
***<desc>Definition des champs</desc>
PROCESS:

    ID.F = "CODE.ACTION"
    ID.N = "40.1"
    ID.T<1> = "ANY"
    ID.CHECKFILE = ""
    ID.CONCATFILE = ""

    Z = 0
    Z += 1 ; F(Z) = "DESCRIPTION"              ; N(Z) = "65.1"  ; T(Z) = "ANY"
    Z += 1 ; F(Z) = "POSITION"                 ; N(Z) = "4.1"   ; T(Z) = "" ; T(Z)<2> = "AVR1_R1R2_R2R3_APR3" ; T(Z)<11> = "Avant RESTORE1 (début)_Entre RESTORE1 et 2_Entre RESTORE2 et 3 (référentiel)_Après RESTORE3 (fin)"
    Z += 1 ; F(Z) = "TYPE.ACTION"              ; N(Z) = "4.1"   ; T(Z) = "" ; T(Z)<2> = "SH_RTN_SRV_OFS1_OFSF_EXTR" ; T(Z)<11> = "Shell (unix)_Routine (T24.LAUNCHER)_Service_1 OFS_Fichier OFS_Extraction"
    Z += 1 ; F(Z) = "PARAMETRE1"               ; N(Z) = "65.1"  ; T(Z) = "ANY"
    Z += 1 ; F(Z) = "XX.PARAMETRE2"            ; N(Z) = "65"    ; T(Z) = "ANY"
    Z += 1 ; F(Z) = "XX.PARAMETRE3"            ; N(Z) = "65"    ; T(Z) = "ANY"
    Z += 1 ; F(Z) = "XX.PARAMETRE4"            ; N(Z) = "65"    ; T(Z) = "ANY"
    Z += 1 ; F(Z) = "REEXECUTION"              ; N(Z) = "1"     ; T(Z) = "" ; T(Z)<2> = "Y"

    Z += 1 ; F(Z) = "XX<EXEC.USER"             ; N(Z) = "16"    ; T(Z) = "AA" ; T(Z)<3> = "NOINPUT"
    Z += 1 ; F(Z) = "XX-EXEC.CURR.NO"          ; N(Z) = "4"     ; T(Z) = "" ; T(Z)<3> = "NOINPUT"
    Z += 1 ; F(Z) = "XX-EXEC.DATE"             ; N(Z) = "11"    ; T(Z) = "D" ; T(Z)<3> = "NOINPUT"
    Z += 1 ; F(Z) = "XX-EXEC.TIME"             ; N(Z) = "8"     ; T(Z) = "TIME" ; T(Z)<2, 1> = "S" ; T(Z)<3> = "NOINPUT"
    Z += 1 ; F(Z) = "XX>EXEC.LOG"              ; N(Z) = "35"    ; T(Z) = "ANY" ; T(Z)<3> = "NOINPUT"

    Z += 1 ; F(Z) = "RESERVED5"                ; N(Z) = "35"    ; T(Z) = "" ; T(Z)<3> = "NOINPUT"
    Z += 1 ; F(Z) = "RESERVED4"                ; N(Z) = "35"    ; T(Z) = "" ; T(Z)<3> = "NOINPUT"
    Z += 1 ; F(Z) = "RESERVED3"                ; N(Z) = "35"    ; T(Z) = "" ; T(Z)<3> = "NOINPUT"
    Z += 1 ; F(Z) = "RESERVED2"                ; N(Z) = "35"    ; T(Z) = "" ; T(Z)<3> = "NOINPUT"
    Z += 1 ; F(Z) = "RESERVED1"                ; N(Z) = "35"    ; T(Z) = "" ; T(Z)<3> = "NOINPUT"

    Z += 1 ; F(Z) = "XX.OVERRIDE"              ; N(Z) = "35"    ; T(Z) = "A" ; T(Z)<3> = "NOINPUT"

    V = Z + 9

    RETURN
***</region>
