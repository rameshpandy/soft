*-----------------------------------------------------------------------------
* <Rating>-148</Rating>
*-----------------------------------------------------------------------------
    PROGRAM B.SET.SERVICES
*-----------------------------------------------------------------------------
*<doc>
*  table.
* @author = AF
* @date = 08/2018
* @jira =
*</doc>
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.TSA.SERVICE

*-----------------------------------------------------------------------------

    GOSUB INITIALISE
    IF W.ERR = '' THEN
        GOSUB PROCESS
    END 
        
    EXIT(RETURN.CODE)
    
********************************************************************************
INITIALISE:
********************************************************************************
* Open TSA.SERVICE table
    FN.TSA.SERVICE = 'F.TSA.SERVICE'
    F.TSA.SERVICE = ''
    CALL OPF(FN.TSA.SERVICE,F.TSA.SERVICE)

* Open LOCKING table
    FN.LOCKING = 'F.LOCKING'
    F.LOCKING = ''
    CALL OPF(FN.LOCKING,F.LOCKING)
	
	IF BATCH.DETAILS<3> THEN
		DO.ACTION = BATCH.DETAILS<3>
    END ELSE
        DO.ACTION=SENTENCE(1)
    END	
	
	CRT "ACTION=" :DO.ACTION
    RETURN.CODE = ''

*read the previous run 
    YERR = ''
    CALL F.READ(FN.LOCKING,"SAVE.SERVICE.STATE",TSA.SERVICE.LIST,F.TSA.SERVICE,YERR)
*   
    IF YERR = '' THEN
        IF TSA.SERVICE.LIST<1> NE "TOSTOP" THEN 
            IF TSA.SERVICE.LIST<1> NE "INITIAL" THEN 
                RETURN.CODE = 99
                W.ERR = "WRONG LOCKING>SAVE.SERVICE.STATE RECORD"
                CRT W.ERR
                RETURN
            END
        END
    END
 
    W.ERR = ''
    IF TSA.SERVICE.LIST<1> EQ DO.ACTION THEN
        RETURN.CODE = 99
        W.ERR = "YOU CANNOT RUN TWICE IN A RAW WITH THE SAME STATUS" 
        CRT W.ERR
    END
    
    RETURN
********************************************************************************
PROCESS:
********************************************************************************
    IF  DO.ACTION = "TOSTOP" THEN
        GOSUB SET.TO.STOP
    END ELSE
        IF  DO.ACTION = "INITIAL" THEN
            GOSUB SET.TO.INITIAL.STATE
        END ELSE
            RETURN.CODE = 99
            W.ERR = "WRONG STATUS"
            CRT W.ERR
       END
    END   

    RETURN

**********************************************************************************************************
SET.TO.STOP:
    TSA.SERVICE.LIST = ''
    TSA.SERVICE.LIST<-1> = 'TOSTOP'       
      
    SELECT.STATEMENT = 'SELECT ':FN.TSA.SERVICE : ' WITH SERVICE.CONTROL EQ "AUTO" OR SERVICE.CONTROL EQ "START"'
    SERVICE.LIST = ''
    LIST.NAME = ''
    SELECTED = ''
    SYSTEM.RETURN.CODE = ''
    CALL EB.READLIST(SELECT.STATEMENT,SERVICE.LIST,LIST.NAME,SELECTED,SYSTEM.RETURN.CODE)

    Y.TSA.COUNT = DCOUNT(SERVICE.LIST,@FM)
    FOR I=1 TO Y.TSA.COUNT

        Y.TSA.ID = SERVICE.LIST<I>
        IF Y.TSA.ID NE 'TSM' AND Y.TSA.ID NE 'OLTP' THEN
            R.TSA.SERVICE = ''
            YERR = ''
            CALL F.READ(FN.TSA.SERVICE,Y.TSA.ID,R.TSA.SERVICE,F.TSA.SERVICE,YERR)
            IF YERR = '' THEN
                TSA.SERVICE.LIST<-1> = Y.TSA.ID : @VM : R.TSA.SERVICE<TS.TSM.SERVICE.CONTROL>                
                R.TSA.SERVICE<TS.TSM.SERVICE.CONTROL> = "STOP"
                CALL F.WRITE(FN.TSA.SERVICE,Y.TSA.ID,R.TSA.SERVICE)
            END
        END
    NEXT I
   
    CALL F.WRITE(FN.LOCKING,"SAVE.SERVICE.STATE",TSA.SERVICE.LIST)
    CALL JOURNAL.UPDATE('')
RETURN


**********************************************************************************************************
SET.TO.INITIAL.STATE:
    TSA.SERVICE.LIST = ''
    CALL F.READ(FN.LOCKING,"SAVE.SERVICE.STATE",TSA.SERVICE.LIST,F.LOCKING,YERR)
   
    Y.TSA.COUNT = DCOUNT(TSA.SERVICE.LIST,@FM)
    FOR I=2 TO Y.TSA.COUNT

        Y.TSA.ID = TSA.SERVICE.LIST<I,1>
        R.TSA.SERVICE = ''
        YERR = ''
        CALL F.READ(FN.TSA.SERVICE,Y.TSA.ID,R.TSA.SERVICE,F.TSA.SERVICE,YERR)
                                
        R.TSA.SERVICE<TS.TSM.SERVICE.CONTROL> = TSA.SERVICE.LIST<I,2>
        CALL F.WRITE(FN.TSA.SERVICE,Y.TSA.ID,R.TSA.SERVICE)
    NEXT I
  
    TSA.SERVICE.LIST<1> = 'INITIAL'  
    CALL F.WRITE(FN.LOCKING,"SAVE.SERVICE.STATE",TSA.SERVICE.LIST)   
    CALL JOURNAL.UPDATE('')

RETURN

END

