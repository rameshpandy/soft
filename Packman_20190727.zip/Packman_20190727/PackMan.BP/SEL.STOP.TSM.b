*----------------------------------------------------------
* <Rating>-5</Rating>
*----------------------------------------------------------
    PROGRAM SEL.STOP.TSM
***<region name=Description>
***
* Arrete le TSM et les agents.
***</region>
***<region name=changelog>
***
* Modifications :
*   22/05/2014, TM :
*     Lecture de delai d'attente dans TSA.PARAMETER.
*     Ajout de l'arret des agents.
***</region>
    $INSERT I_COMMON
    $INSERT I_EQUATE

    $INSERT I_F.TSA.SERVICE
    $INSERT I_F.TSA.STATUS
    $INSERT I_F.TSA.PARAMETER

    GOSUB INITIALISE
    GOSUB PROCESS.STOP.SERVICE

    EXIT (0)
***<region name=Initialise>
***
INITIALISE:

    F.TSA.SERVICE = ""
    OPEN "F.TSA.SERVICE" TO F.TSA.SERVICE ELSE
        PRINT "F.TSA.SERVICE : Not found ..."
        EXIT (2)
    END

    F.TSA.STATUS = ""
    OPEN "F.TSA.STATUS" TO F.TSA.STATUS ELSE
        PRINT "F.TSA.STATUS : Not found ..."
        EXIT (2)
    END

    F.TSA.PARAMETER = ''
    OPEN 'F.TSA.PARAMETER' TO F.TSA.PARAMETER ELSE
        PRINT 'F.TSA.PARAMETER : Not found ...'
        EXIT (2)
    END

    PAUSE.SERVICE = ""
    DEATH.WATCH = ""
    READ R.TSA.PARAMETER FROM F.TSA.PARAMETER, "SYSTEM" THEN
        PAUSE.SERVICE = R.TSA.PARAMETER<TS.PARM.REVIEW.TIME>
        DEATH.WATCH = R.TSA.PARAMETER<TS.PARM.DEATH.WATCH>
    END
    IF NOT(PAUSE.SERVICE) THEN
        PAUSE.SERVICE = 60
    END
    IF NOT(DEATH.WATCH) THEN
        DEATH.WATCH = 900
    END

    LIST.TSA = ''

    RETURN
***</region>
***<region name=Process stop service>
***
PROCESS.STOP.SERVICE:

    PRINT OCONV(TIME(),"MTS"):" TSM Service En cours d'arret"

* Arret du service TSM si besoin
    ID.SERVICE = 'TSM'
    READU R.SERVICE FROM F.TSA.SERVICE, ID.SERVICE THEN
        IF R.SERVICE<TS.TSM.SERVICE.CONTROL> = "START" THEN
            R.SERVICE<TS.TSM.SERVICE.CONTROL> = "STOP"
            WRITE R.SERVICE ON F.TSA.SERVICE, ID.SERVICE
* Le temps qu'il prenne en compte l'arret
            SLEEP PAUSE.SERVICE + 10
        END ELSE
            RELEASE F.TSA.SERVICE, ID.SERVICE
        END
    END ELSE
        RELEASE F.TSA.SERVICE, ID.SERVICE
    END

    GOSUB CHECK.RUNNING
    IF SERVICE.DEMARRE THEN
* Le temps qu'il s'arrete
        SLEEP PAUSE.SERVICE + 10
        GOSUB CHECK.RUNNING
        IF SERVICE.DEMARRE THEN
            GOSUB LOGOFF.SERVICE
        END
    END
    PRINT OCONV(TIME(),"MTS"):" Service TSM a l'arret"

* Arret des services encore en cours
    GOSUB CTRL.SERVICES.ENCOURS
    IF LIST.SERVICE THEN
        PRINT OCONV(TIME(),"MTS"):" Services encore en cours " : CHANGE(LIST.SERVICE, FM, ", ")
* On attend DEATH.WATCH que les services s'arretent
        PAUSE.MAXI = DEATH.WATCH
        LOOP
            TEMPS.PAUSE = PAUSE.SERVICE
            IF TEMPS.PAUSE > PAUSE.MAXI THEN
                TEMPS.PAUSE = PAUSE.MAXI
            END
            SLEEP TEMPS.PAUSE
            PAUSE.MAXI -= TEMPS.PAUSE
            GOSUB CTRL.SERVICES.ENCOURS
* On controle pour chaque service que les tSA existent toujours
            RESTE.SERVICE = 0
            LOOP
                REMOVE ID.SERVICE FROM LIST.SERVICE SETTING POS.SEL
            WHILE ID.SERVICE : POS.SEL DO
                GOSUB CHECK.RUNNING
                IF SERVICE.DEMARRE THEN
                    RESTE.SERVICE = 1
                END
            REPEAT
        WHILE RESTE.SERVICE AND PAUSE.MAXI > 0 DO
        REPEAT
* S'il reste des services en cours on force leur arret
        LOOP
            REMOVE ID.SERVICE FROM LIST.SERVICE SETTING POS.SEL
        WHILE ID.SERVICE : POS.SEL DO
            GOSUB CHECK.RUNNING
            IF SERVICE.DEMARRE THEN
                GOSUB LOGOFF.SERVICE
            END
        REPEAT

        PRINT OCONV(TIME(),"MTS"):" Tous les services sont arretes"
    END

    CMD.SEL = 'SSELECT F.TSA.STATUS WITH AGENT LIKE 1N0N AND AGENT.STATUS # "RUNNING"'
    EXECUTE CMD.SEL CAPTURING RIEN
    IF @SELECTED THEN
        PRINT OCONV(TIME(),"MTS"):" Nettoyage de F.TSA.STATUS"
        EXECUTE "DELETE F.TSA.STATUS" CAPTURING RIEN
    END

    RETURN
***<region name=Check running>
***
CHECK.RUNNING:

    SERVICE.DEMARRE = 0
    LIST.TSA = ""

    CMD.CTRL = 'SSELECT F.TSA.STATUS WITH AGENT LIKE 1N0N AND (CURRENT.SERVICE = "' : ID.SERVICE : '" OR NEXT.SERVICE = "' : ID.SERVICE : '") AND AGENT.STATUS = "RUNNING"'

    NUM.PROCESS = ""
    SLCT.NB = ""
    LIST.OF.ID = ""
    CALL EB.READLIST (CMD.CTRL, LIST.OF.ID, LST.NAME, NUM.PROCESS, SLCT.NB)
    IF LIST.OF.ID THEN
        LOOP
            REMOVE REC.ID FROM LIST.OF.ID SETTING RECDELIM
        WHILE REC.ID:RECDELIM
            READU R.REC FROM F.TSA.STATUS,REC.ID THEN
                PORT.NO = R.REC<TS.TSS.PORT.ID>
                GOSUB CTRL.AGENT
                IF AGENT.EXISTE THEN
                    IF LIST.TSA THEN LIST.TSA := FM
                    LIST.TSA := REC.ID
                    RELEASE F.TSA.STATUS, REC.ID
                    SERVICE.DEMARRE = 1
                END ELSE
                    DELETE F.TSA.STATUS, REC.ID
                END
            END ELSE
                RELEASE F.TSA.STATUS, REC.ID
            END
        REPEAT
        PRINT OCONV(TIME(), "MTS") : " TSM Service " : ID.SERVICE : " Toujours Running " : CHANGE(LIST.TSA, FM, ", ")
    END

    RETURN
***</region>
***<region name=Ctrl agent>
***
CTRL.AGENT:

    AGENT.EXISTE = 0
    IF PORT.NO THEN
        CAPT.WHERE = ''
        CMD = "WHERE " : PORT.NO : " (V"
        EXECUTE CMD CAPTURING CAPT.WHERE
        IF INDEX(CAPT.WHERE, 'User not logged on', 1) THEN
            PRINT OCONV(TIME(), "MTS") : " Avertissement - Port TSA.STATUS " : ID.SERVICE : " hors service : " : PORT.NO
        END ELSE
            CAPT.TSM = 'tSA ':REC.ID
            IF INDEX(CAPT.WHERE, CAPT.TSM, 1) THEN
                AGENT.EXISTE = 1
            END ELSE
                PRINT OCONV(TIME(), "MTS"):" Avertissement - Port TSA.STATUS " : ID.SERVICE:" n'est pas le tSA : " : PORT.NO
            END
        END
    END

    RETURN
***</region>
***<region name=Logoff service>
***
LOGOFF.SERVICE:

    IF LIST.TSA THEN
        PRINT OCONV(TIME(),"MTS"):" Arret force du service " : ID.SERVICE
        LOOP
            REMOVE REC.ID FROM LIST.TSA SETTING RECDELIM
        WHILE REC.ID:RECDELIM
            READU R.REC FROM F.TSA.STATUS, REC.ID THEN
                PORT.NO = R.REC<TS.TSS.PORT.ID>
                GOSUB CTRL.AGENT
                IF AGENT.EXISTE THEN
                    CMD.LOGOFF = "LOGOFF " : PORT.NO
                    PRINT OCONV(TIME(), "MTS") : " " : PORT.NO
                    EXECUTE CMD.LOGOFF CAPTURING RIEN
                    GOSUB CTRL.AGENT
                    IF AGENT.EXISTE THEN
                        PRINT OCONV(TIME(), "MTS") : " ERREUR : Impossible d'arreter l'agent " : REC.ID : " port " : PORT.NO
                        EXIT (1)
                    END
                    DELETE F.TSA.STATUS, REC.ID
                END ELSE
                    RELEASE F.TSA.STATUS, REC.ID
                END
            END
        REPEAT
    END

    RETURN
***</region>
***<region name=Ctrl services encours>
***
CTRL.SERVICES.ENCOURS:

    CMD.CTRL = 'SELECT F.TSA.STATUS WITH AGENT LIKE 1N0N AND AGENT.STATUS = "RUNNING" SAVING UNIQUE CURRENT.SERVICE NEXT.SERVICE'
    SEL.NB = ""
    NOM.LISTE = ""
    LIST.SERVICE = ""
    CALL EB.READLIST (CMD.CTRL, LIST.SERVICE, NOM.LISTE, SEL.NB, ERR.MSG)
* On supprime les valeurs vide et STOP
    LOCATE "" IN LIST.SERVICE<1> SETTING  POS.SERV THEN
        DEL LIST.SERVICE<POS.SERV>
    END
    LOCATE "STOP" IN LIST.SERVICE<1> SETTING  POS.SERV THEN
        DEL LIST.SERVICE<POS.SERV>
    END

    RETURN
***</region>
***</region>
