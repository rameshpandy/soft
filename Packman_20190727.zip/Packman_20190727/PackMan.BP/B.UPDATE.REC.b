*-----------------------------------------------------------------------------
* <Rating>-148</Rating>
*-----------------------------------------------------------------------------
    PROGRAM B.UPDATE.REC
*-----------------------------------------------------------------------------
*<doc>
*  table.
* @author = AF
* @date = 08/2018
* @jira =
*</doc>
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.TSA.SERVICE

*-----------------------------------------------------------------------------

    GOSUB INITIALISE
    IF W.CONTINUE = 'Y' THEN    
        GOSUB PROCESS
    END
    RETURN
    
********************************************************************************
INITIALISE:
********************************************************************************
    W.CONTINUE = 'Y'
   
* Open table
    FN.TABLE = SENTENCE(1)
    F.TABLE = ''
    CALL OPF(FN.TABLE,F.TABLE)

    W.ID = SENTENCE(2)
    IF W.ID EQ '' THEN
        CRT "ID IS MANDATORY"
        W.CONTINUE = 'N'
    END
   
    W.FIELD.NB = SENTENCE(3)
    IF W.FIELD.NB EQ '' THEN
        CRT "FIELD NUMBER IS MANDATORY"
        W.CONTINUE = 'N'
    END
    
    IF NUM(W.FIELD.NB) ELSE
        CRT "INPUT PARAM FOR FIELD.NR NOT NUMERIC"
        W.CONTINUE = 'N'
    END
	
    W.FM.POS = W.FIELD.NB
    W.VM.POS = 1
    IF INDEX(W.FIELD.NB,'.',1) THEN
       W.FM.POS=FIELD(W.FIELD.NB,'.',1)
       W.VM.POS=FIELD(W.FIELD.NB,'.',2)
    END

    W.FIELD.VALUE = SENTENCE(4)
    
    
    RETURN
********************************************************************************
PROCESS:
********************************************************************************
    R.REC = ''
    YERR = ''
    CALL F.READ(FN.TABLE,W.ID,R.REC,F.TABLE,YERR)

     R.REC<W.FM.POS,W.VM.POS> = W.FIELD.VALUE
   
    CALL F.WRITE(FN.TABLE,W.ID,R.REC)
    CALL JOURNAL.UPDATE('')

END


