*-----------------------------------------------------------------------------
* <Rating>-27</Rating>
*-----------------------------------------------------------------------------
*    $PACKAGE Tool_Packman

    SUBROUTINE SEL.INSTALL.ACTION
***<region name=Description>
***
* @author TM
* @date 17/01/2014
*
* Actions a executer a l'installation avec PACK MAN.
***</region>
***<region name=changelog>
***
* Modifications :
***</region>
    $INSERT I_COMMON
    $INSERT I_EQUATE

    $INSERT I_METHODS.AND.PROPERTIES

    C_METHODS = ''
    C_PROPERTIES = ''

***<region name=Definition table>
***
    C_PROPERTIES<P_NAME> = 'SEL.INSTALL.ACTION'                   ;* Full application name including product prefix
    C_PROPERTIES<P_TITLE> = 'Actions a executer a l installation' ;* Screen title
    C_PROPERTIES<P_STEREOTYPE> = 'H'                              ;* H, U, L, W or T
    C_PROPERTIES<P_PRODUCT> = 'EB'                                ;* Must be on EB.PRODUCT
    C_PROPERTIES<P_SUB.PRODUCT> = ''                              ;* Must be on EB.SUB.PRODUCT
    C_PROPERTIES<P_CLASSIFICATION> = 'INT'                        ;* As per FILE.CONTROL
    C_PROPERTIES<P_SYS.CLEAR.FILE> = ''                           ;* As per FILE.CONTROL
    C_PROPERTIES<P_RELATED.FILES> = ''                            ;* As per FILE.CONTROL
    C_PROPERTIES<P_PC.FILE> = ''                                  ;* As per FILE.CONTROL
    C_PROPERTIES<P_EQUATE.PREFIX> = 'SEL.INST.ACTION'             ;* Use to create I_F.XX.TABLE

    C_PROPERTIES<P_ID.PREFIX> = ''                                ;* Used by EB.FORMAT.ID if set
    C_PROPERTIES<P_BLOCKED.FUNCTIONS> = ''                        ;* Space delimeted list of blocked functions ; * TM_140108
    C_PROPERTIES<P_TRIGGER> = ''                                  ;* Trigger field used for OPERATION style fields

    C_METHODS<M_INITIALISE> = ''                                  ;* Use this to load a common area
    C_METHODS<M_ID> = ''                                          ;* Check ID ; * TM_140108
    C_METHODS<M_RECORD> = ''                                      ;* Check Record
    C_METHODS<M_VALIDATE> = 'Y'                                   ;* Cross validation ; * TM_140108
    C_METHODS<M_OVERRIDES> = ''                                   ;* Overrides
    C_METHODS<M_FUNCTION> = ''                                    ;* Check Function
    C_METHODS<M_PREVIEW> = ''                                     ;* Delivery Preview
    C_METHODS<M_PROCESS> = ''                                     ;* The main processing routine
    C_METHODS<M_AUTHORISE> = ''                                   ;* Any work that needs to be done at authorisation
    C_METHODS<M_DEFAULT> = ''                                     ;* Any defaulting

    CALL THE.TEMPLATE

    RETURN
***</region>
