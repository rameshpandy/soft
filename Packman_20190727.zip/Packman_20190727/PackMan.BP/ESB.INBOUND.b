*-----------------------------------------------------------------------------
* <Rating>336</Rating>
*-----------------------------------------------------------------------------
    PROGRAM ESB.INBOUND
*
    $INSERT I_COMMON
    $INSERT I_IF.INTEGRATION.SERVICE


    GOSUB GET.DATE.TIME
************************************************************************
* T24 OFS Source Configuration
************************************************************************
    OFSSource = "GCS"
		
    IF GETENV("OFS_SOURCE") = "" THEN
	IF PUTENV("OFS_SOURCE=":OFSSource) THEN
           CRT W.ACTUAL.DATETIME : "OFS_SOURCE defaulted to '":OFSSource:"'"
	END
    END


    CALL JF.INITIALISE.CONNECTION ;* INITIALIZE T24 Session


************************************************************************
    W.JUST.ONCE="Y"    

    LOOP
    WHILE 1

        SEL.CMD = 'SELECT F.IF.EVENTS.INTERFACE.TABLE WITH EVENT.TYPE LIKE T24... AND EVENT.TIMESTAMP EQ ""'
        CALL EB.READLIST(SEL.CMD, SEL.ID, '', NO.SELECTED, SEL.ERR)

        GOSUB GET.DATE.TIME
*
        IF NO.SELECTED THEN
*
            CRT W.ACTUAL.DATETIME : "SELECTED : ":NO.SELECTED:" ":SEL.ERR

            IF W.JUST.ONCE = "Y" THEN 
                W.JUST.ONCE = ""
                FN.IF.EVENTS.INTERFACE.TABLE = 'F.IF.EVENTS.INTERFACE.TABLE'
                F.IF.EVENTS.INTERFACE.TABLE = ''
                CALL OPF(FN.IF.EVENTS.INTERFACE.TABLE, F.IF.EVENTS.INTERFACE.TABLE)
            *
                EventBatchSize = 1
                MessageDeliveryMode = 'NO.BATCH'
                MessageBatchXml = 'YES'

                ctxenv<-1> = "MQSeries"
                ctxenv<-1> = "NTAS102083T14"
                ctxenv<-1> = "1414"
                ctxenv<-1> = "TST.LDBSRV1"
                ctxenv<-1> = "CLI.LDB_2"
                ctxenv<-1> = "mquser"
                ctxenv<-1> = "123"
                requestQueue="DEV.Z6.LDB.T242LDB_RESPONSE.R.Z6"



*SET "JAVA_OPTS=%JAVA_OPTS% -DmqESBHostName=NTAS102083T14"
*SET "JAVA_OPTS=%JAVA_OPTS% -DmqESBPort=1414"
*SET "JAVA_OPTS=%JAVA_OPTS% -DmqESBUser=mquser"
*SET "JAVA_OPTS=%JAVA_OPTS% -DmqESBPassword=123"
*SET "JAVA_OPTS=%JAVA_OPTS% -DmqESBChannel=CLI.LDB_2"
*SET "JAVA_OPTS=%JAVA_OPTS% -DmqESBQManager=TST.LDBSRV1"


                CONNECTION = JMSGETCONNECTION(ctxenv)
                CONTEXT = CONNECTION
                CRT W.ACTUAL.DATETIME : "MQ CONN STATUS:": CONNECTION<1>
                SESSION = JMSGETSESSION(CONTEXT, connectionFactory)
                CRT W.ACTUAL.DATETIME : "MQ SESSION:":SESSION
                QUEUEPost = JMSGETQUEUE(SESSION, requestQueue, 1)
                CRT W.ACTUAL.DATETIME : "MQ QUEUE:":QUEUEPost<1>
            END
            *
            FOR I = 1 TO NO.SELECTED
                CRT W.ACTUAL.DATETIME : "EVENT: ":SEL.ID<I>
                EVENT.ID = SEL.ID<I>
                CALL F.READU(FN.IF.EVENTS.INTERFACE.TABLE, EVENT.ID, R.EVENT, F.IF.EVENTS.INTERFACE.TABLE, EVENT.ERR, "")

                FLOW.ID = R.EVENT<2>
                CRT W.ACTUAL.DATETIME : 'FLOW: ':FLOW.ID
                R.FLOW = ''
                CALL CACHE.READ('F.IF.INTEGRATION.FLOW.CATALOG', FLOW.ID, R.FLOW, FLOW.ERR)
                FLOWATTR = R.FLOW<4>
                CRT W.ACTUAL.DATETIME : 'FLOWATTR: ':FLOWATTR:' ERROR: ':FLOW.ERR
                CALL IF.INTEGRATION.TRANSFORM.HANDLER(EVENT.ID, R.EVENT, R.NEWEVENT, HANDL.ERR)
                CRT W.ACTUAL.DATETIME : 'HANDLER: ':HANDL.ERR
                EVENTS = ''
                EVENTS<1> = R.NEWEVENT<1>

                CALL IF.INTEGRATION.SERVICE.PACKAGER(FLOW.ID, FLOWATTR, EVENTS, EVENTXML)
*TAKE OUT THE xmlns:xmlns tag
                CHANGE 'xmlns:xmlns="http://www.w3.org/2000/xmlns/" ' TO "" IN EVENTXML

                CRT W.ACTUAL.DATETIME : "XML: ":EVENTXML
                SUCCESS = JMSPOST(QUEUEPost, EVENTXML, CORRID)
                CRT W.ACTUAL.DATETIME : 'MQPOST: ':SUCCESS
                IF SUCCESS THEN
                    R.EVENT<3> = TIMESTAMP()
                    R.EVENT<1> = EVENTXML
                    CRT W.ACTUAL.DATETIME : 'TIMESTAMP for ':EVENT.ID:' is ':R.EVENT<3>
                    CALL F.WRITE(FN.IF.EVENTS.INTERFACE.TABLE, EVENT.ID, R.EVENT)
                    CALL JOURNAL.UPDATE(EVENT.ID)
                END

            NEXT I
        END ELSE
            CRT W.ACTUAL.DATETIME : "no records selected :":NO.SELECTED
        END

        SLEEP 5
    REPEAT

    RETURN


*****************************************************
GET.DATE.TIME:
*****************************************************
    DATETIME = OCONV(DATE(),"D-")
*    DATETIME = DATETIME[7,4]:DATETIME[1,2]:DATETIME[4,2]
    YTIME = OCONV(TIME(),'MT')
    DATETIME := " " : YTIME[1,2] : ":" : YTIME[4,2]

    W.ACTUAL.DATETIME = "[" : DATETIME : "]"
    RETURN
