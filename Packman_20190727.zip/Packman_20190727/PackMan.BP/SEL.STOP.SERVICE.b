*----------------------------------------------------------
* <Rating>1312</Rating>
*----------------------------------------------------------
    PROGRAM SEL.STOP.SERVICE

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.SPF
    $INSERT I_F.JOB.TIMES
    $INSERT I_F.BATCH
    $INSERT I_F.TSA.SERVICE
    $INSERT I_F.TSA.STATUS
    $INSERT I_F.TSA.PARAMETER
    $INSERT I_F.COMPANY
    $INSERT I_F.EB.EOD.ERROR
    $INSERT I_F.BATCH
    $INSERT I_F.PGM.FILE
    $INSERT I_F.DATES
    $INSERT I_F.SEL.SCHEDULE

    GOSUB INITIALISE
    GOSUB PROCESS.STOP.SERVICE
    GOSUB WRITE.COMO

    RETURN

**********
INITIALISE:
**********

    F.TSA.SERVICE = ""
    OPEN "F.TSA.SERVICE" TO F.TSA.SERVICE ELSE
        PRINT "F.TSA.SERVICE : Not found ..."
        GOSUB FATAL.ERROR99
    END

    F.TSA.STATUS = ""
    OPEN "F.TSA.STATUS" TO F.TSA.STATUS ELSE
        PRINT "F.TSA.STATUS : Not found ..."
        GOSUB FATAL.ERROR99
    END

    F.TSA.PARAMETER = ''
    OPEN 'F.TSA.PARAMETER' TO F.TSA.PARAMETER ELSE
        PRINT 'F.TSA.PARAMETER : Not found ...'
        GOSUB FATAL.ERROR99
    END

    F.BATCH = ''
    OPEN 'F.BATCH' TO F.BATCH ELSE
        PRINT 'F.BATCH : Not found...'
    END

    F.PGM.FILE = ''
    OPEN 'F.PGM.FILE' TO F.PGM.FILE ELSE
        PRINT 'F.PGM.FILE : Not found...'
    END

    OPEN "&COMO&" TO F.COMO ELSE
        PRINT '&COMO& : Not found ...'
        GOSUB FATAL.ERROR99
    END

    F.SEL.SCHEDULE = ''
    OPEN "F.SEL.SCHEDULE" TO F.SEL.SCHEDULE ELSE
        PRINT 'F.SEL.SCHEDULE : Not found ...'
        GOSUB FATAL.ERROR99
    END


    STR.CODE = 0

    PAUSE.SERVICE = 60

    CMD="whoami"
* CMD ="WHO"
    EXECUTE CMD RTNLIST LIST.WHO CAPTURING CAPT.WHO
* STR.CURRENT.ENV=FIELD(CAPT.WHO,' ',2)
    STR.CURRENT.ENV = TRIM(CAPT.WHO)

    LIST.SERVICE = ''
    LIST.TSA = ''

    R.LIST.SERVICE = ''
    SCH.KEY = ''
    COMMAND.LINE.ARGUMENT = TRIM(@SENTENCE, SPACE(1), 'R')
    COMMAND.LINE.ARGUMENT = TRIM(FIELD(COMMAND.LINE.ARGUMENT,' ',2))


    SCH.KEY = COMMAND.LINE.ARGUMENT
    READ R.LIST.SERVICE FROM F.SEL.SCHEDULE,SCH.KEY ELSE NULL
    IF R.LIST.SERVICE = '' THEN
        PRINT ' Argument ':COMMAND.LINE.ARGUMENT:' Not Valid....'
        PRINT ' No Record Found to process...'
        GOSUB FATAL.ERROR99
    END


    RETURN

*********************
PROCESS.STOP.SERVICE:
*********************
    PRINT OCONV(TIME(),"MTS"):" Tsa Service En cours d'arret "
    LIST.SERVICE.TEMP = ''
    LIST.SERVICE = ''
    LIST.SERVICE.TEMP = R.LIST.SERVICE<SEL.SCH.TSA.SERVICE>
    CONVERT @VM TO @FM IN LIST.SERVICE.TEMP

    TEMPS.PAUSE = PAUSE.SERVICE + 10
    LOOP
        LISTE.SERVICE = ''
        SERVICE.DEMARRE = 0
        NB.ARRET = 0
        NB.FM = 1
        NB.FM = DCOUNT(LIST.SERVICE.TEMP,@FM)
        FOR I = 1 TO NB.FM
            KEY.SERVICE = LIST.SERVICE.TEMP<I>
            READ R.KEY.SERVICE FROM F.TSA.SERVICE,KEY.SERVICE ELSE NULL
            IF R.KEY.SERVICE THEN
                IF R.KEY.SERVICE<TS.TSM.SERVICE.CONTROL> # 'STOP' AND R.KEY.SERVICE<TS.TSM.SERVICE.CONTROL> # '' AND KEY.SERVICE # 'COB' AND KEY.SERVICE # 'OLTP' THEN
                    NB.ARRET +=1
                    IF LISTE.SERVICE = '' THEN
                        LISTE.SERVICE = KEY.SERVICE
                    END ELSE
                        LISTE.SERVICE :=@FM:KEY.SERVICE
                    END
                END
            END
        NEXT I

        LIST.SERVICE.TEMP = LISTE.SERVICE

        IF NB.ARRET THEN
            LOOP
                REMOVE ID.SERVICE FROM LISTE.SERVICE SETTING POS.SERVICE
            UNTIL ID.SERVICE = "" AND NOT(POS.SERVICE) DO
                READU R.SERVICE FROM F.TSA.SERVICE, ID.SERVICE THEN
                    IF R.SERVICE<TS.TSM.SERVICE.CONTROL> = "AUTO" THEN
                        R.SERVICE<TS.TSM.SERVICE.CONTROL> = "START"
                        WRITE R.SERVICE ON F.TSA.SERVICE, ID.SERVICE
                        SERVICE.DEMARRE = 1
                    END ELSE
                        GOSUB CHECK.BATCH
                        IF R.SERVICE<TS.TSM.SERVICE.CONTROL> # "STOP" AND PRO.SERVICE = @TRUE THEN
                            R.SERVICE<TS.TSM.SERVICE.CONTROL> = "STOP"
                            WRITE R.SERVICE ON F.TSA.SERVICE, ID.SERVICE
                            SERVICE.DEMARRE = 1
                            GOSUB CHECK.RUNNING.PRO
                        END ELSE
                            GOSUB CHECK.RUNNING
                        END
                    END
                END ELSE      ;* READ R.SERVICE
                    RELEASE F.TSA.SERVICE, ID.SERVICE
                END ;* ELSE READ R.SERVICE
            REPEAT
        END         ;* IF NB.ARRET
    WHILE SERVICE.DEMARRE DO
        SLEEP TEMPS.PAUSE
        TEMPS.PAUSE = 10
    REPEAT

    PRINT OCONV(TIME(),"MTS"):" Tous les services sont a l'arret "

    RETURN


**************
CHECK.RUNNING:
**************
    CMD.CTRL = 'SSELECT F.TSA.STATUS WITH AGENT LIKE 1N0N AND (CURRENT.SERVICE = "' : ID.SERVICE : '" OR NEXT.SERVICE = "' : ID.SERVICE : '") AND AGENT.STATUS = "RUNNING"'
    NUM.PROCESS = ""
    SLCT.NB = ""
    LIST.OF.ID = ""
    CALL EB.READLIST(CMD.CTRL,LIST.OF.ID,LST.NAME,NUM.PROCESS,SLCT.NB)
    IF LIST.OF.ID THEN
        LOOP
            REMOVE REC.ID FROM LIST.OF.ID SETTING RECDELIM
        WHILE REC.ID:RECDELIM
            READ R.REC FROM F.TSA.STATUS,REC.ID ELSE NULL
            IF R.REC THEN
                COMO.NAME.1 = '' ; PORT.NO = ''
                COMO.NAME.1 = R.REC<TS.TSS.COMO.NAME>
                PORT.NO = R.REC<TS.TSS.PORT.ID>
                GOSUB EXEC.EXIT
            END
        REPEAT
        CLEARSELECT
        SERVICE.DEMARRE = 1
        RELEASE F.TSA.SERVICE, ID.SERVICE
        PRINT OCONV(TIME(),"MTS"):" Tsa Service ":ID.SERVICE:" Toujours Running ":LIST.TSA
    END ELSE
        R.SERVICE<TS.TSM.SERVICE.CONTROL> = "STOP"
        WRITE R.SERVICE ON F.TSA.SERVICE, ID.SERVICE
    END

    RETURN

******************
CHECK.RUNNING.PRO:
******************

    LOOP
        SERV.PRO = 0
        CMD.CTRL = 'SSELECT F.TSA.STATUS WITH AGENT LIKE 1N0N AND (CURRENT.SERVICE = "' : ID.SERVICE : '" OR NEXT.SERVICE = "' : ID.SERVICE : '") AND AGENT.STATUS = "RUNNING"'
        NUM.PROCESS = ""
        SLCT.NB = ""
        LIST.OF.ID = ""
        CALL EB.READLIST(CMD.CTRL,LIST.OF.ID,LST.NAME,NUM.PROCESS,SLCT.NB)
        IF LIST.OF.ID THEN
            LOOP
                REMOVE REC.ID FROM LIST.OF.ID SETTING RECDELIM
            WHILE REC.ID:RECDELIM
                READ R.REC FROM F.TSA.STATUS,REC.ID ELSE NULL
                IF R.REC THEN
                    COMO.NAME.1 = '' ; PORT.NO = ''
                    COMO.NAME.1 = R.REC<TS.TSS.COMO.NAME>
                    PORT.NO = R.REC<TS.TSS.PORT.ID>
                    GOSUB EXEC.EXIT
                END
            REPEAT
            CLEARSELECT
            SERV.PRO = 1
            RELEASE F.TSA.SERVICE, ID.SERVICE
            PRINT OCONV(TIME(),"MTS"):" Tsa Service ":ID.SERVICE:" Toujours Running ":LIST.TSA
        END

    WHILE SERV.PRO DO
        SLEEP TEMPS.PAUSE
        TEMPS.PAUSE = 10
    REPEAT

    RETURN

************
CHECK.BATCH:
************
    REC.BATCH = ''
    REC.PGM.FILE = ''
    ACT.FILE = ''
    PRO.SERVICE = @FALSE
    READ REC.BATCH FROM F.BATCH,ID.SERVICE ELSE NULL
    IF REC.BATCH THEN
        JOBS.BATCH = REC.BATCH<BAT.JOB.NAME>
        NB.VM = DCOUNT(JOBS.BATCH,@VM)
        FOR J = 1 TO NB.VM
            JOB.BATCH =REC.BATCH<BAT.JOB.NAME,J>
            READ REC.PGM.FILE FROM F.PGM.FILE,JOB.BATCH ELSE NULL
            IF REC.PGM.FILE THEN
                ACT.FILE = REC.PGM.FILE<EB.PGM.ACTIVATION.FILE>
                IF ACT.FILE THEN
                    PRO.SERVICE = @TRUE
                    J = NB.VM
                END
            END
        NEXT J
    END

    RETURN

**********
EXEC.EXIT:
**********
    LIST.WHERE = ''
    CAPT.WHERE = ''
    CMD="WHERE V( ":PORT.NO
    EXECUTE CMD RTNLIST LIST.WHERE CAPTURING CAPT.WHERE
    CAPT.TSM = ''
    CAPT.TSM = 'tSA ':REC.ID
    IF INDEX (CAPT.WHERE, 'User not logged on', 1) THEN
        PRINT OCONV(TIME(),"MTS"):" ERROR. - PORT TSA.STATUS ":ID.SERVICE:" HORS SERVICE: ":PORT.NO
        PRINT OCONV(TIME(),"MTS"):" ERROR. - Verifier Log: ":COMO.NAME.1
        STR.CODE = 99
        GOSUB FATAL.ERROR99
    END ELSE
        IF NOT(INDEX (CAPT.WHERE,CAPT.TSM,1)) THEN
            PRINT OCONV(TIME(),"MTS"):" ERROR. - PORT TSA.STATUS ":ID.SERVICE:"  Not Running: ":PORT.NO
            PRINT OCONV(TIME(),"MTS"):" ERROR. - Verifier Log: ":COMO.NAME.1
            STR.CODE = 99
            GOSUB FATAL.ERROR99
        END
    END

    RETURN

**********
WRITE.COMO:
***********

    WRITE STR.CODE TO F.COMO,'TSA.STOP' ON ERROR
        PRINT OCONV(TIME(),"MTS"):"  Error. Impossible de rederiger vers COMO."
        PRINT '99'
        STOP
    END

    CLOSE F.COMO
    EXIT(STR.CODE)
    STOP


**************
FATAL.ERROR99:
**************

* DISPLAY ERR.MSG
    STR.CODE = '99'
    GOSUB WRITE.COMO
    STOP
