* @ValidationCode : MjoyMDIzMjc5Nzk6Q3AxMjUyOjE1NDc0NTkzOTg3MTk6dXRndGw1MjotMTotMTowOjA6ZmFsc2U6Ti9BOlIxOF9BTVIuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 14 Jan 2019 11:49:58
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : utgtl52
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R18_AMR.0
*-----------------------------------------------------------------------------
* <Rating>150</Rating>
*-----------------------------------------------------------------------------
SUBROUTINE E.GET.COB.JOB.STATS(IN.MSG,OUT.MSG)

    $INCLUDE I_COMMON
    $INCLUDE I_EQUATE
    $INCLUDE I_F.BATCH
    $INCLUDE I_F.DATES

    OPEN "F.BATCH" TO F.BATCH ELSE
        OUT.MSG = "ER: COULD NOT OPEN BATCH RECORD"
        RETURN
    END

    OPEN "F.DATES" TO F.DATES ELSE
    END

    READ R.DATE FROM F.DATES, "IL0010001-COB" THEN
        R.TODAY = R.DATE<EB.DAT.TODAY>
    END
    ELSE
        R.TODAY = TODAY
    END

    SEL.CMD = "SSELECT ":F.BATCH:" WITH BATCH.STAGE NE ''"
    CALL EB.READLIST(SEL.CMD, JOB.LIST, "", SELECTED, SEL.ERR)

    IF SEL.ERR AND NOT(JOB.LIST) AND NOT(SELECTED) THEN
        OUT.MSG = "ER: " : SEL.ERR
        RETURN
    END

    TOTAL = 0
    COMPLETED = 0
    Y.ERROR = 0

    FOR I = 1 TO SELECTED
        R.BATCH = ""
        READ R.BATCH FROM F.BATCH, JOB.LIST<I> ELSE
        END

        JOBS = DCOUNT(R.BATCH<BAT.JOB.NAME>,@VM)
        FOR J = 1 TO JOBS
            IF R.BATCH<BAT.JOB.STATUS,J> = "2" THEN
                COMPLETED += 1
                TOTAL += 1
            END
            IF R.BATCH<BAT.JOB.STATUS,J> = "1" THEN
                TOTAL += 1
            END
            IF R.BATCH<BAT.JOB.STATUS,J> = "3" THEN
                Y.ERROR += 1
                TOTAL += 1
            END
            IF R.BATCH<BAT.JOB.STATUS,J> = "0" THEN
                IF R.BATCH<BAT.FREQUENCY,J> = "D" THEN
                    TOTAL += 1
                END
                ELSE
                    IF R.BATCH <BAT.NEXT.RUN.DATE,J> = TODAY THEN
                        TOTAL += 1
                    END
                END
            END
        NEXT J
    NEXT I

    OUT.MSG=TOTAL:",":COMPLETED:",":(TOTAL-COMPLETED):",":Y.ERROR:",":FMT((COMPLETED*100/TOTAL),"L2%5")

RETURN


