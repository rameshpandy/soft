*-----------------------------------------------------------------------------
* <Rating>2393</Rating>
*-----------------------------------------------------------------------------
*    $PACKAGE Tool_Packman
    
    SUBROUTINE SEL.INSTALL.ACTION.VALIDATE
***<region name=Description>
***
* @author = TM
* @date = 21/01/2014
*
* Controle a la validation de la table des actions a executer a l'installation avec PACK MAN.
***</region>
***<region name=changelog>
***
***</region>
    $INSERT I_COMMON
    $INSERT I_EQUATE

    $INSERT I_F.FILE.CONTROL
    $INSERT I_F.PGM.FILE
    $INSERT I_F.SEL.INSTALL.ACTION
    $INSERT I_F.STANDARD.SELECTION

    GOSUB INITIALISE
    GOSUB OPEN.FILES
    GOSUB PROCESS.MESSAGE

    RETURN
***<region name=Initialise>
***
INITIALISE:

    FN.OFS.SOURCE = "F.OFS.SOURCE" ; F.OFS.SOURCE = ""
    FN.PGM.FILE = "F.PGM.FILE" ; F.PGM.FILE = ""
    FN.STANDARD.SELECTION = "F.STANDARD.SELECTION" ; F.STANDARD.SELECTION = ""
    FN.TSA.SERVICE = "F.TSA.SERVICE" ; F.TSA.SERVICE = ""

    CURR.NO = 0

    RETURN
***</region>
***<region name=Open files>
***
OPEN.FILES:

    CALL OPF (FN.OFS.SOURCE, F.OFS.SOURCE)
    CALL OPF (FN.PGM.FILE, F.PGM.FILE)
    CALL OPF (FN.STANDARD.SELECTION, F.STANDARD.SELECTION)
    CALL OPF (FN.TSA.SERVICE, F.TSA.SERVICE)

    RETURN
***</region>
***<region name=Process Message>
***
PROCESS.MESSAGE:

    BEGIN CASE
    CASE MESSAGE EQ ''        ;* Only during commit...
        BEGIN CASE
        CASE V$FUNCTION EQ 'D'
            GOSUB VALIDATE.DELETE
        CASE V$FUNCTION EQ 'R'
            GOSUB VALIDATE.REVERSE
        CASE OTHERWISE        ;* The real VALIDATE...
            GOSUB VALIDATE
        END CASE
    CASE MESSAGE EQ 'AUT' OR MESSAGE EQ 'VER'     ;* During authorisation and verification...
        GOSUB VALIDATE.AUTHORISATION
    END CASE

    RETURN
***<region name=Validate>
***<desc>Controles a la validation hors Delete et Reverse</desc>
VALIDATE:

* Supprime les anciens overrides
    CALL STORE.OVERRIDE (CURR.NO)

    TYPE.ACTION = R.NEW(SEL.INST.ACTION.TYPE.ACTION)
    PARAM1 = R.NEW(SEL.INST.ACTION.PARAMETRE1)
    PARAM2 = R.NEW(SEL.INST.ACTION.PARAMETRE2)
    PARAM3 = R.NEW(SEL.INST.ACTION.PARAMETRE3)
    PARAM4 = R.NEW(SEL.INST.ACTION.PARAMETRE4)
    BEGIN CASE
    CASE TYPE.ACTION = "SH"
* Shell Unix
        IF PARAM2 THEN
            AF = SEL.INST.ACTION.PARAMETRE2
            AV = 1
            AS = ""
            ETEXT = "Paramètre 2 inutile"
            CALL STORE.END.ERROR
        END
        IF PARAM3 THEN
            AF = SEL.INST.ACTION.PARAMETRE3
            AV = 1
            AS = ""
            ETEXT = "Paramètre 3 inutile"
            CALL STORE.END.ERROR
        END
        IF PARAM4 THEN
            AF = SEL.INST.ACTION.PARAMETRE4
            AV = 1
            AS = ""
            ETEXT = "Paramètre 4 inutile"
            CALL STORE.END.ERROR
        END
    CASE TYPE.ACTION = "RTN"
* Routine (T24.LAUNCHER)
        CALL F.READ (FN.PGM.FILE, PARAM1, R.PGM.FILE, F.PGM.FILE, ERR.MSG)
        IF ERR.MSG THEN
            AF = SEL.INST.ACTION.PARAMETRE1
            AV = ""
            AS = ""
            ETEXT = DQUOTE(PARAM1) : " n'est pas défini dans PGM.FILE"
            CALL STORE.END.ERROR
        END ELSE IF R.PGM.FILE<EB.PGM.TYPE> # "M" THEN
            AF = SEL.INST.ACTION.PARAMETRE1
            AV = ""
            AS = ""
            ETEXT = DQUOTE(PARAM1) : " n'est pas de type M"
            CALL STORE.END.ERROR
        END
        IF PARAM3 THEN
            AF = SEL.INST.ACTION.PARAMETRE3
            AV = 1
            AS = ""
            ETEXT = "Paramètre 3 inutile"
            CALL STORE.END.ERROR
        END
        IF PARAM4 THEN
            AF = SEL.INST.ACTION.PARAMETRE4
            AV = 1
            AS = ""
            ETEXT = "Paramètre 4 inutile"
            CALL STORE.END.ERROR
        END
    CASE TYPE.ACTION = "SRV"
* Service
        IF PARAM1 # "ALL_TSA" THEN
            CALL F.READ (FN.TSA.SERVICE, PARAM1, R.TSA.SERVICE, F.TSA.SERVICE, ERR.MSG)
            IF ERR.MSG THEN
                AF = SEL.INST.ACTION.PARAMETRE1
                AV = ""
                AS = ""
                ETEXT = DQUOTE(PARAM1) : " n'est pas un service"
                CALL STORE.END.ERROR
            END
        END
        BEGIN CASE
        CASE NOT(PARAM2)
            AF = SEL.INST.ACTION.PARAMETRE2
            AV = 1
            AS = ""
            ETEXT = "EB-INPUT.MISSING"
            CALL STORE.END.ERROR
        CASE DCOUNT(PARAM2, VM) > 1
            AF = SEL.INST.ACTION.PARAMETRE2
            AV = 2
            AS = ""
            ETEXT = "Il ne faut qu'une seule ligne de paramètre 2"
            CALL STORE.END.ERROR
        CASE PARAM2 # "STOP" AND PARAM2 # "START" AND PARAM2 # "STOPWAIT" AND PARAM2 # "STARTWAIT" AND PARAM2 # "AUTO" AND PARAM2 # "RESTART"
            AF = SEL.INST.ACTION.PARAMETRE2
            AV = 1
            AS = ""
            ETEXT = "Seules les valeurs STOP, START, STOPWAIT, STARTWAIT, AUTO et RESTART sont autorisées"
            CALL STORE.END.ERROR
        CASE PARAM1 = "ALL_TSA" AND (PARAM2 = "START" OR PARAM2 = "STARTWAIT" OR PARAM2 = "AUTO")
            AF = SEL.INST.ACTION.PARAMETRE2
            AV = 1
            AS = ""
            ETEXT = "Valeurs START, STARTWAIT et AUTO interdites pour ALL_TSA"
            CALL STORE.END.ERROR
        END CASE
        IF PARAM3 THEN
            AF = SEL.INST.ACTION.PARAMETRE3
            AV = 1
            AS = ""
            ETEXT = "Paramètre 3 inutile"
            CALL STORE.END.ERROR
        END
        IF PARAM4 THEN
            AF = SEL.INST.ACTION.PARAMETRE4
            AV = 1
            AS = ""
            ETEXT = "Paramètre 4 inutile"
            CALL STORE.END.ERROR
        END
    CASE TYPE.ACTION = "OFS1" OR TYPE.ACTION = "OFSF"
* 1 OFS ou fichier OFS
        CALL F.READ (FN.OFS.SOURCE, PARAM1, R.OFS.SOURCE, F.OFS.SOURCE, ERR.MSG)
        IF ERR.MSG THEN
            AF = SEL.INST.ACTION.PARAMETRE1
            AV = 1
            AS = ""
            ETEXT = "La source OFS " : DQUOTE(PARAM2) : " n'existe pas"
            CALL STORE.END.ERROR
        END
        BEGIN CASE
        CASE NOT(PARAM2)
            AF = SEL.INST.ACTION.PARAMETRE2
            AV = 1
            AS = ""
            ETEXT = "EB-INPUT.MISSING"
            CALL STORE.END.ERROR
        CASE DCOUNT(PARAM2, VM) > 1 AND TYPE.ACTION = "OFSF"
            AF = SEL.INST.ACTION.PARAMETRE2
            AV = 2
            AS = ""
            ETEXT = "Il ne faut qu'une seule ligne de paramètre 2"
            CALL STORE.END.ERROR
        CASE OTHERWISE
        END CASE
        IF PARAM3 THEN
            AF = SEL.INST.ACTION.PARAMETRE3
            AV = 1
            AS = ""
            ETEXT = "Paramètre 3 inutile"
            CALL STORE.END.ERROR
        END
        IF PARAM4 THEN
            AF = SEL.INST.ACTION.PARAMETRE4
            AV = 1
            AS = ""
            ETEXT = "Paramètre 4 inutile"
            CALL STORE.END.ERROR
        END
    CASE TYPE.ACTION = "EXTR"
* Extraction
        NOM.APPLI = PARAM1["$", 1, 1]
        SUFFIXE.APPLI = PARAM1["$", 2, 9999]
        CALL F.READ ("F.FILE.CONTROL", NOM.APPLI, R.FILE.CONTROL, F.FILE.CONTROL, ERR.MSG)
        CALL F.READ (FN.STANDARD.SELECTION, NOM.APPLI, R.SS, F.STANDARD.SELECTION, ERR.MSG)
        IF ERR.MSG THEN
            R.SS = ""
            AF = SEL.INST.ACTION.PARAMETRE1
            AV = ""
            AS = ""
            ETEXT = "La table " : DQUOTE(NOM.APPLI) : " n'existe pas dans FILE.CONTROL"
            CALL STORE.END.ERROR
        END ELSE
            IF SUFFIXE.APPLI THEN
                LOCATE "$" : SUFFIXE.APPLI IN R.FILE.CONTROL<EB.FILE.CONTROL.SUFFIXES, 1> SETTING POS.SUFFIXE ELSE
                    AF = SEL.INST.ACTION.PARAMETRE1
                    AV = ""
                    AS = ""
                    ETEXT = "Le suffixe " : DQUOTE(SUFFIXE.APPLI) : " n'existe pas dans FILE.CONTROL"
                    CALL STORE.END.ERROR
                END
            END
        END
        MOT.SELECT = TRIM(PARAM2)[" ", 1, 1]
        BEGIN CASE
        CASE NOT(PARAM2)
            AF = SEL.INST.ACTION.PARAMETRE2
            AV = 1
            AS = ""
            ETEXT = "EB-INPUT.MISSING"
            CALL STORE.END.ERROR
        CASE INDEX(PARAM2, '"', 1)
            AF = SEL.INST.ACTION.PARAMETRE2
            AV = 1
            AS = ""
            ETEXT = "La requête de sélection ne doit pas contenir de guillemet"
            CALL STORE.END.ERROR
        CASE MOT.SELECT = "GL" OR MOT.SELECT = "GET.LIST"
            CONVERT VM TO " " IN PARAM2
            PARAM2 = TRIM(PARAM2)
            IF DCOUNT(PARAM2, " ") # 2 THEN
                AF = SEL.INST.ACTION.PARAMETRE2
                AV = 1
                AS = ""
                ETEXT = MOT.SELECT : " doit être suivi d'un nom de liste sans espace"
                CALL STORE.END.ERROR
            END
        CASE MOT.SELECT # "SELECT" AND MOT.SELECT # "SSELECT"
            AF = SEL.INST.ACTION.PARAMETRE2
            AV = 1
            AS = ""
            ETEXT = "La requête de sélection doit commencer par SELECT, SSELECT, GL ou GET.LIST"
            CALL STORE.END.ERROR
        END CASE
        BEGIN CASE
        CASE INDEX(PARAM3, " ", 1)
            FINDSTR " " IN PARAM3 SETTING POS.FIELD, AV THEN
                AF = SEL.INST.ACTION.PARAMETRE3
                AS = ""
                ETEXT = "Les noms de champs ne doivent pas contenir d'espace"
                CALL STORE.END.ERROR
            END
        CASE PARAM3 AND R.SS
            CONVERT "/" TO VM IN PARAM3
            NB.FIELD = DCOUNT(PARAM3, VM)
            FOR I.FIELD = 1 TO NB.FIELD
                NOM.CHAMP = PARAM3<1, I.FIELD>
                PRES.FIELD = 0
                LOCATE NOM.CHAMP IN R.SS<SSL.SYS.FIELD.NAME, 1> SETTING POS.FIELD THEN
                    IF R.SS<SSL.SYS.TYPE, POS.FIELD> = "D" AND R.SS<SSL.SYS.FIELD.NO, POS.FIELD> MATCH '1N0N' AND R.SS<SSL.SYS.FIELD.NO, POS.FIELD> THEN
                        PRES.FIELD = 1
                    END
                END ELSE LOCATE NOM.CHAMP IN R.SS<SSL.USR.FIELD.NAME, 1> SETTING POS.FIELD THEN
                    IF R.SS<SSL.USR.TYPE, POS.FIELD> = "I" AND R.SS<SSL.USR.FIELD.NO, POS.FIELD> MATCH '"LOCAL.REF<1,"1N0N">"' THEN
                        PRES.FIELD = 1
                    END
                END
                IF NOT(PRES.FIELD) THEN
                    FINDSTR NOM.CHAMP IN R.NEW(SEL.INST.ACTION.PARAMETRE3) SETTING POS.FIELD, AV THEN
                        AF = SEL.INST.ACTION.PARAMETRE2
                        AS = ""
                        ETEXT = "Le champ " : NOM.CHAMP : " n'existe pas pour cette application"
                        CALL STORE.END.ERROR
                    END
                END
            NEXT I.FIELD
        END CASE
        IF NOT(PARAM4) THEN
            AF = SEL.INST.ACTION.PARAMETRE4
            AV = 1
            AS = ""
            ETEXT = "EB-INPUT.MISSING"
            CALL STORE.END.ERROR
        END
    END CASE

    RETURN
***</region>
***<region name=VALIDATE.DELETE>
***<desc>Any special checks for deletion</desc>
VALIDATE.DELETE:

    RETURN
***</region>
***<region name=VALIDATE.REVERSE>
***<desc>Any special checks for reversal</desc>
VALIDATE.REVERSE:

    RETURN
***</region>
***<region name=VALIDATE.AUTHORISATION>
***<desc>Any special checks for authorisation</desc>
VALIDATE.AUTHORISATION:

    RETURN
***</region>
***</region>
***<region name=On error>
***
ON.ERROR:

    RETURN TO ON.ERROR
***</region>
