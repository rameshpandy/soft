*-----------------------------------------------------------------------------
* <Rating>-35</Rating>
*-----------------------------------------------------------------------------
*    $PACKAGE Tool_Packman

    PROGRAM T24.T.COMPILE
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE

    IN.PARAM = SENTENCE(1)

*
    OS.TYPE = SYSTEM(1017)
    IF OS.TYPE <> 'UNIX' THEN
        OS.TYPE = 'NT'
    END
    IF OS.TYPE = "UNIX" THEN
        SEP.REP = "/"
        CHANGE "\" TO "/" IN IN.PARAM
    END ELSE
        SEP.REP = "\"
        CHANGE "/" TO "\" IN IN.PARAM
    END

    NB.SEP.REP = DCOUNT(IN.PARAM, SEP.REP)
    IF NB.SEP.REP GT 1 THEN
        L.NOM.PROG = FIELDS(IN.PARAM,SEP.REP,NB.SEP.REP)
        W.LENGHT.NOM.PROG = LEN(IN.PARAM) - LEN(L.NOM.PROG) - 1
        NOM.BP = IN.PARAM[1,W.LENGHT.NOM.PROG]
    END ELSE
        L.NOM.PROG = IN.PARAM
        NOM.BP = "." : SEP.REP
    END

* Controle des parametres
    IF RIGHT(NOM.BP, 3) # ".BP" AND LEN(NOM.BP) > 2 THEN
        CRT "The source file should be in a folder with suffix .BP."
        STOP
    END
    OPEN NOM.BP TO F.BP ELSE
        STOP 201, NOM.BP
    END

* Lecture des parametres
*    PARAM.APPEL = SYSTEM(1000)

* Controle des codes sources
    FOR I.PROG = DCOUNT(L.NOM.PROG, @FM) TO 1 STEP -1
        C.PROG = L.NOM.PROG<I.PROG>
        REP.ATTENDU = ""
        * Programme existe ?
        READ R.PROG FROM F.BP, C.PROG ELSE
            CRT "Routine/Program " : C.PROG : " missing"
            DEL L.NOM.PROG<I.PROG>
            CONTINUE
        END
        * Exclus certains noms
        IF C.PROG[1, 2] = "I_" OR C.PROG[1, 1] = "$" OR C.PROG[4] = ".OLD" OR C.PROG[2] = ".c" OR C.PROG[4] = ".exe" OR C.PROG[2] = ".o" OR C.PROG[3] = ".so" OR C.PROG[6] = ".so.el" THEN
            CRT "This routine " : C.PROG : " should not be compiled"
            DEL L.NOM.PROG<I.PROG>
            CONTINUE
        END
        * Controle la declaration PROGRAM/SUBROUTINE/FUNCTION
        LOOP
            REMOVE LIG.PROG FROM R.PROG SETTING POS.PROG
        WHILE LIG.PROG OR POS.PROG DO
            LIG.PROG = TRIM(LIG.PROG)
        WHILE LIG.PROG = "" OR LIG.PROG[1, 1] = "*" OR LIG.PROG[1, 1] = "!" OR LIG.PROG[" ", 1, 1] = "REM" DO
        REPEAT
        TYPE.PROG = LIG.PROG[" ", 1, 1]
        BEGIN CASE
            CASE TYPE.PROG = "SUBROUTINE" OR TYPE.PROG = "FUNCTION"
                REP.ATTENDU = "lib"
                NOM.PROG.SRC = LIG.PROG[" ", 2, 1]["(", 1, 1]
            CASE TYPE.PROG = "PROGRAM"
                REP.ATTENDU = "bin"
                NOM.PROG.SRC = LIG.PROG[" ", 2, 1]
        END CASE
        IF NOM.PROG.SRC AND FIELDS(C.PROG,".b",1) # NOM.PROG.SRC THEN
            CRT "The name of SUBROUTINE/PROGRAM (" : NOM.PROG.SRC : ") different from the source file name " : C.PROG
            DEL L.NOM.PROG<I.PROG>
            CONTINUE
        END
        * Controle de la presence d'un DEBU G dans la routine
        IF NOT(OPTION.DEBU.G) THEN
            PRES.DEBU.G = 0
            GOSUB CTRL.DEBU.G
            IF PRES.DEBU.G THEN
                CRT "The source " : C.PROG : " contains a DEBU" : "G"
                DEL L.NOM.PROG<I.PROG>
                CONTINUE
            END
        END
    NEXT I.PROG
*    IF NOT(ERREURS.SEULS) THEN
*        CRT
*    END
    CLOSE F.BP
*
    IF L.NOM.PROG THEN
        W.ERROR.LOG = ''
        IF OS.TYPE = "UNIX" THEN
            TCL.COMPILE = "SH -c tCompile "  : IN.PARAM ;*: ">>LOGXXX.txt"
        END ELSE
            TCL.COMPILE = "DOS /c tCompile "  : IN.PARAM ;*: ">>LOGXXX.txt"
        END
*        CRT TCL.COMPILE
        EXECUTE TCL.COMPILE CAPTURING SORTIE.CATALOG

        W.DELIM = CHAR(91):CHAR(27):CHAR(91):CHAR(49):CHAR(109):CHAR(27):CHAR(91):CHAR(51):CHAR(49):CHAR(109):CHAR(69):CHAR(82):CHAR(82):CHAR(79):CHAR(82):CHAR(27):CHAR(91):CHAR(48):CHAR(109):CHAR(93)
        CHANGE CHAR(10) TO @FM IN SORTIE.CATALOG
        CHANGE CHAR(13) TO '' IN SORTIE.CATALOG
        UCNT = DCOUNT(SORTIE.CATALOG,@FM)
        
        *
  
        FOR I = 1 TO UCNT
            IF SORTIE.CATALOG<I>[1,20]=W.DELIM THEN
                W.ERROR.LOG<-1> =  SORTIE.CATALOG<I>
            END
*           IF I EQ UCNT THEN
*               W.ERROR.LOG<-1> = FIELDS(FIELDS(SORTIE.CATALOG,W.DELIM,I+1),CHAR(10),1)
*           END ELSE
*               W.LOG = FIELDS(SORTIE.CATALOG,W.DELIM,I)
*               CHANGE CHAR(10) TO "" IN W.LOG
*               W.ERROR.LOG<-1> = W.LOG
*           END
        NEXT I
        IF W.ERROR.LOG THEN
            IF OS.TYPE <> 'UNIX' THEN
                CONSOL.KEY.TYPE.LINE = CHAR(13):CHAR(10)
            END ELSE
                CONSOL.KEY.TYPE.LINE = CHAR(10)
            END

            CHANGE FM TO CONSOL.KEY.TYPE.LINE IN W.ERROR.LOG
            CRT W.ERROR.LOG
        END ELSE
            CRT "COMPILE:OK"
        END

        *			GOSUB AFFICHE.ERREURS.COMPILE

    END ; * IF L.NOM.PROG

*    STOP
   RETURN
*--------------------------------------------------------------------
*
CTRL.DEBU.G:

    I.DEBU.G = 1
    LOOP
        FINDSTR "DEBU" : "G" IN R.PROG, I.DEBU.G SETTING NUM.LIG ELSE
            EXIT
        END
        LIG.PROG = R.PROG<NUM.LIG>
        CONVERT ";" TO @FM IN LIG.PROG
        NB.INST = DCOUNT(LIG.PROG, @FM)
        FOR I.INST = 1 TO NB.INST
            INST.PROG = TRIM(LIG.PROG<I.INST>)
            IF INST.PROG[1, 1] = "*" OR INST.PROG[1, 1] = "!" OR INST.PROG[" ", 1, 1] = "REM" THEN
                EXIT
            END
            IF INST.PROG = "DEBU" : "G" OR INST.PROG[6] = " DEBU" : "G" THEN
                PRES.DEBU.G = 1
            END
        NEXT I.INST
    UNTIL PRES.DEBU.G DO
        I.DEBU.G = I.DEBU.G + 1
    REPEAT

    RETURN
*--------------------------------------------------------------------
*--------------------------------------------------------------------
*
AFFICHE.ERREURS.COMPILE:

    NOM.PROG.CRT = ""
    ENS.ERREUR.PROG = ""
    LIG.PREC = ""
    LOOP
        REMOVE LIG.SORTIE FROM SORTIE.CATALOG SETTING POS.LIG
    WHILE LIG.SORTIE : POS.LIG DO
        IF NOT(INDEX(LIG.SORTIE, " ", 1)) THEN
            LOCATE LIG.SORTIE IN L.NOM.PROG<1> SETTING POS.PROG THEN
            * C'est le nom du programme
            IF NOM.PROG.CRT # LIG.SORTIE THEN
                GOSUB AFFICHE.DERNIERE.ERREUR
                NOM.PROG.CRT = LIG.SORTIE
                CONTINUE
            END
        END
    END
    NB.MOT.SORTIE = DCOUNT(LIG.SORTIE, " ")
    BEGIN CASE
            * Lignes a ignorer
        CASE TRIM(LIG.SORTIE) = ""
        CASE LIG.SORTIE[" ", 1, 1] = "Library" AND LIG.SORTIE[" ", NB.MOT.SORTIE - 1, 2] = "rebuild okay"
        CASE LIG.SORTIE[" ", 1, 6] = "xlC_r: 1501-291 (I) Utilization tracking message:"
            * Derniere ligne en cas de catalog reussie
        CASE NOM.PROG.CRT AND LIG.SORTIE[" ", 1, 1] = "Object" AND INDEX(LIG.SORTIE, NOM.PROG.CRT, 1) AND LIG.SORTIE[" ", NB.MOT.SORTIE - 1, 2] = "cataloged successfully"
            IF ENS.ERREUR.PROG THEN
                GOSUB AJOUT.ERREUR
                GOSUB AFFICHE.DERNIERE.ERREUR
            END
            * Sinon il faut afficher le message
        CASE 1
            GOSUB AJOUT.ERREUR
    END CASE
    REPEAT

    GOSUB AFFICHE.DERNIERE.ERREUR

    RETURN
*--------------------------------------------------------------------
*
AFFICHE.DERNIERE.ERREUR:

    IF ENS.ERREUR.PROG # "" THEN
        CRT NOM.PROG.CRT
        NB.ERREUR = DCOUNT(ENS.ERREUR.PROG, @FM)
        FOR I.ERREUR = 1 TO NB.ERREUR
            CRT ENS.ERREUR.PROG<I.ERREUR>
        NEXT I.ERREUR
        ENS.ERREUR.PROG = ""
    END

    RETURN
*--------------------------------------------------------------------
*
AJOUT.ERREUR:

    IF ENS.ERREUR.PROG # "" THEN
        ENS.ERREUR.PROG := @FM
    END
    ENS.ERREUR.PROG := LIG.SORTIE

    RETURN
*------------------------------------------------------------------------
*
