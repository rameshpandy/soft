*-----------------------------------------------------------------------------
* <Rating>-1</Rating>
*-----------------------------------------------------------------------------
*    $PACKAGE Tool_Packman

    SUBROUTINE COPY.FROM.FILE.TO.DB(PATH.FILE.NAME.FROM,APPLICATION.TO,ID.REC,DO.READ.WRITE)
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
*-----------------------------------------------------------------------------


    RETURN.CODE = ''
*
    OS.TYPE = SYSTEM(1017)
    IF OS.TYPE <> 'UNIX' THEN
        OS.TYPE = 'NT'
    END
    SEP.REP.UNIX = "/"
    SEP.REP.NT = "\"
*
    IF OS.TYPE = "UNIX" THEN
        CHANGE SEP.REP.NT TO SEP.REP.UNIX IN PATH.FILE.NAME.FROM
        NB.SEP = COUNT(PATH.FILE.NAME.FROM,SEP.REP.UNIX)
        FILE.NAME.FROM = FIELDS(PATH.FILE.NAME.FROM,SEP.REP.UNIX,NB.SEP+1)
        PATH.NAME = PATH.FILE.NAME.FROM[1,LEN(PATH.FILE.NAME.FROM) - LEN(FILE.NAME.FROM) - 1]
    END ELSE
        CHANGE SEP.REP.UNIX TO SEP.REP.NT IN PATH.FILE.NAME.FROM
        NB.SEP = COUNT(PATH.FILE.NAME.FROM,SEP.REP.NT)
        FILE.NAME.FROM = FIELDS(PATH.FILE.NAME.FROM,SEP.REP.NT,NB.SEP+1)
        PATH.NAME = PATH.FILE.NAME.FROM[1,LEN(PATH.FILE.NAME.FROM) - LEN(FILE.NAME.FROM) - 1]
    END


    IF DO.READ.WRITE NE "Y" THEN
        CMD.EXECUTE = "COPY FROM " : PATH.FILE.NAME.FROM : " TO " : APPLICATION.TO : " " : ID.REC
        EXECUTE CMD.EXECUTE CAPTURING RESULT
        CRT RESULT
    END ELSE
        OPEN PATH.NAME TO F.PATH.FILE ELSE
            CRT "UNABLE TO OPEN :" : PATH.FILE.NAME.FROM
            RETURN
        END

        OPEN APPLICATION.TO TO F.APPLICATION.TO ELSE
            CRT "UNABLE TO OPEN :" : APPLICATION.TO
            RETURN
        END

        READ R.FILE.NAME.FROM FROM F.PATH.FILE,FILE.NAME.FROM THEN
            WRITE R.FILE.NAME.FROM TO F.APPLICATION.TO, ID.REC ON ERROR
                CRT "UNABLE TO WRITE : " : ID.REC : " TO " : APPLICATION.ID
            END
        END ELSE
            CRT "UNABLE TO READ :" : FILE.NAME.FROM : " FROM " : APPLICATION.TO
        END

        CALL JOURNAL.UPDATE("ID.REC")
    END
    RETURN
