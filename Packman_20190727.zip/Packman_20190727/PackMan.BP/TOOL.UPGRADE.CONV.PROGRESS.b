*-----------------------------------------------------------------------------
* <Rating>-148</Rating>
*-----------------------------------------------------------------------------
    PROGRAM TOOL.UPGRADE.CONV.PROGRESS
*-----------------------------------------------------------------------------
*<doc>
*  table.
* @author = AF
* @date = 08/2018
* @jira =
*</doc>
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.CONVERSION.PGMS
    $INSERT I_F.TSA.SERVICE
    $INSERT I_F.BATCH

*-----------------------------------------------------------------------------

    GOSUB INITIALISE
    IF W.CONTINUE = 'Y' THEN    
        GOSUB PROCESS
    END
    RETURN
    
********************************************************************************
INITIALISE:
********************************************************************************
    W.CONTINUE = 'Y'

* Open table
    FN.CONVERSION.PGMS = 'F.CONVERSION.PGMS'
    F.CONVERSION.PGMS = ''
    CALL OPF(FN.CONVERSION.PGMS,F.CONVERSION.PGMS)
* Open table
    FN.BATCH = 'F.BATCH'
    F.BATCH = ''
    CALL OPF(FN.BATCH,F.BATCH)
* Open table
    FN.TSA.SERVICE = 'F.TSA.SERVICE'
    F.TSA.SERVICE = ''
    CALL OPF(FN.TSA.SERVICE,F.TSA.SERVICE)
    
    
    W.NR.TOTAL.REC=0
    W.NR.REC.PROC=0
    W.NR.REC.NOT.SCHED.TO.RUN=0
                
    W.CONV.IDS="R16" : @FM : "R17" : @FM : "R18" 


    W.CONVSVC.SERVICE="BLM.CONV.OPT.SEC.MASTER" : @FM : "BLM.CONV.OPT.SEC.MASTER.HIS" : @FM : "BLM.OPT.CONV.AC.HIS.RTN" : @FM : "BLM.OPT.CONV.AC.RTN" : @FM : "BLM.OPT.CONV.AC.STMT" : @FM : "BLM.OPT.CONV.AC.STMT.HIS" : @FM : "BLM.OPT.CONV.DE.ADDRESS" : @FM : "BLM.OPT.CONV.DE.ADDRESS.HIS" : @FM : "BLM.OPT.CONV.FT.RTN" : @FM : "BLM.OPT.CONV.FT.RTN.HIS" : @FM : "BLM.OPT.CONV.LIMIT" : @FM : "BLM.OPT.CONV.LIMIT.HIS"

    W.NB.SERVICES.TO.CHECK = DCOUNT(W.CONVSVC.SERVICE, @FM)
    
    W.NR.TOTAL.REC= W.NR.TOTAL.REC + W.NB.SERVICES.TO.CHECK
    
    RETURN
********************************************************************************
PROCESS:
********************************************************************************
    NB.REC.ID = DCOUNT(W.CONV.IDS,@FM)
    
    FOR I = 1 TO NB.REC.ID
        W.ID = W.CONV.IDS<I>
    
        R.REC = ''
        YERR = ''
        CALL F.READ(FN.CONVERSION.PGMS,W.ID,R.REC,F.CONVERSION.PGMS,YERR)
        
        IF YERR = '' THEN
            NB.RECS = DCOUNT(R.REC<EB.CON.RUN.PGM>, @VM)
            FOR J = 1 TO NB.RECS
*                                             
                W.NR.TOTAL.REC = W.NR.TOTAL.REC + 1
*
                IF R.REC<EB.CON.RUN.PGM,J> = 2 THEN
                     W.NR.REC.PROC = W.NR.REC.PROC + 1
                END ELSE 
                    IF R.REC<EB.CON.RUN.PGM,J> = 0 THEN
                        W.NR.REC.NOT.SCHED.TO.RUN = W.NR.REC.NOT.SCHED.TO.RUN + 1
                    END
                END
            NEXT J
        END
    NEXT I
*   
    FOR K = 1 TO W.NB.SERVICES.TO.CHECK
        W.SERVICE.FIN = 0
        W.SERVICE.NAME = W.CONVSVC.SERVICE<K>
        GOSUB CHECK.SERVICE.STATUS
    NEXT K
      
    CRT W.NR.REC.PROC : " of " : (W.NR.TOTAL.REC-W.NR.REC.NOT.SCHED.TO.RUN) : " processed.(" : FMT((W.NR.REC.PROC / (W.NR.TOTAL.REC-W.NR.REC.NOT.SCHED.TO.RUN)) * 100,'R2') : "%)" 

     
    RETURN
    
********************************************************************************
CHECK.SERVICE.STATUS:
********************************************************************************
    R.TSA.SERVICE = ''
    YERR = ''
    CALL F.READ(FN.TSA.SERVICE,W.SERVICE.NAME,R.TSA.SERVICE,F.TSA.SERVICE,YERR)
    IF YERR THEN 
        CRT "NOT ABLE TO READ TSA.SERVICE FOR :" : W.SERVICE.NAME : " ERROR=" : YERR
        RETURN
    END
*   
    IF R.TSA.SERVICE<TS.TSM.SERVICE.CONTROL> = 'START' THEN
        RETURN
    END
*    
    R.BATCH = ''
    YERR = ''
    CALL F.READ(FN.BATCH,W.SERVICE.NAME,R.BATCH,F.BATCH,YERR)
    IF YERR THEN 
        CRT "NOT ABLE TO READ BATCH FOR :" : W.SERVICE.NAME : " ERROR=" : YERR
        RETURN
    END
*
    IF R.BATCH<BAT.PROCESS.STATUS> = '3' THEN
        CRT "WARNING: BATCH " : W.SERVICE.NAME : " On hold or in error!!!!!"
        RETURN
    END 
    
    W.NR.REC.PROC = W.NR.REC.PROC + 1    
    
    RETURN
    
END

