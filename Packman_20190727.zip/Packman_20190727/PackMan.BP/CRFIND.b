*-----------------------------------------------------------------------------
* <Rating>605</Rating>
*-----------------------------------------------------------------------------
    PROGRAM CRFIND

*------------------------------------------------------------------------------*
*                                                                              *
* Program to search through a file/savedlist to see if a particular string     *
* exists                                                                       *
*                                                                              *
* Date        Who   Ver  Description                                           *
* ----        ---   ---  -----------                                           *
* 02 Feb 2008 Ches  1.0  Initial version                                       *
*                                                                               *
*------------------------------------------------------------------------------*

! start by reading the input buffer

    SEARCH.LIST   = SENTENCE(1)
    SEARCH.STRING = SENTENCE(2)
    OPTION.LIST   = FIELD ( SENTENCE(3), '(', 2 )

    IF SEARCH.LIST = '' THEN
        CRT
        CRT 'CRFIND <search-list> <search-string> (<option-list>'
        CRT
        CRT 'e.g. >CRFIND SEARCH.LIST R.CATEGORY'
        CRT
        CRT 'where search-list = a saved list of files or items to be checked'
        CRT '                    e.g. GG.BP'
        CRT '                    or   GG.BP>AC.NOS.STMT.GG'
        CRT '                    or   F.ENQUIRY>LD.MARGIN.RPT.GG'
        CRT
        CRT '    search-string = string to be searched for'
        CRT '                    e.g. R.CATEGORY or Customer_not_found'
        CRT '                    nb.  use "_"  as a separator for multiple word searches'
        CRT
        CRT "   option-list '' = file                {as specified in search-list}"
        CRT '               C  = output to COMO file {saved with same name as search-list}'
        CRT '               L  = use search list     {as specified in search-list}'
        CRT
    END ELSE

! now get the select list...

        OPEN '&SAVEDLISTS&' TO F.SAVEDLISTS ELSE STOP 201,'&SAVEDLISTS&'

! ...and then get each file to be processed

        IF INDEX(SEARCH.STRING, '_', 1) THEN
            SEARCH.STRING = CHANGE(SEARCH.STRING, '_', ' ')
        END

        WRITE.TO.COMO     = (OPTION.LIST = 'C')
        FULL.SEARCH.START = (OPTION.LIST = 'CFS')
        FULL.SEARCH.END   = (OPTION.LIST = 'CFE')

        IF WRITE.TO.COMO OR FULL.SEARCH.START THEN
            TIME.NOW    = TIME() 'MTS'
            THIS.MOMENT = CHANGE(TIME.NOW, ':', '-')
            THIS.DAY    = OCONV(DATE(), 'D2/')
            THIS.DAY    = '20' : THIS.DAY[7,2] : THIS.DAY[1,2] : THIS.DAY[4,2]

            COMO.NAME = 'CRFIND_' : SEARCH.LIST : '_' : THIS.DAY : '_' : THIS.MOMENT

            EXECUTE 'COMO ON ':COMO.NAME
        END

        IF OPTION.LIST[1,2] = '(C' ELSE
            CRT @(-1)
        END

        IF OPTION.LIST NE 'L' THEN
            R.FILE.LIST = SEARCH.LIST
        END ELSE
            READ R.FILE.LIST FROM F.SAVEDLISTS, SEARCH.LIST ELSE NULL
        END

        NO.OF.FILES   = DCOUNT(R.FILE.LIST, @FM)

        FOR A = 1 TO NO.OF.FILES
            FILE.NAME = R.FILE.LIST<A>
            OBJECTS   = INDEX ( FILE.NAME, '>', 1 )

            IF A = 1 AND OBJECTS THEN
                CRT 'Searching List'
                CRT '--------------'
            END

            GOSUB CHECK.FILE
        NEXT A


        CRT 'Finished'
        CRT

        IF WRITE.TO.COMO OR FULL.SEARCH.END THEN
            EXECUTE 'COMO OFF'
            CRT '***  Output file ':SEARCH.LIST:' written to &COMO&  ***'
            CRT
        END
    END

    STOP


! check each file

*----------
CHECK.FILE:
*----------

    IF OBJECTS THEN
        RECORD.ID = FIELD( FILE.NAME, '>', 2)
        FILE.NAME = FIELD( FILE.NAME, '>', 1)

        OPEN FILE.NAME TO F.FILE ELSE STOP 201,FILE.NAME

        GOSUB CHECK.RECORD
        CRT
    END ELSE
        CRT
        CRT 'Checking ':FILE.NAME
        CRT STR('-', LEN(FILE.NAME) + 9)

        OPEN FILE.NAME TO F.FILE ELSE STOP 201,FILE.NAME

        SELECT F.FILE

        LOOP
            READNEXT RECORD.ID ELSE RECORD.ID = ''
        WHILE RECORD.ID DO
            IF RECORD.ID[1,1] = '$' OR RECORD.ID[3] = '.so' ELSE

!!!
!CRT 'Processing : ':RECORD.ID
!!!
                GOSUB CHECK.RECORD

                IF DISPLAYED THEN CRT
            END
        REPEAT
    END

    RETURN


! check each record

*------------
CHECK.RECORD:
*------------

    READ R.RECORD FROM F.FILE, RECORD.ID THEN
        B              = 0
        DISPLAYED      = 0
        LAST.ATTRIBUTE = ''
        DISPLAY.MASK   = 'L#':LEN(FILE.NAME) + 2

        LOOP
            B += 1
            FOUND.STRING = 0 + INDEX( R.RECORD, SEARCH.STRING, B )
        WHILE FOUND.STRING DO

            ATTRIBUTE = DCOUNT ( R.RECORD [ 1, FOUND.STRING ], @FM )

            IF ATTRIBUTE = LAST.ATTRIBUTE ELSE
                GOSUB FORMAT.LINE
                CRT FILE.NAME DISPLAY.MASK : RECORD.ID 'L#50 ' : '-> ' : ATTRIBUTE 'R%4' : '  ' : DISPLAY.LINE
                DISPLAYED += 1
            END

            LAST.ATTRIBUTE = ATTRIBUTE
        REPEAT
    END

    RETURN


! highlight the text in the line (or don't if going to a COMO)

*-----------
FORMAT.LINE:
*-----------

    SEARCH.LINE  = TRIM(R.RECORD<ATTRIBUTE>,' ', 'L') 'L#95'
    START.POS    = INDEX ( SEARCH.LINE, SEARCH.STRING, 1 )

    IF START.POS THEN
        IF WRITE.TO.COMO THEN
            DISPLAY.LINE = SEARCH.LINE [1 ,START.POS-1 ] : SEARCH.STRING
            DISPLAY.LINE := SEARCH.LINE [ START.POS + LEN(SEARCH.STRING) , 95 - (START.POS + LEN(SEARCH.STRING)) ]
        END ELSE
            DISPLAY.LINE = SEARCH.LINE [1 ,START.POS-1 ] : @(-15) : SEARCH.STRING
            DISPLAY.LINE := @(-16) : SEARCH.LINE [ START.POS + LEN(SEARCH.STRING) , 95 - (START.POS + LEN(SEARCH.STRING)) ]
        END
    END ELSE
        DISPLAY.LINE = SEARCH.LINE
    END

    RETURN

END
