*-----------------------------------------------------------------------------
* <Rating>315</Rating>
*-----------------------------------------------------------------------------
**    $PACKAGE Tool_Packman

    PROGRAM PACK.MAN.LAUNCHER
*------------------------------------------------------------------------------*
*                                                                              *
* Program to launch T24 PACK.MAN programs . This program is using the          *
* recommended solution used by T24.LAUNCHER.                                   *
*
*for the moment use just first 3 params                                                                              *
*     Parameter 1 = valid T24 user for audit                                   *
*     Parameter 2 = SAVE or RESTORE1/RESTORE2/RESTORE3                         *
*     Parameter 3 = path of CHANGE_LIST in SAVEDLISTS format i.e. A1>V1        *
*not used:
*     Parameter 4 = suffix for the pack name WEB/NONWEB/PACK                   *
*     Parameter 5 = to tar the package TAR                                     *
*                                                                              *
* Date        Who   Ver  Description                                           *
* ----        ---   ---  -----------                                           *
*------------------------------------------------------------------------------*

    $INSERT I_COMMON
    $INSERT I_EQUATE

    $INSERT I_F.TSA.SERVICE
    $INSERT I_F.PGM.FILE
    $INSERT I_F.USER
    $INSERT I_F.T24.W.PACK.MAN

    GOSUB INITIALISE

    GOSUB CHECK.PARAMETER

    INSTALL.OLD = SENTENCE(4)
    IF INSTALL.OLD NE "N" THEN
        INSTALL.OLD = "Y"
    END  

    IF NOT(RETURN.CODE) THEN
        BEGIN CASE
            CASE PROCESS.MODE = 'SAVE'
                GOSUB RUN.T24.COMMAND.SAVE
            CASE PROCESS.MODE[1,7] = 'RESTORE'
                W.RUN.FLAG = "Y"
                W.SAVE.NB.ERROR = 0
                LOOP
                WHILE W.RUN.FLAG EQ "Y"
                    GOSUB RUN.T24.COMMAND.RESTORE
                    IF PROCESS.MODE[1,8] NE 'RESTORE3' THEN
                        W.RUN.FLAG = "N"
                    END ELSE
                        IF RETURN.CODE NE '13' THEN
                            W.RUN.FLAG = "N"                                                    
                        END ELSE
                           IF W.SAVE.NB.ERROR EQ 0 OR W.SAVE.NB.ERROR NE NB.ERRORS THEN
                               W.SAVE.NB.ERROR = NB.ERRORS
                           END ELSE
                               W.RUN.FLAG = "N"    
                           END
                        END
                    END                    
                REPEAT
        END CASE 
    END
    GOSUB WRITE.COMO

    EXIT(RETURN.CODE)
*
*------------------------------------------------------------------------------
*
RUN.T24.COMMAND.RESTORE:
*
*
    ID.PACK.MAN = FIELD(CHANGE.LIST,SEP.REP, DCOUNT(CHANGE.LIST,SEP.REP)) ; * TM_100503 s
    IF ID.PACK.MAN[1, 4] # "TAF-" THEN
        ID.PACK.MAN = "TAF-" : THIS.DAY :'.': CHANGE(TIME.NOW, ':', '') :'.': PACK.TYPE
    END ; * TM_100503 e
    OFS.MESSAGE  = "T24.W.PACK.MAN,/I/PROCESS/1/0,"               : ","
    OFS.MESSAGE := ID.PACK.MAN                                    : "," ; * TM_20100503
    OFS.MESSAGE := "DIRECTORY=":DIRECTORY.NAME                    : "," ; * TM_20100503, TM_20100830
    OFS.MESSAGE := "ACTION=":PROCESS.MODE                         : ","
    OFS.MESSAGE := "TOP.LEVEL.ITEM=ALL"                           : "," ; * TM_20100503
*
    READ R.PACK.MAN.OLD FROM F.T24.W.PACK.MAN, ID.PACK.MAN THEN
*check if the pack was already installed. this check has to be done just for RESTORE1
        IF PROCESS.MODE EQ "RESTORE1" THEN
            PACK.INSTALL.DATE = "20" : R.PACK.MAN.OLD<T24.PM.DEF.DATE.TIME>[1,6]
            IF THIS.DAY GT PACK.INSTALL.DATE THEN 
                R.COMO := "THIS PACK WAS ALREADY INSTALLED ON :" : PACK.INSTALL.DATE : "!Are you sure you want to install this pack again?[Y/N]"
*                
                IF INSTALL.OLD NE "Y" THEN
                    R.COMO := "STOP!"
                    RETURN.CODE = '13'
                    RETURN
                END           
            END       
        END        
    END ELSE 
        R.PACK.MAN.OLD = ""
    END ; * TM_20100503 e

    CALL EB.TRANS("START",RETURN.MESSAGE)
    CALL OFS.GLOBUS.MANAGER(OFSS.ID,OFS.MESSAGE)
    CALL EB.TRANS("END",RETURN.MESSAGE)

    READ R.PACK.MAN.NEW FROM F.T24.W.PACK.MAN, ID.PACK.MAN ELSE ; * TM_20100503 s
        R.PACK.MAN.NEW = ""
    END
    R.REPORT = ""
    ID.REPORT = ""
    IF DCOUNT(R.PACK.MAN.OLD<T24.PM.DEF.HISTO.LOG>, VM) + 1 = DCOUNT(R.PACK.MAN.NEW<T24.PM.DEF.HISTO.LOG>, VM) THEN
        ID.REPORT = R.PACK.MAN.NEW<T24.PM.DEF.HISTO.LOG, DCOUNT(R.PACK.MAN.NEW<T24.PM.DEF.HISTO.LOG>, VM)>
        READ R.REPORT FROM F.SAVEDLISTS, ID.REPORT ELSE
            NULL
        END
    END ; * TM_20100503 e

    RETURN.VALUE = FIELD(OFS.MESSAGE,',',1) ; * TM_140219
    RETURN.VALUE = FIELD(RETURN.VALUE,'/',3) ; * TM_140219
    BEGIN CASE
        CASE RETURN.VALUE # 1 AND NOT(INDEX(OFS.MESSAGE,'LIVE RECORD NOT CHANGED',1)) ; * TM_140219
            R.COMO := 'Result of process failed ':OFS.MESSAGE:' - ' : TIMEDATE() : FM : FM
            RETURN.CODE = '13'
            CRT 'Process failed : ' : OFS.MESSAGE : ' - Please check COMO '
            RETURN
        CASE R.REPORT<1> # "No error during installation"
            R.COMO := 'Process failed : error report by PACK.MAN - Please check &SAVEDLISTS& ' : ID.REPORT : ' - ' : TIMEDATE() : FM : FM
            RETURN.CODE = '13'
            CRT 'Process failed : error report by PACK.MAN - Please check &SAVEDLISTS& ' : ID.REPORT
            CRT R.REPORT<1>
            NB.ERRORS=FIELDS(R.REPORT<1>," ",1)
            RETURN
        CASE OTHERWISE             
            R.COMO := 'Result of process ':OFS.MESSAGE:' - ' : TIMEDATE() : FM : FM
            CRT 'Process successfully : ' : ID.PACK.MAN ; * TM_20100503
    END CASE
*
    RETURN
*
*------------------------------------------------------------------------------
*
RUN.T24.COMMAND.SAVE:
*
    IF ID.PACK.MAN = '' THEN
        ID.PACK.MAN = THIS.DAY :'.': CHANGE(TIME.NOW, ':', '') :'.': PACK.TYPE
    END
    OFS.MESSAGE  = "T24.W.PACK.MAN,/I/PROCESS/1/0,"               : ","
    OFS.MESSAGE := ID.PACK.MAN                                    : ","
    OFS.MESSAGE := "DIRECTORY=./LEUMI.PACKS/":ID.PACK.MAN              : ","
    OFS.MESSAGE := "SELECT.LIST=":CHANGE.LIST                     : ","
*
    CALL EB.TRANS("START",RETURN.MESSAGE)
    CALL OFS.GLOBUS.MANAGER(OFSS.ID,OFS.MESSAGE)
    CALL EB.TRANS("END",RETURN.MESSAGE)

    RETURN.VALUE = FIELDS(FIELDS(OFS.MESSAGE,',',1),'/',3)

    BEGIN CASE
        CASE RETURN.VALUE # 1 AND NOT(INDEX(OFS.MESSAGE,'LIVE RECORD NOT CHANGED',1)) ; * TM_140219
            R.COMO := 'Result of process failed ':OFS.MESSAGE:' - ' : TIMEDATE() : FM : FM
            RETURN.CODE = '13'
            CRT 'Process failed : ' : OFS.MESSAGE : ' - Please check COMO '
            RETURN
        CASE OTHERWISE
            R.COMO := 'Result of process ':OFS.MESSAGE:' - ' : TIMEDATE() : FM : FM
    END CASE
*
    IF TAR.IT = 'TAR' THEN
        EXEC.CMD = "tar cvf TEMP/TAF-" : ID.PACK.MAN : ".tar TEMP/TAF-" : ID.PACK.MAN
        EXEC.CMD = 'SH -c "' : EXEC.CMD : '"'
        EXECUTE EXEC.CMD CAPTURING RIEN
        CRT 'Process successfully : TEMP/TAF-' : ID.PACK.MAN : '.tar'
    END ELSE
        CRT 'Process successfully : ./LEUMI.PACKS/' : ID.PACK.MAN
    END
*
    RETURN
*
*------------------------------------------------------------------------------
*
INITIALISE:
*
    RETURN.CODE = ''
*
    OS.TYPE = SYSTEM(1017)
    IF OS.TYPE <> 'UNIX' THEN
        OS.TYPE = 'NT'
    END
    IF OS.TYPE = "UNIX" THEN
        SEP.REP = "/"
    END ELSE
        SEP.REP = "\"
    END
    W.LOCAL.DIR = '.' : SEP.REP

    OPEN W.LOCAL.DIR:'&COMO&' TO F.COMO ELSE
        STOP 201,'CANT OPEN &COMO&'
    END
    OPEN 'F.USER' TO F.USER ELSE
        STOP 201,'CANT OPEN F.USER'
    END
*
    OFSS.ID = 'AUTH':'.':'1'
    OFSS.ID = 'OFS.LOAD'
*
    YTIME = OCONV(TIME(),'MTS')
    THIS.MOMENT = YTIME[1,2]:YTIME[4,2]:YTIME[7,2]
    THIS.DAY    = OCONV(DATE(), 'D2/')
    THIS.DAY    = '20' : THIS.DAY[7,2] : THIS.DAY[1,2] : THIS.DAY[4,2]
    COMO.ID     = 'PACK.MAN.LAUNCHER_' : THIS.DAY : '_' : THIS.MOMENT

    R.COMO      = ''
    R.COMO     := 'Start T24 PACK.MAN Launcher process - ' : TIMEDATE() : FM : FM
    R.COMO     := 'User Name    = ':SENTENCE(1) : FM
    R.COMO     := 'Process Mode  = ':SENTENCE(2) : FM
    R.COMO     := 'Change list path = ':SENTENCE(3) : FM : FM
*
*    HUSH ON
*    EXECUTE "EBS.TERMINAL.SELECT EBS-JBASE"
*    HUSH OFF

    CALL T24.INITIALISE
    R.COMO := 'T24 initialised - ' : TIMEDATE() : FM : FM

    CALL S.INITIALISE.COMMON
    R.COMO := 'T24 Common Variables Initialised - ' : TIMEDATE() : FM : FM

    CALL LOAD.COMPANY ('IL0010001')
    R.COMO := 'Loaded T24 Company IL0010001 - ' : TIMEDATE() : FM : FM

    FN.T24.W.PACK.MAN = "F.T24.W.PACK.MAN" ; F.T24.W.PACK.MAN = "" ; * TM_20100503 s
    CALL OPF (FN.T24.W.PACK.MAN, F.T24.W.PACK.MAN)
    FN.SAVEDLISTS = W.LOCAL.DIR:"&SAVEDLISTS&" ; F.SAVEDLISTS = ""
    CALL OPF (FN.SAVEDLISTS, F.SAVEDLISTS) ; * TM_20100503 e
*
    RUNNING.UNDER.BATCH = 1
*
    RETURN
*

*------------------------------------------------------------------------------
*
CHECK.PARAMETER:
*
    IF SENTENCE(3) = '' THEN
        CRT "change_list_path missing"
        GOSUB PRINT.THE.USAGE.OF.THE.COMMAND
        RETURN.CODE = '13'
        RETURN
    END
*
    OPERATOR = SENTENCE(1)
    IF OPERATOR = "" THEN
        CRT "t24_user missing"
        GOSUB PRINT.THE.USAGE.OF.THE.COMMAND
        RETURN.CODE = '13'
        RETURN
    END
    READ R.USER FROM F.USER, OPERATOR ELSE
        R.USER = ''
    END
    IF R.USER = '' THEN
        MSG.ERR = 'Read USER record for ' : OPERATOR : ' failed'
        CRT MSG.ERR
        R.COMO := MSG.ERR : ' - ' : TIMEDATE() : FM : FM
        GOSUB PRINT.THE.USAGE.OF.THE.COMMAND
        RETURN.CODE = '13'
        RETURN
    END ELSE
        R.COMO := 'Read USER record for ' : R.USER<EB.USE.USER.NAME> : ' - ' : TIMEDATE() : FM : FM
    END
*
    PROCESS.MODE = SENTENCE(2)
    IF PROCESS.MODE <> 'RESTORE1' AND PROCESS.MODE <> 'RESTORE2' AND PROCESS.MODE <> 'RESTORE3' AND PROCESS.MODE <> 'SAVE' THEN
        MSG.ERR = 'Check the process mode ' : PROCESS.MODE : ' not supported'
        CRT MSG.ERR
        R.COMO := MSG.ERR : ' - ' : TIMEDATE() : FM : FM
        GOSUB PRINT.THE.USAGE.OF.THE.COMMAND
        RETURN.CODE = '13'
        RETURN
    END ELSE
        R.COMO := 'Check the process mode ' : PROCESS.MODE : ' - ' : TIMEDATE() : FM : FM
    END
*
    CHANGE.LIST = SENTENCE(3)
    IF PROCESS.MODE = 'SAVE' THEN
        MSG.ERR = ''
        GOSUB CHECK.CHANGE.LIST.NAME
        IF MSG.ERR THEN
            CRT MSG.ERR
            CRT '        format name : TAF-<YYYYMMDD><XXXXXN.FS>.changelog'
            CRT '        where XXXXX - 5 characters - about domain of dev'
            CRT '        N numeric - seq. from 1 to 9'
            CRT '        F -first name of dev'
            CRT '        S- second name'
            R.COMO := MSG.ERR : ' - ' : TIMEDATE() : FM : FM
            RETURN.CODE = '13'
            RETURN
        END
        SAVEDLISTS.NAME = CHANGE.LIST
        GOSUB EXTRACT.LIST.PACK
    END
    IF PROCESS.MODE[1,7] = 'RESTORE' THEN
        NB.BACKSLASH = COUNT(CHANGE.LIST,'\')
        NB.SLASH = COUNT(CHANGE.LIST,'/')
        *
        IF NB.BACKSLASH NE 0 OR NB.SLASH NE 0 THEN
            IF OS.TYPE = "UNIX" THEN
                CHANGE '\' TO '/' IN CHANGE.LIST
                NB.SLASH = DCOUNT(CHANGE.LIST,'/')
                PACK.NAME = FIELDS(CHANGE.LIST,"/",NB.SLASH)
*                DIRECTORY.NAME = CHANGE.LIST[1,LEN(CHANGE.LIST) - LEN(PACK.NAME) - 1]
            END ELSE
                CHANGE '/' TO '\' IN CHANGE.LIST
                NB.BACKSLASH = DCOUNT(CHANGE.LIST,'\')
                PACK.NAME = FIELDS(CHANGE.LIST,"\",NB.BACKSLASH)
*                DIRECTORY.NAME = CHANGE.LIST[1,LEN(CHANGE.LIST) - LEN(PACK.NAME) - 1]
            END
            DIRECTORY.NAME = CHANGE.LIST
        END ELSE
            DIRECTORY.NAME = "." : SEP.REP : "LEUMI.PACKS" : SEP.REP : CHANGE.LIST
        END

        OPEN DIRECTORY.NAME TO F.DIRECTORY.NAME ELSE
            ERROR.FILE = '1'
        END
        IF ERROR.FILE  THEN
            MSG.ERR = 'Check the directory ' : DIRECTORY.NAME : ' failed'
            CRT MSG.ERR
            R.COMO := MSG.ERR : ' - ' : TIMEDATE() : FM : FM
            GOSUB PRINT.THE.USAGE.OF.THE.COMMAND
            RETURN.CODE = '13'
            RETURN
        END ELSE
            R.COMO := 'Check the directory ' : DIRECTORY.NAME : ' - ' : TIMEDATE() : FM : FM
        END
    END
    IF PROCESS.MODE[1,7] = 'RESTORE' THEN
        COMMAND = 'SELECT ':DIRECTORY.NAME
        *        EXECUTE COMMAND CAPTURING OUTPUT
        CALL EB.READLIST(COMMAND,RECORD.LIST,"","","")
        *        READLIST RECORD.LIST ELSE RECORD.LIST = ''
        R.SAVEDLISTS.NAME = RECORD.LIST
    END
    IF ERROR.FILE  THEN
        MSG.ERR = 'Check the file ' : SAVEDLISTS.NAME : ' from ' :DIRECTORY.NAME:' failed'
        CRT MSG.ERR
        R.COMO := MSG.ERR : ' - ' : TIMEDATE() : FM : FM
        GOSUB PRINT.THE.USAGE.OF.THE.COMMAND
        RETURN.CODE = '13'
        RETURN
    END ELSE
        R.COMO := 'Check the file ' : SAVEDLISTS.NAME : ' from ' :DIRECTORY.NAME:' - ' : TIMEDATE() : FM : FM
    END
    IF PROCESS.MODE = 'SAVE' THEN
        FOR I = 1 TO DCOUNT(R.SAVEDLISTS.NAME,FM)
            IF INDEX(R.SAVEDLISTS.NAME<I>,'>',1) THEN
                * FILE.NAME<-1> = FIELD(R.SAVEDLISTS.NAME<I>,'>',1) ; * TM_20100503
                * RECORD.NAME<-1> = FIELD(R.SAVEDLISTS.NAME<I>,'>',2) ; * TM_20100503
            END ELSE
                MSG.ERR = 'Checking the file ' : SAVEDLISTS.NAME : ' line ' :I:' failed'
                CRT MSG.ERR
                R.COMO := MSG.ERR : ' - ' : TIMEDATE() : FM : FM
                GOSUB PRINT.THE.USAGE.OF.THE.COMMAND
                RETURN.CODE = '13'
                RETURN
            END
        NEXT I
    END
    IF PROCESS.MODE[1,7] = 'RESTORE' THEN
        FOR I = 1 TO DCOUNT(R.SAVEDLISTS.NAME,FM)
            IF INDEX(R.SAVEDLISTS.NAME<I>,'-',1) ELSE
                MSG.ERR = 'Checking the file ' : SAVEDLISTS.NAME : ' line ' :I:' failed'
                CRT MSG.ERR
                R.COMO := MSG.ERR : ' - ' : TIMEDATE() : FM : FM
                GOSUB PRINT.THE.USAGE.OF.THE.COMMAND
                RETURN.CODE = '13'
                RETURN
            END
        NEXT I
    END
*
*    PACK.TYPE = SENTENCE(4)
*    IF NOT(PACK.TYPE) THEN
*        *default value for PACK.TYPE is NONWEB
*        PACK.TYPE = 'NONWEB'
*    END
*    IF PACK.TYPE[1,3] <> 'WEB' AND PACK.TYPE[1,6] <> 'NONWEB' AND PACK.TYPE[1,4] <> 'PACK' THEN
*        MSG.ERR = 'Check the pack type ' : PACK.TYPE : ' mandatory for SAVE process mode'
*        CRT MSG.ERR
*        R.COMO := MSG.ERR : ' - ' : TIMEDATE() : FM : FM
*        GOSUB PRINT.THE.USAGE.OF.THE.COMMAND
*        RETURN.CODE = '13'
*        RETURN
*    END ELSE
*        R.COMO := 'Check the pack type ' : PACK.TYPE : ' - ' : TIMEDATE() : FM : FM
*    END
**
*    TAR.IT = SENTENCE(5)
*    IF PROCESS.MODE = 'SAVE' AND TAR.IT <> '' AND TAR.IT <> 'TAR' THEN
*        MSG.ERR = 'Check the tar type ' : TAR.IT : ' not supported'
*        CRT MSG.ERR
*        R.COMO := MSG.ERR : ' - ' : TIMEDATE() : FM : FM
*        GOSUB PRINT.THE.USAGE.OF.THE.COMMAND
*        RETURN.CODE = '13'
*        RETURN
*    END ELSE
*        R.COMO := 'Check the tar type ' : TAR.IT : ' - ' : TIMEDATE() : FM : FM
*    END
*

    RETURN

*
*------------------------------------------------------------------------------
*
CHECK.CHANGE.LIST.NAME:
    IF CHANGE.LIST[1,4] NE 'TAF-' THEN
        MSG.ERR = 'INCORRECT FILE NAME: tha change log file should start with TAF-'
        RETURN
    END
*
*   IF CHANGE.LIST[5,8] LT 20150701 OR CHANGE.LIST[5,8] GT 20170701 THEN
*       MSG.ERR = 'INCORRECT FILE NAME: INVALID DATE'
*       RETURN
*   END
*
    IF (NUM(CHANGE.LIST[18,1]) NE NUMERIC) CHANGE.LIST[18,1] GE 1 AND CHANGE.LIST[18,1] LE 9 THEN
        MSG.ERR = 'INCORRECT FILE NAME: INVALID SEQ NUMBER'
        RETURN
    END
*
    IF FIELDS(CHANGE.LIST,".",3) NE 'changelog' THEN
        MSG.ERR = 'INCORRECT FILE NAME: the file name should have the extension .changelog'
        RETURN
    END
    RETURN
*
*------------------------------------------------------------------------------
*
WRITE.COMO:
*
    READU DUMMY FROM F.COMO, COMO.ID ELSE
        NULL
    END
    R.COMO := FM : 'Finished PACK MAN Launcher process - ' : TIMEDATE() : FM

    WRITE R.COMO TO F.COMO, COMO.ID ON ERROR
        RELEASE F.COMO, COMO.ID
    END
*
    RETURN
*
*------------------------------------------------------------------------------
*
PRINT.THE.USAGE.OF.THE.COMMAND:
*
    CRT ' '
    CRT 'Illegal option   : "':SENTENCE(0):' ':SENTENCE(1):' ':SENTENCE(2):' ':SENTENCE(3):'"'
    CRT ' '
    CRT 'Usage            : PACK.MAN.LAUNCHER <t24_user> <process_mode> <change_list_path> <pack_type> <tar_pack>'
    CRT ' '
    CRT 't24_user         : a valid T24 user from the USER table'
    CRT 'process_mode     : only on of the following options SAVE, RESTORE1,'
    CRT '                   RESTORE2, RESTORE3'
    CRT 'change_list_path : a valide file name path which contains the list of '
    CRT '                   object to save in the format of the savedlists i.e.'
    CRT '                   OR a directory that contains the file to restore '
    CRT 'pack_type        : for both SAVE/RESTOREx mode use as a suffix WEB/NONWEB  '
    CRT '                   or PACK'
    CRT 'tar_pack         : only for SAVE mode to TAR cvf the generated pack '
    CRT ' '
    CRT 'exemple          : '
    CRT 'PACK.MAN.LAUNCHER ABOU.1 SAVE /tmp/mylist.txt NONWEB'
    CRT 'PACK.MAN.LAUNCHER EXPLOIT.1 SAVE /temenos/t24/dev01/bnk/abou.txt WEB TAR'
    CRT 'PACK.MAN.LAUNCHER EXPLOIT.1 RESTORE1 /temenos/t24/dev01/bnk/mydir NONWEB'
    CRT 'PACK.MAN.LAUNCHER EXPLOIT.1 RESTORE2 /temenos/t24/dev01/bnk/mydir NONWEB'
    CRT 'PACK.MAN.LAUNCHER EXPLOIT.1 RESTORE3 /temenos/t24/dev01/bnk/mydir NONWEB'
    CRT ' '
    GOSUB WRITE.COMO
*
    EXIT(RETURN.CODE)
*
    RETURN
*-----------------------------------------------------------------------------
*** <region name= EXTRACT.LIST.PACK>
EXTRACT.LIST.PACK:
*** <desc> EXTRACT</desc>
    W.TAG.START.PACK = '[START.PACK.LIST]'
    W.TAG.END.PACK = '[END.PACK.LIST]'
    W.FILE.NAME = ''
    W.RECORD.NAME = ''
    W.REC.PACK = ''
*
    ID.PACK.MAN = FIELDS(CHANGE.LIST,'.changelog',1)
    CHANGELOG.FILE = CHANGE.LIST
    FN.PACK.DIR = "LEUMI.PACKS"
    F.PACK.DIR = ""

    CALL OPF (FN.PACK.DIR, F.PACK.DIR)

    READ R.FILE.CHANGELOG FROM F.PACK.DIR, CHANGELOG.FILE ELSE
        CRT 'MISSING FILE ' : CHANGELOG.FILE : ' IN LEUMI.PACKS'
        GOSUB WRITE.COMO
        *
        EXIT(RETURN.CODE)
    END

    LOCATE W.TAG.START.PACK IN R.FILE.CHANGELOG<1> SETTING POS.TAG.START ELSE
    CRT 'MISSING TAG: ' : W.TAG.START.PACK
    GOSUB WRITE.COMO
*
    EXIT(RETURN.CODE)

    END
*
    I = POS.TAG.START + 1
    LOOP
    WHILE NOT(INDEX(R.FILE.CHANGELOG<I>,W.TAG.END.PACK,1))
        IF INDEX(R.FILE.CHANGELOG<I>,'>',1) THEN
            W.FILE.NAME.REC = FIELD(R.FILE.CHANGELOG<I>,'>',1)
            CHANGE " " TO "" IN W.FILE.NAME.REC
            W.RECORD.NAME.REC = FIELD(R.FILE.CHANGELOG<I>,'>',2)
            CHANGE " " TO "" IN W.RECORD.NAME.REC
            W.REC.PACK<-1> = W.FILE.NAME.REC : '>' : W.RECORD.NAME.REC
        END
        I=I+1
    REPEAT
*
    IF NOT(W.REC.PACK) THEN
        CRT 'EMPTY PACK LIST!'
        GOSUB WRITE.COMO
        *
        EXIT(RETURN.CODE)
    END

    CHANGE.LIST = ID.PACK.MAN : '.LIST'
    WRITE W.REC.PACK TO F.SAVEDLISTS, CHANGE.LIST ON ERROR
        CRT 'EMPTY CREATE THE LIST IN &SAVEDLISTS&!'
        GOSUB WRITE.COMO
        *
        EXIT(RETURN.CODE)
    END

    RETURN
*** </region>
