*-----------------------------------------------------------------------------
* <Rating>-2</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE CHECK.OFS.FIELDS
*-----------------------------------------------------------------------------
*<doc>
* Template for field definitions routine YOURAPPLICATION.FIELDS
*
* @author tcoleman@temenos.com
* @stereotype fields template
* @uses Table
* @public Table Creation
* @package infra.eb
* </doc> 
*-----------------------------------------------------------------------------
* Modification History :
*
* 19/10/07 - EN_10003543
*            New Template changes
*
* 14/11/07 - BG_100015736
*            Exclude routines that are not released
*-----------------------------------------------------------------------------
*** <region name= Header>
*** <desc>Inserts and control logic</desc>
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_DataTypes
*** </region>
*-----------------------------------------------------------------------------
    CALL Table.defineId("CHECK.OFS.ID", T24_String)        ;* Define Table id
    ID.F = "CHECK.OFS.ID1" ; ID.N = "15.1"
*-----------------------------------------------------------------------------
    neighbour = ''
    fieldName = 'INPUT'
    fieldLength = '65'
    fieldType = ''
    fieldType<1> = 'A'
    fieldType<7> = 'TEXT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour)

    neighbour = ''
    fieldName = 'OUTPUT'
    fieldLength = '65'
    fieldType = ''
    fieldType<1> = 'A'
    fieldType<7> = 'TEXT'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour)
    
    neighbour = ''
    fieldName = 'ERROR'
    fieldLength = '65'
    fieldType = ''
    fieldType = 'A'
    CALL Table.addFieldDefinition(fieldName, fieldLength, fieldType, neighbour)
*-----------------------------------------------------------------------------
    CALL Table.setAuditPosition          ;*Poputale audit information

*-----------------------------------------------------------------------------

*-----------------------------------------------------------------------------
    RETURN
*-----------------------------------------------------------------------------
END





