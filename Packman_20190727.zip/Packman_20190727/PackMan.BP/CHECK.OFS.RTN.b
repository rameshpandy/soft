*-----------------------------------------------------------------------------
* <Rating>-20</Rating>
*-----------------------------------------------------------------------------
* @desc
* @author Alin
* @create 20120731 
*    $PACKAGE Tool_Packman
    SUBROUTINE CHECK.OFS.RTN
  
    $INSERT I_COMMON 
    $INSERT I_EQUATE
*   $INSERT I_F.CHECK.OFS     
 
    $INSERT I_GTS.COMMON

    IF MESSAGE EQ 'VAL' THEN
        GOSUB INITIALISE
        GOSUB PROCESS.DATA
    END

    RETURN

*--------------------------------------------------------------------------
*INITIALISE
*--------------------------------------------------------------------------
INITIALISE:
    Y.INPUT.COMI = ''
    MESAG_OFS_BEGIN = "T24.W.PACK.MAN,AUTO/I/VALIDATE,//"

    OFS.SOURCE = 'OFS.LOAD'
    RETURN
*--------------------------------------------------------------------------

*--------------------------------------------------------------------------
*PROCESS.DATA
*--------------------------------------------------------------------------
PROCESS.DATA:

    Y.INPUT.COMI = R.NEW(1)
    SUBFIELD_1 = FIELD(R.NEW(1), CHAR(253), 1)

    IF SUBFIELD_1 NE COMI THEN
        RETURN
    END
    
    FINDSTR MESAG_OFS_BEGIN IN SUBFIELD_1 SETTING Abc,Bac THEN
    END ELSE
         R.NEW(2) = "Please use the message OFS generated with PackTool"
         RETURN           
    END

    theRequests = EREPLACE(Y.INPUT.COMI, CHAR(253), '')

    CALL OFS.GLOBUS.MANAGER(OFS.SOURCE, theRequests) 
      
    NR_COMMA = DCOUNT (theRequests, ",") 
    
    TRAIT_STRING = FIELD (theRequests, "," , I)
    
    FINDSTR "//1" IN TRAIT_STRING SETTING AA,BB THEN
         R.NEW(2) = "PACK LIST OK!"
         RETURN           
    END
    
    R.NEW(LCF.CHECK.OFS.OUTPUT) = ''
    FOR I =2 TO NR_COMMA 
	TRAIT_STRING = FIELD (theRequests, "," , I)
        R.NEW(LCF.CHECK.OFS.OUTPUT)=R.NEW(LCF.CHECK.OFS.OUTPUT) : VM : TRAIT_STRING
    NEXT I
  
   RETURN
END
*--------------------------------------------------------------------------





