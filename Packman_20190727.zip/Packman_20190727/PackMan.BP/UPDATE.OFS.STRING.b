*-----------------------------------------------------------------------------
* <Rating>100</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE UPDATE.OFS.STRING


    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.CATEGORY
    $INSERT I_OFS.MESSAGE.SERVICE.COMMON
    $INSERT I_GTS.COMMON


    CRT 'PLEASE ENTER THE PATH WITH OUT CSV ID '

    INPUT CSV.FILE.DIRECTORY

    CSV.FILE.DIRECTORY =TRIM(CSV.FILE.DIRECTORY)
    CRT 'PLEASE ENTER THE CSV FILE NAME'

    INPUT CSV.ID
    CSV.ID = TRIM(CSV.ID)
    EOF = ''
    ID.OFS.UPD =''

    FN.OFS.SOURCE = 'F.OFS.SOURCE'
    F.OFS.SOURCE = ''
    CALL OPF(FN.OFS.SOURCE, F.OFS.SOURCE)
    OFS$SOURCE.ID = 'OFS.LOAD'
    CALL F.READ(FN.OFS.SOURCE, OFS$SOURCE.ID, OFS$SOURCE.REC, F.OFS.SOURCE, ERR)

    Y.PATH = CSV.FILE.DIRECTORY
    Y.FILE = 'LOG.OFS_': CSV.ID : '_' : TODAY
    OPENSEQ Y.PATH,Y.FILE TO Y.FILE.PTR ELSE
        CREATE Y.FILE.PTR ELSE
            CRT 'UNABLE TO CREATE RECORD IN FILE'
            RETURN
        END
    END

    OFS.REC = ''
    OPENSEQ CSV.FILE.DIRECTORY,CSV.ID TO F.FILE1 ELSE CRT "CANNOT OPEN FILE"
    LOOP
        READSEQ REC FROM F.FILE1 THEN
            theRequests = REC
            theResponses =''
            requestCommitted = ''

            CALL OFS.BULK.MANAGER(theRequests, theResponses, requestCommitted)

            WRITESEQ theResponses : CHAR(10) APPEND TO Y.FILE.PTR
            ELSE
                CRT 'UNABLE TO WRITE TO THE FILE'
            END

            CRT theResponses
        END ELSE
            EOF = 1
        END
    UNTIL EOF

    REPEAT

    CLOSE Y.FILE.PTR

    RETURN


