*-----------------------------------------------------------------------------
* <Rating>-148</Rating>
*-----------------------------------------------------------------------------
    PROGRAM TOOL.FILE.CONTROL.CHANGE.CO.CODE
*-----------------------------------------------------------------------------
*<doc>
*  table.
* @author = AF
* @date = 05/2019
* @jira =
*</doc>
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FILE.CONTROL

*-----------------------------------------------------------------------------

    GOSUB INITIALISE
    IF W.ERR = '' THEN
        GOSUB PROCESS
    END 
        
    EXIT(RETURN.CODE)
    
********************************************************************************
INITIALISE:
********************************************************************************
* Open FILE.CONTROL table
    FN.FILE.CONTROL = 'F.FILE.CONTROL'
    F.FILE.CONTROL = ''
    CALL OPF(FN.FILE.CONTROL,F.FILE.CONTROL)

*    
    W.INI.CODE='US0010001'
    W.TO.CODE='IL0010001'    
*   
 
    W.ERR = ''
    
    RETURN
********************************************************************************
PROCESS:
********************************************************************************    
    SELECT.STATEMENT = 'SELECT ':FN.FILE.CONTROL 
    FILE.CONTROL.LIST.REC = ''
    LIST.NAME = ''
    SELECTED = ''
    SYSTEM.RETURN.CODE = ''
    CALL EB.READLIST(SELECT.STATEMENT,FILE.CONTROL.LIST.REC,LIST.NAME,SELECTED,SYSTEM.RETURN.CODE)

    Y.TSA.COUNT = DCOUNT(FILE.CONTROL.LIST.REC,@FM)
    FOR I=1 TO Y.TSA.COUNT

        Y.TSA.ID = FILE.CONTROL.LIST.REC<I>
        R.FILE.CONTROL = ''
        YERR = ''
        CALL F.READ(FN.FILE.CONTROL,Y.FILE.CONTROL.ID,R.FILE.CONTROL,F.FILE.CONTROL,YERR)
        IF YERR = '' AND R.FILE.CONTROL<EB.FILE.CO.CODE> EQ W.INI.CODE THEN
            R.FILE.CONTROL<EB.FILE.CO.CODE> = W.TO.CODE  
            CALL F.WRITE(FN.FILE.CONTROL,Y.FILE.CONTROL.ID,R.FILE.CONTROL)
        END
    NEXT I

    CALL JOURNAL.UPDATE('')
RETURN

END

