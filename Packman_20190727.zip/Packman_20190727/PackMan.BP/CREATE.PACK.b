*-----------------------------------------------------------------------------
* <Rating>-4</Rating>
*-----------------------------------------------------------------------------
*    $PACKAGE Tool_Packman
    
    SUBROUTINE CREATE.PACK
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
*-----------------------------------------------------------------------------


*     Parameter 1 = valid T24 user for audit                                   *
*     Parameter 2 = SAVE or RESTORE1/RESTORE2/RESTORE3                         *
*     Parameter 3 = path of CHANGE_LIST in SAVEDLISTS format i.e. A1>V1        *

    PARAM.APPEL = SYSTEM(1000)
    COMMAND.LINE.ARGUMENT = TRIM(@SENTENCE, SPACE(1), 'R')
SS = V$FUNCTION
TT = COMI
    W.SAVEDLIST.NAME = SENTENCE(1)
        
    CMD.CREATE.PACK = "PACK.MAN.LAUNCHER " : OPERATOR : " SAVE " : W.SAVEDLIST.NAME 
    
    EXECUTE CMD.CREATE.PACK    
    
    RETURN
    
