*-----------------------------------------------------------------------------
* <Rating>644</Rating>
*-----------------------------------------------------------------------------
*    $PACKAGE Tool_Packman
    
    PROGRAM SEL.INSTALL.ACTION.EXEC
***<region name=Description>
***
* @author = TM
* @date = 22/01/2014
*
* Execution des actions a l'installation avec PACK MAN.
***</region>
***<region name=changelog>
***
***</region>
    $INSERT I_COMMON
    $INSERT I_EQUATE

    $INSERT I_F.USER
    $INSERT I_F.SEL.INSTALL.ACTION

*    HUSH ON
    GOSUB INITIALISE
    IF NOT(RETURN.CODE) THEN
        GOSUB PROCESS
    END
*    HUSH OFF
    GOSUB WRITE.COMO

    IF RETURN.CODE EQ "" THEN RETURN.CODE = 1
    CRT "RETURN.CODE=" : RETURN.CODE
    EXIT (RETURN.CODE)
***<region name=Initialise>
***
INITIALISE:

    GOSUB INIT.CAR.SPE.ID.DL.DIR
    NOM.SUBR.TRANS = "EB.TRANS"

    TIME.NOW    = TIME() "MTS"
    THIS.MOMENT = CHANGE(TIME.NOW, ":", "-")
    THIS.DAY    = OCONV(DATE(), "DG")
    COMO.ID     = "SEL.INSTALL.ACTION.EXEC_" : THIS.DAY : "_" : THIS.MOMENT

    NEW.OPERATOR = SENTENCE(1)
    INSTALL.POS = SENTENCE(2)

    DIRECTORY.NAME = SENTENCE(3)

    R.COMO  = "Start SEL.INSTALL.ACTION.EXEC process - " : TIMEDATE() : FM
    R.COMO := FM : "User name    = " : NEW.OPERATOR
    R.COMO := FM : "Position     = " : INSTALL.POS
    R.COMO := FM : "Directory    = " : DIRECTORY.NAME : FM

    RETURN.CODE = ""

    GOSUB INITIALISE.T24

    OPERATOR = NEW.OPERATOR

    GOSUB OPEN.FILES

    GOSUB CHECK.PARAMETER
    IF RETURN.CODE THEN
        DISPLAY
        DISPLAY "Illegal option   : " : DQUOTE(SENTENCE())
        DISPLAY
        DISPLAY "Usage            : " : SENTENCE(0) : " <t24_user> <position> <taf_path>"
        DISPLAY
        DISPLAY "t24_user         : a valid T24 user from the USER table"
        DISPLAY "position         : only on of the following options AVR1, R1R2, R2R3 or APR3"
        DISPLAY "taf_path         : a valid directory name path which contains the PACK MAN"
        DISPLAY "                   package to execute"
        DISPLAY
    END

    RETURN
***<region name=Initialise T24>
***
INITIALISE.T24:
    OPEN "F.SPF" TO F.SPF ELSE
        DISPLAY "Can't open F.SPF"
        EXIT (12)
    END
    READ R.SPF.SYSTEM FROM F.SPF, "SYSTEM" ELSE
        DISPLAY "Can't read F.SPF SYSTEM"
        EXIT (12)
    END
    R.COMO := FM : "Successfuly read SPF - " : TIMEDATE()

*    HUSH ON
*    EXECUTE "EBS.TERMINAL.SELECT EBS-JBASE"
*    HUSH OFF

    CALL T24.INITIALISE
    R.COMO := FM : "T24 initialised - " : TIMEDATE()

    CALL S.INITIALISE.COMMON
    R.COMO := FM : "T24 common variables initialised - " : TIMEDATE()

    NEW.ID.COMP = "IL0010001"
    CALL LOAD.COMPANY (NEW.ID.COMP)
    R.COMO := FM : "Loaded T24 company " : NEW.ID.COMP : " - " : TIMEDATE() : FM

    RUNNING.UNDER.BATCH = 1
    LEVEL.NO = 1 ; * for ENQUIRY.REPORTs

    RETURN
***</region>
***<region name=Check parameter>
***
CHECK.PARAMETER:

    IF OPERATOR = "" OR INSTALL.POS = "" OR DIRECTORY.NAME = "" OR SENTENCE(4) # "" THEN
        MSG.ERR = "Incorrect number of parameters"
        DISPLAY MSG.ERR
        R.COMO := FM : MSG.ERR : " - " : TIMEDATE()
        RETURN.CODE = 13
        RETURN
    END

    READ R.USER FROM F.USER, OPERATOR ELSE
        MSG.ERR = "Read USER record for " : OPERATOR : " failed"
        DISPLAY MSG.ERR
        R.COMO := FM : MSG.ERR : " - " : TIMEDATE()
        RETURN.CODE = 13
        RETURN
    END
    R.COMO := FM : "Read USER record for " : R.USER<EB.USE.USER.NAME> : " - " : TIMEDATE()

    IF INSTALL.POS # "AVR1" AND INSTALL.POS # "R1R2" AND INSTALL.POS # "R2R3" AND INSTALL.POS # "APR3" THEN
        MSG.ERR = "Incorrect position value " : INSTALL.POS
        DISPLAY MSG.ERR
        R.COMO := FM : MSG.ERR : " - " : TIMEDATE()
        RETURN.CODE = 13
        RETURN
    END

    PATH.TYPE = ""
    OPEN DIRECTORY.NAME TO F.PACKAGE THEN
        STATUS PACKAGE.STATUS FROM F.PACKAGE ELSE PACKAGE.STATUS = ""
        PATH.TYPE = PACKAGE.STATUS<21>
    END
    IF PATH.TYPE # "UD" OR INDEX(DIRECTORY.NAME, " ", 1) THEN
        MSG.ERR = "The path " : DIRECTORY.NAME : " is not a valid directory"
        DISPLAY MSG.ERR
        R.COMO := FM : MSG.ERR : " - " : TIMEDATE()
        RETURN.CODE = 13
        RETURN
    END
    R.COMO := FM : "The path " : DIRECTORY.NAME : " is a valid directory - " : TIMEDATE()

    RETURN
***</region>
***<region name=Open files>
***
OPEN.FILES:

    FN.USER = "F.USER" ; F.USER = ""
    CALL OPF (FN.USER, F.USER)

    FN.COMO = "&COMO&" ; F.COMO = ""
    CALL OPF (FN.COMO, F.COMO)

    FN.SEL.INSTALL.ACTION = "F.SEL.INSTALL.ACTION" ; F.SEL.INSTALL.ACTION = ""
    CALL OPF (FN.SEL.INSTALL.ACTION, F.SEL.INSTALL.ACTION)

    FN.SEL.INSTALL.ACTION$HIS = "F.SEL.INSTALL.ACTION$HIS" ; F.SEL.INSTALL.ACTION$HIS = ""
    CALL OPF (FN.SEL.INSTALL.ACTION$HIS, F.SEL.INSTALL.ACTION$HIS)

    RETURN
***</region>
***</region>
***<region name=Process>
***
PROCESS:
*    SEL.CMD = "SSELECT " : DIRECTORY.NAME : " USING DICT " : FN.SEL.INSTALL.ACTION : " WITH @ID LIKE " : DQUOTE(SQUOTE("SEL.INSTALL.ACTION-") : "...") : " AND POSITION = " : DQUOTE(INSTALL.POS)
    W.TAG.SEL.INSTALL.ACTION = "SEL.INSTALL.ACTION"        
    W.TAG.SEL.INSTALL.ACTION.LEN = LEN(W.TAG.SEL.INSTALL.ACTION)

    SEL.CMD = "SELECT " : DIRECTORY.NAME
    LISTE.SEL.INST.ACT = "" ; NOM.LISTE = "" ; SEL.NB = ""
    CALL EB.READLIST (SEL.CMD, LISTE.SEL.INST.ACT, NOM.LISTE, SEL.NB, ERR.MSG)
    LISTE.SEL.INST.ACT.SAVE = ""
    K = 0
    FOR I = 1 TO SEL.NB
        IF LISTE.SEL.INST.ACT<I>[1,W.TAG.SEL.INSTALL.ACTION.LEN] EQ W.TAG.SEL.INSTALL.ACTION THEN
            READ R.INST.ACT FROM F.PACKAGE, LISTE.SEL.INST.ACT<I> THEN
                IF R.INST.ACT<SEL.INST.ACTION.POSITION> EQ INSTALL.POS THEN
                    K = K + 1 
                    LISTE.SEL.INST.ACT.SAVE<K> = LISTE.SEL.INST.ACT<I>
                END
            END   
        END
    NEXT I

*  
    LISTE.SEL.INST.ACT = LISTE.SEL.INST.ACT.SAVE
    SEL.NB = K

    R.COMO := FM : FM : SEL.NB : " SEL.INSTALL.ACTION selected - " : TIMEDATE()

    LOOP
        REMOVE ID.PACK.INST.ACT FROM LISTE.SEL.INST.ACT SETTING POS.SEL
    WHILE ID.PACK.INST.ACT : POS.SEL DO
        ID.DL.DIR = ID.PACK.INST.ACT
        GOSUB REVERSE.CAR.SPE.ID.DL.DIR
        ID.INST.ACT = ID.DL.DIR["-", 2, 999]
        READ R.INST.ACT FROM F.PACKAGE, ID.PACK.INST.ACT THEN
            READU R.OLD.INST.ACT FROM F.SEL.INSTALL.ACTION, ID.INST.ACT ELSE
                R.OLD.INST.ACT = ""
            END
            FOR I.FIELD = SEL.INST.ACTION.EXEC.USER TO SEL.INST.ACTION.EXEC.LOG
                R.INST.ACT<I.FIELD> = R.OLD.INST.ACT<I.FIELD>
            NEXT I.FIELD
            CURR.NO = R.OLD.INST.ACT<SEL.INST.ACTION.CURR.NO>
            IF R.INST.ACT[FM, 1, SEL.INST.ACTION.OVERRIDE - 1] # R.OLD.INST.ACT[FM, 1, SEL.INST.ACTION.OVERRIDE - 1] THEN
                CURR.NO++
            END
            R.INST.ACT<SEL.INST.ACTION.RECORD.STATUS> = ""
            R.INST.ACT<SEL.INST.ACTION.CURR.NO> = CURR.NO
            IF R.INST.ACT<SEL.INST.ACTION.REEXECUTION> = "Y" OR R.OLD.INST.ACT = "" THEN
                TYPE.ACTION = R.INST.ACT<SEL.INST.ACTION.TYPE.ACTION>
                R.COMO := FM : FM : "Run of " : ID.INST.ACT : " " : TYPE.ACTION : " - " : TIMEDATE()
                PARAM1 = R.INST.ACT<SEL.INST.ACTION.PARAMETRE1>
                PARAM2 = R.INST.ACT<SEL.INST.ACTION.PARAMETRE2>
                PARAM3 = R.INST.ACT<SEL.INST.ACTION.PARAMETRE3>
                PARAM4 = R.INST.ACT<SEL.INST.ACTION.PARAMETRE4>
                ACTION.PROCESSED = 1
                BEGIN CASE
                CASE TYPE.ACTION = "SH"
                    GOSUB EXEC.SHELL
                CASE TYPE.ACTION = "RTN"
                    GOSUB EXEC.ROUTINE
                CASE TYPE.ACTION = "SRV"
                    GOSUB EXEC.SERVICE
                CASE TYPE.ACTION = "OFS1"
                    GOSUB EXEC.OFS.UNITAIRE
                CASE TYPE.ACTION = "OFSF"
                    GOSUB EXEC.OFS.FICHIER
                CASE TYPE.ACTION = "EXTR"
                    GOSUB EXEC.EXTRACTION
                CASE OTHERWISE
                    ACTION.PROCESSED = 0
                    R.COMO := FM : "Invalid action type " : TYPE.ACTION : " - " : TIMEDATE()
                END CASE
                IF ACTION.PROCESSED THEN
                    I.ACTION = DCOUNT(R.INST.ACT<SEL.INST.ACTION.EXEC.USER>, VM) + 1
                    R.INST.ACT<SEL.INST.ACTION.EXEC.USER, I.ACTION> = OPERATOR
                    R.INST.ACT<SEL.INST.ACTION.EXEC.CURR.NO, I.ACTION> = CURR.NO
                    R.INST.ACT<SEL.INST.ACTION.EXEC.DATE, I.ACTION> = OCONV(DATE(), "DG")
                    R.INST.ACT<SEL.INST.ACTION.EXEC.TIME, I.ACTION> = OCONV(TIME(), "MTS")
                    R.INST.ACT<SEL.INST.ACTION.EXEC.LOG, I.ACTION> = COMO.ID
                END
            END ELSE
                R.COMO := FM : FM : "No new run for " : ID.INST.ACT : " - " : TIMEDATE()
            END
            IF CURR.NO # R.OLD.INST.ACT<SEL.INST.ACTION.CURR.NO> THEN
                IF R.OLD.INST.ACT THEN
                    WRITE R.OLD.INST.ACT ON F.SEL.INSTALL.ACTION$HIS, ID.INST.ACT : ";" : R.OLD.INST.ACT<SEL.INST.ACTION.CURR.NO>
                END
                R.INST.ACT<SEL.INST.ACTION.INPUTTER> = @USERNO : "_" : OPERATOR : "_V"
                Y.DATE.TIME = OCONV(DATE(), "DG")[3, 6] : OCONV(TIME(), "MT")
                CONVERT ":" TO "" IN Y.DATE.TIME
                R.INST.ACT<SEL.INST.ACTION.DATE.TIME> = Y.DATE.TIME
                R.INST.ACT<SEL.INST.ACTION.AUTHORISER> = @USERNO : "_" : OPERATOR
                R.INST.ACT<SEL.INST.ACTION.CO.CODE> = ID.COMPANY
                R.INST.ACT<SEL.INST.ACTION.DEPT.CODE> = R.USER<EB.USE.DEPARTMENT.CODE>
            END
            WRITE R.INST.ACT ON F.SEL.INSTALL.ACTION, ID.INST.ACT
        END
    REPEAT

    RETURN
***<region name=Exec shell>
***
EXEC.SHELL:

    R.COMO := FM : "Shell: " : PARAM1 : " - " : TIMEDATE()
*    EXECUTE @IM : "k" : PARAM1 : " 2>&1" CAPTURING SHELL.OUTPUT
*    OS.TYPE = SYSTEM(1017)
*    IF OS.TYPE <> 'UNIX' THEN
*        OS.TYPE = 'NT'
*    END
*    IF OS.TYPE = "UNIX" THEN
*        EXECUTE "SH -c" : PARAM1 : " 2>&1" CAPTURING SHELL.OUTPUT
*    END ELSE
*        EXECUTE "DOS /c " : PARAM1 : " 2>&1" CAPTURING SHELL.OUTPUT
*    END    

    EXECUTE PARAM1 CAPTURING SHELL.OUTPUT 
    R.COMO := FM : "Output (" : TIMEDATE() : "): " : SHELL.OUTPUT

    RETURN
***</region>
***<region name=Exec routine>
***
EXEC.ROUTINE:

    RTN.PARAM = PARAM2<1, 1, 1>
    R.COMO := FM : "Routine: " : PARAM1 : " " : RTN.PARAM : " - " : TIMEDATE()
    EXECUTE "T24.LAUNCHER SEL.INSTALL.ACTION " : PARAM1 : " " : RTN.PARAM

    RETURN
***</region>
***<region name=Exec service>
***
EXEC.SERVICE:

    SERVICE.MODE = PARAM2<1, 1, 1>
    R.COMO := FM : "Service: " : PARAM1 : " " : SERVICE.MODE : " - " : TIMEDATE()
    EXECUTE "SEL.TSA.UPDATE " : SERVICE.MODE : " " : PARAM1 CAPTURING SRV.OUTPUT
    IF SRV.OUTPUT THEN
        R.COMO := FM : "Service(s) updated: " : SRV.OUTPUT : " - " : TIMEDATE()
    END ELSE
        R.COMO := FM : "No service uptated - " : TIMEDATE()
    END
    IF SERVICE.MODE = "TSM" AND PARAM1[5] = "START" THEN
        EXECUTE "START.TSM"
    END

    RETURN
***</region>
***<region name=Exec OFS unitaire>
***
EXEC.OFS.UNITAIRE:

    OFS.SOURCE = PARAM1
    OFS.MESSAGE = PARAM2
    R.COMO := FM : "One OFS: " : OFS.SOURCE : " " : OFS.MESSAGE : " - " : TIMEDATE()
* TODO : controler l'existance de la source OFS
* TODO : controler l'existance de la table OFS + si template est bien compile
    GOSUB TRANS.START
    CALL OFS.GLOBUS.MANAGER (OFS.SOURCE, OFS.MESSAGE)
    GOSUB TRANS.END
    R.COMO := FM : "Response OFS: " : OFS.MESSAGE : " - " : TIMEDATE()

    RETURN
***</region>
***<region name=Exec OFS fichier>
***
EXEC.OFS.FICHIER:

    OFS.SOURCE = PARAM1
    OFS.FILE = PARAM2<1, 1, 1>
    R.COMO := FM : "OFS file: " : OFS.FILE : " " : OFS.SOURCE : " - " : TIMEDATE()
* TODO : controler l'existance de la source OFS
    RUNNING.UNDER.BATCH = 0
*    EXECUTE "B4B.BULK.OFS.MSG WAIT " : OFS.FILE : " " : OFS.SOURCE
    CALL BLM.UPDATE.OFS(OFS.FILE, OFS.SOURCE)
    RUNNING.UNDER.BATCH = 1

    RETURN
***</region>
***<region name=Exec extraction>
***
EXEC.EXTRACTION:

    SEL.EXTR = PARAM2<1, 1, 1>
    LIST.FIELD = PARAM3
    CONVERT VM TO "/" IN PARAM3
    FILE.EXTR.BASE = PARAM4<1, 1, 1>
    R.COMO := FM : "Extract: " : PARAM1 : " " : DQUOTE(SEL.EXTR) : " " : LIST.FIELD : " to " : FILE.EXTR.BASE : " - " : TIMEDATE()
    EXECUTE "B4B.FILE.EXTRACT " : PARAM1 : " " : DQUOTE(SEL.EXTR) : " " : LIST.FIELD CAPTURING EXTR.OUTPUT
    FINDSTR "Generated file" IN EXTR.OUTPUT SETTING LIG.OUTPUT THEN
        ORIG.FILE.NAME = EXTR.OUTPUT<LIG.OUTPUT>[" ", 3, 1]
        FILE.EXTR = FILE.EXTR.BASE
        LIST.FILE = ""
        LOOP
            OPENSEQ "&COMO&", ORIG.FILE.NAME READONLY TO F.ORIG.EXTR ELSE
                EXIT
            END
            EXECUTE "mv &COMO&/" : ORIG.FILE.NAME : " " : FILE.EXTR
            IF LIST.FILE THEN
                LIST.FILE := " "
            END
            LIST.FILE := FILE.EXTR
            OCCUR.ORIG = ORIG.FILE.NAME["_", 2, 1]
            ORIG.FILE.NAME = ORIG.FILE.NAME["_", 1, 1] : "_" : (OCCUR.ORIG + 1) : "_" : ORIG.FILE.NAME["_", 3, 2]
            IF FILE.EXTR.BASE[4][1, 1] = "." THEN
                FILE.EXTR = FILE.EXTR.BASE[1, LEN(FILE.EXTR.BASE) - 4] : "_" : OCCUR.ORIG : FILE.EXTR.BASE[4]
            END ELSE
                FILE.EXTR = FILE.EXTR.BASE : "_" : OCCUR.ORIG
            END
        REPEAT
        R.COMO := FM : "Generated file(s): " : LIST.FILE : " - " : TIMEDATE()
    END ELSE
        R.COMO := FM : "No file generated - " : TIMEDATE()
    END

    RETURN
***</region>
***</region>
***<region name=Trans endstart>
***
TRANS.ENDSTART:

    GOSUB TRANS.END
    GOSUB TRANS.START

    RETURN
***</region>
***<region name=Trans start>
***
TRANS.START:

    CALL @NOM.SUBR.TRANS ("START", MSG.TRANS)

    RETURN
***</region>
***<region name=Trans end>
***
TRANS.END:

    CALL @NOM.SUBR.TRANS ("END", MSG.TRANS)

    RETURN
***</region>
***<region name=Write como>
***
WRITE.COMO:

    READU R.DUMMY FROM F.COMO, COMO.ID ELSE NULL

    R.COMO := FM : FM : "Finished SEL.INSTALL.ACTION.EXEC process - " : TIMEDATE()

    WRITE R.COMO ON F.COMO, COMO.ID

    RETURN
***</region>
***<region name=Insert pack man>
***
    $INSERT I_F.HELPTEXT.MAINMENU
* Variables utilisees dans I_T24.W.PACK.MAN.ADDITIONAL.STAFF dans des subroutines non utilisees ici
    APPLI = ""
    ID.APPLI = ""
    ID.BASIC = ""
    NBR.ERREUR = ""
    NOM.PROG.CTRL = ""
    R.STD.SEL.LR.ID = ""
    RECORD.ID = ""
    REP.BASIC = ""
    TEXTE.CTRL = ""
    $INSERT I_T24.W.PACK.MAN.ADDITIONAL.STAFF
***</region>
