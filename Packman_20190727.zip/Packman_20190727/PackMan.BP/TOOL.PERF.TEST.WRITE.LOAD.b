* Version 1 13/04/00  GLOBUS Release No. 200508 30/06/05
*-----------------------------------------------------------------------------
* <Rating>0</Rating>
*-----------------------------------------------------------------------------
      SUBROUTINE TOOL.PERF.TEST.WRITE.LOAD
*-----------------------------------------------------------------------------
* Load routine to setup the common area for the multi-threaded TOOL.PERF.TEST.WRITE
*-----------------------------------------------------------------------------
$INSERT I_COMMON
$INSERT I_EQUATE
$INSERT I_TOOL.PERF.TEST.WRITE.COMMON
*-----------------------------------------------------------------------------
* Open files to be used in the XX.EOD routine as well as standard variables.

    FN.TOOL.TEST.PERF.TABLE = 'F.TOOL.TEST.PERF.TABLE'
    F.TOOL.TEST.PERF.TABLE  = ''; 
    CALL OPF(FN.TOOL.TEST.PERF.TABLE, F.TOOL.TEST.PERF.TABLE)

      

    W.REC.TO.WRITE= ""
    FOR I=1 TO 10000
        W.REC.TO.WRITE = W.REC.TO.WRITE : "THIS IS THE LINE " : I : FM
    NEXT I

    
    RETURN
END
