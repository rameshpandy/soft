*-----------------------------------------------------------------------------
* <Rating>628</Rating>
*-----------------------------------------------------------------------------
    PROGRAM T24.LAUNCHER

*------------------------------------------------------------------------------*
*                                                                              *
* Program to launch T24 programs or start T24 services. This program will be   *
* called from an AIX shell script (T24_Launcher.sh) which has itself been      *
* launched from TWS (IBM Tivoli Workload Scheduler). TWS will pass in a couple *
* of parameters into it namely :                                               *
*                                                                              *
*     Parameter 1 = flow name (e.g. CED01 or COB)                              *
*     Parameter 2 = program name e.g. SEL.CHECK.GED.IN or SEL.TSA.CRECRO       *
*     Parameter 3 = START, STOP or a parameter list in an array                *
*                                                                              *
* Date        Who   Ver  Description                                           *
* ----        ---   ---  -----------                                           *
* 24/09/2009  Ches  1.0  Initial version                                       *
* 05/10/2009  Ches  1.1  Add parameter to indicate which flow                  *
* 07/04/2010  Ches  1.2  Add call to remove control characters                 *
* 23/06/2010  Ches  1.3  Set LEVEL.NO to 1 at all times                        *
* 19/07/2010  FFE   1.4  Add CASE clause to chose OPERATOR according to        *
*                        v5.0.5 requirements                                   *
*                                                                              *
*------------------------------------------------------------------------------*
 
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.TSA.SERVICE
    $INSERT I_F.PGM.FILE
    $INSERT I_F.USER

! process control section

    GOSUB INITIALISE

    IF RETURN.CODE = 1 THEN
        GOSUB MAIN.PROCESS
    END

    GOSUB WRITE.COMO

    EXIT(RETURN.CODE)


! initialisation section

*----------
INITIALISE:
*----------

! read input buffer

    FLOW.NAME     = SENTENCE(1)
    PROCESS.NAME  = SENTENCE(2)
    PARAMETERS    = SENTENCE(3)
    RETURN.CODE   = 1

! open files

    OPEN 'F.SPF'         TO F.SPF         ELSE STOP 201,'CANT OPEN F.SPF'
    OPEN 'F.TSA.SERVICE' TO F.TSA.SERVICE ELSE STOP 201,'CANT OPEN F.TSA.SERVICE'
    OPEN 'F.PGM.FILE'    TO F.PGM.FILE    ELSE STOP 201,'CANT OPEN F.PGM.FILE'
    OPEN '&COMO&'        TO F.COMO        ELSE STOP 201,'CANT OPEN &COMO&'
    OPEN 'F.USER'        TO F.USER        ELSE STOP 201,'CANT OPEN F.USER'

! read SPF and determine whether this is a service or a mainline program

    R.SPF.SYSTEM  = ''
    R.TSA.SERVICE = ''
    R.PGM.FILE    = ''

! start preparing log info

    TIME.NOW    = TIME() 'MTS'
    THIS.MOMENT = CHANGE(TIME.NOW, ':', '-')
    THIS.DAY    = OCONV(DATE(), 'D2/')
    THIS.DAY    = '20' : THIS.DAY[7,2] : THIS.DAY[1,2] : THIS.DAY[4,2]
    COMO.ID     = 'T24.LAUNCHER_' : THIS.DAY : '_' : THIS.MOMENT

    R.COMO      = ''
    R.COMO     := 'Start T24 Launcher process - ' : TIMEDATE() : FM : FM
    R.COMO     := 'Flow Name    = ':FLOW.NAME : FM
    R.COMO     := 'Process Name = ':PROCESS.NAME : FM
    R.COMO     := 'Parameters   = ':PARAMETERS : FM : FM


    READ R.SPF.SYSTEM FROM F.SPF, 'SYSTEM' THEN

        R.COMO := 'Successfuly read SPF - ' : TIMEDATE() : FM : FM

        READ R.TSA.SERVICE FROM F.TSA.SERVICE, PROCESS.NAME THEN
            R.COMO := 'Successfuly read TSA.SERVICE, ' : PROCESS.NAME : ' - ' : TIMEDATE() : FM : FM
        END ELSE

            READ R.PGM.FILE FROM F.PGM.FILE, PROCESS.NAME THEN
                R.COMO := 'Successfuly read PGM.FILE, ':PROCESS.NAME: ' - ' : TIMEDATE() : FM : FM
            END ELSE
                R.COMO     := 'Failed to read TSA.SERVICE or PGM.FILE for ' : PROCESS.NAME : ' - ' : TIMEDATE() : FM : FM
                RETURN.CODE = '13'
            END
        END

    END ELSE
        R.COMO     := 'Failed to read SPF - ' : TIMEDATE() : FM : FM
        RETURN.CODE = '13'
    END

    RETURN

! main processing section

*------------
MAIN.PROCESS:
*------------

! if this is a service, set the status to start and exit...

! ...on the other hand, if it is a program, call it directly using CALL @

    BEGIN CASE
    CASE R.TSA.SERVICE NE ''
        GOSUB START.SERVICE

    CASE R.PGM.FILE NE ''
        GOSUB RUN.T24.PROGRAM

    CASE 1          ;* how did it get this far?
        RETURN.CODE = '13'
    END CASE

    RETURN


! start service

*-------------
START.SERVICE:
*-------------

    R.COMO := 'Setting status of TSA.SERVICE, ' : PROCESS.NAME : ' to START - ' : TIMEDATE() : FM : FM

    READU R.TSA.SERVICE FROM F.TSA.SERVICE, PROCESS.NAME THEN
        R.TSA.SERVICE<TS.TSM.SERVICE.CONTROL> = PARAMETERS
        WRITE R.TSA.SERVICE ON F.TSA.SERVICE, PROCESS.NAME
    END

    RELEASE F.TSA.SERVICE, PROCESS.NAME

    RETURN


! run T24 program

*---------------
RUN.T24.PROGRAM:
*---------------

! set up T24

    CALL T24.INITIALISE
    R.COMO := 'T24 initialised - ' : TIMEDATE() : FM : FM

    CALL S.INITIALISE.COMMON
    R.COMO := 'T24 Common Variables Initialised - ' : TIMEDATE() : FM : FM

    CALL LOAD.COMPANY ('IL0010001')
    R.COMO := 'Loaded T24 Company IL0010001 - ' : TIMEDATE() : FM : FM

! set LEVEL.NO for ENQUIRY.REPORTs

    LEVEL.NO = 1

! load user details (different user for part 2 of CED_01)
! v1.4 : modified according to 5.0.5 requirements
!    IF PROCESS.NAME = 'SEL.PROCESS.FT.INAU' THEN
!        OPERATOR = 'EXPLOIT.2'
!    END ELSE
!        OPERATOR = 'EXPLOIT.1'
!    END

    BEGIN CASE
    CASE PROCESS.NAME = 'SEL.PROCESS.FT.INAU.180'
        OPERATOR = 'EXPLOIT.3'
    CASE PROCESS.NAME = 'SEL.PROCESS.FT.INAU'
        OPERATOR = 'EXPLOIT.2'
    CASE OTHERWISE
        OPERATOR = 'EXPLOIT.1'
    END CASE

    READ R.USER FROM F.USER, OPERATOR ELSE R.USER = ''

    R.COMO := 'Read USER record for ' : R.USER<EB.USE.USER.NAME> : ' - ' : TIMEDATE() : FM : FM

! determine how to perform the subroutine call

    BEGIN CASE

    CASE FLOW.NAME = 'COB'
        CALL @ PROCESS.NAME

    CASE ( PARAMETERS NE 'START' ) AND ( PARAMETERS NE 'STOP' ) AND ( PARAMETERS NE '' )
        HUSH ON
        CALL @ PROCESS.NAME(PARAMETERS)
        HUSH OFF

    CASE 1
        HUSH ON
        CALL @ PROCESS.NAME
        HUSH OFF

    END CASE

    R.COMO := 'Returned from calling T24 program ' : PROCESS.NAME : ' - ' : TIMEDATE() : FM : FM

    RETURN


! write the log file

*----------
WRITE.COMO:
*----------

    READU DUMMY FROM F.COMO, COMO.ID ELSE NULL

    R.COMO := FM : 'Finished T24 Launcher process - ' : TIMEDATE() : FM

    WRITE R.COMO ON F.COMO, COMO.ID
    RELEASE F.COMO, COMO.ID

    RETURN

END


