* @ValidationCode : Mjo1Mjc5OTQ4NTQ6Q3AxMjUyOjE1NDg5Mjk1MjY2NTU6dWRndGxjZDotMTotMTowOjA6ZmFsc2U6Ti9BOlIxOF9BTVIuMDotMTotMQ==
* @ValidationInfo : Timestamp         : 31 Jan 2019 12:12:06
* @ValidationInfo : Encoding          : Cp1252
* @ValidationInfo : User Name         : udgtlcd
* @ValidationInfo : Nb tests success  : N/A
* @ValidationInfo : Nb tests failure  : N/A
* @ValidationInfo : Rating            : N/A
* @ValidationInfo : Coverage          : N/A
* @ValidationInfo : Strict flag       : N/A
* @ValidationInfo : Bypass GateKeeper : false
* @ValidationInfo : Compiler Version  : R18_AMR.0
*-----------------------------------------------------------------------------
* <Rating>26683</Rating>
*-----------------------------------------------------------------------------
*    $PACKAGE Tool_Packman

SUBROUTINE T24.W.PACK.MAN
*-----------------------------------------------------------------------------
* author ssenthamil@temenos.com
*=============================================================================
* Modification History :
* dd/mm/yyy    - CD_REFERENCE - author
*              Description of modification.
* 31 Jan 2019 K Amith Gowda - Replaced READLIST with EB.READLIST for R18 TAFJ8 upgrade
*-----------------------------------------------------------------------------
*   Date            who                      Reference            Description
*-----------------------------------------------------------------------------
*=============================================================================
*
    $INSERT I_COMMON
    $INSERT I_EQUATE

    $INSERT I_F.SPF ;* TM_20100809
    $INSERT I_IO.EQUATE ;* TM_20100809

    $INSERT I_SCREEN.VARIABLES
    $INSERT I_GTS.COMMON
    $INSERT I_F.OFS.STATUS.FLAG
    $INSERT I_STATIC.CACHE.COMMON ;* TM_20100809

    $INSERT I_F.ABBREVIATION ;* TM_20100804
    $INSERT I_F.BATCH         ;* TM_061006a
    $INSERT I_F.COMPANY
    $INSERT I_F.EB.ALTERNATE.KEY ;* TM_20100804
    $INSERT I_F.EB.PHANTOM    ;* TM_061206a
    $INSERT I_F.EB.TABLE.DEFINITION ; * TM_20100401
    $INSERT I_F.ENQUIRY
    $INSERT I_F.FILE.CONTROL
    $INSERT I_F.HELPTEXT.MAINMENU
    $INSERT I_F.HELPTEXT.MENU
    $INSERT I_F.LOCAL.REF.TABLE
    $INSERT I_F.LOCAL.TABLE
    $INSERT I_F.OFS.SOURCE
    $INSERT I_F.PGM.FILE
    $INSERT I_F.STANDARD.SELECTION
    $INSERT I_F.TSA.SERVICE   ;* TM_061206a
    $INSERT I_F.USER
    $INSERT I_F.VERSION
*
*===================================================================================
*
    $INSERT I_F.T24.W.PACK.MAN
*
*===================================================================================
*
    GOSUB DEFINE.PARAMETERS

    IF LEN(V$FUNCTION) GT 1 THEN
        GOTO V$EXIT
    END

    CALL MATRIX.UPDATE

    GOSUB INITIALISE          ;* Special Initialising
*
*===================================================================================
*
    LOOP

        CALL RECORDID.INPUT

    UNTIL (MESSAGE EQ 'RET')

        V$ERROR = ''

        IF MESSAGE EQ 'NEW FUNCTION' THEN

            GOSUB CHECK.FUNCTION        ;* Special Editing of Function

            IF V$FUNCTION EQ 'E' OR V$FUNCTION EQ 'L' THEN
                CALL FUNCTION.DISPLAY
                V$FUNCTION = ''
            END

        END ELSE

            GOSUB CHECK.ID    ;* Special Editing of ID
            IF V$ERROR THEN
                GOTO MAIN.REPEAT
            END

            CALL RECORD.READ

            IF MESSAGE EQ 'REPEAT' THEN
                GOTO MAIN.REPEAT
            END

            CALL MATRIX.ALTER

            GOSUB CHECK.RECORD          ;* Special Editing of Record
            IF V$ERROR THEN
                GOTO MAIN.REPEAT
            END

            LOOP
                GOSUB PROCESS.FIELDS    ;* ) For Input
                GOSUB PROCESS.MESSAGE   ;* ) Applications
            WHILE (MESSAGE EQ 'ERROR')
            REPEAT

        END

MAIN.REPEAT:
    REPEAT

V$EXIT:
*
RETURN          ;* From main program
*
*===================================================================================
*
PROCESS.FIELDS:
*
    LOOP
        IF SCREEN.MODE EQ 'MULTI' THEN
            IF FILE.TYPE EQ 'I' THEN
                CALL FIELD.MULTI.INPUT
            END ELSE
                CALL FIELD.MULTI.DISPLAY
            END
        END ELSE
            IF FILE.TYPE EQ 'I' THEN
                CALL FIELD.INPUT
            END ELSE
                CALL FIELD.DISPLAY
            END
        END

    UNTIL MESSAGE <> "" DO

        GOSUB CHECK.FIELDS    ;* Special Field Editing

        IF E # '' THEN
            T.SEQU = 'IFLD' ; CALL ERR
        END

        IF T.SEQU NE '' THEN
            T.SEQU<-1> = A + 1
        END

    REPEAT
*
RETURN
*
*===================================================================================
*
PROCESS.MESSAGE:
*
    IF MESSAGE EQ 'VAL' THEN
        MESSAGE = ''
        BEGIN CASE
            CASE V$FUNCTION EQ 'D'
                GOSUB CHECK.DELETE          ;* Special Deletion checks
            CASE V$FUNCTION EQ 'R'
                GOSUB CHECK.REVERSAL        ;* Special Reversal checks
            CASE OTHERWISE
                GOSUB CROSS.VALIDATION      ;* Special Cross Validation
        END CASE

        IF NOT(V$ERROR) THEN
            GOSUB BEFORE.UNAU.WRITE     ;* Special Processing before write
        END
        IF NOT(V$ERROR) THEN
            CALL UNAUTH.RECORD.WRITE
            IF MESSAGE NE "ERROR" THEN
                GOSUB AFTER.UNAU.WRITE  ;* Special Processing after write
            END
        END

    END

    IF MESSAGE EQ 'AUT' THEN
        GOSUB AUTH.CROSS.VALIDATION     ;* Special Cross Validation
        IF NOT(V$ERROR) THEN
            GOSUB BEFORE.AUTH.WRITE     ;* Special Processing before write
        END

        IF NOT(V$ERROR) THEN

            CALL AUTH.RECORD.WRITE

            IF MESSAGE NE "ERROR" THEN
                GOSUB AFTER.AUTH.WRITE  ;* Special Processing after write
            END
        END

    END
*
RETURN
*
*===================================================================================
*
CHECK.ID:
*
*=============================================================================
* Modification History :
* dd/mm/yyy    - CD_REFERENCE - author
*              Description of modification.
*-----------------------------------------------------------------------------
* Date         who                       Reference            Description
* 25/01/2012   Thierry MARTIN            TM_20120125          Increase the numbre of characters id the id.
*-----------------------------------------------------------------------------
    IF COMI = '' THEN
        E ='EB.DL.TAF.ID.DOES.NOT.MATCH'
        CALL ERR
        V$ERROR = 1
        RETURN
    END
    IF INDEX(COMI,'-',1) THEN
        TAF.ID = COMI['-',1,1]
        UNIT.NAME = COMI['-',2,99]
    END ELSE
        TAF.ID = ''
        UNIT.NAME = COMI
    END
*
    IF INDEX(UNIT.NAME,'-',1) OR INDEX(UNIT.NAME,'>',1) THEN
        E ='EB.DL.INVALID.CHARACTERS'
        CALL ERR
        V$ERROR = 1
    END
*
    IF NOT(V$FUNCTION MATCHES "S") THEN
        IF NOT(V$ERROR) THEN
            BEGIN CASE
                CASE INDEX(COMI,'/',1)
                    V$ERROR = 1
                    E ='EB.DL.NOT.ALLOW.ID'
                CASE INDEX(COMI,'\',1)
                    V$ERROR = 1
                    E ='EB.DL.NOT.ALLOWED.ID'
                CASE INDEX(COMI,':',1)
                    V$ERROR = 1
                    E ='EB.DL.NOT.ALLOWED.ID.1'
                CASE INDEX(COMI,'*',1)
                    V$ERROR = 1
                    E ='EB.DL.NOT.ALLOWED.ID.2'
                CASE INDEX(COMI,'?',1)
                    V$ERROR = 1
                    E ='EB.DL.NOT.ALLOWED.ID.3'
                CASE INDEX(COMI,'"',1)
                    V$ERROR = 1
                    E ='EB.DL.NOT.ALLOWED.ID.4'
                CASE INDEX(COMI,'<',1)
                    V$ERROR = 1
                    E ='EB.DL.L.NOT.ALLOWED.ID'
                CASE INDEX(COMI,'>',1)
                    V$ERROR = 1
                    E ='EB.DL.G.NOT.ALLOWED.ID'
                CASE INDEX(COMI,'|',1)
                    V$ERROR = 1
                    E ='EB.DL.|.NOT.ALLOWED.ID'
                CASE INDEX(COMI,'%',1)
                    V$ERROR = 1
                    E ='EB.DL.NOT.ALLOWED.ID.5'
            END CASE
            IF V$ERROR THEN ; * TM_140219 s
                CALL ERR
            END ; * TM_140219 e
        END
    END
*
* IF LEN(UNIT.NAME) > 22 THEN ; * TM_20120125 s
* E ='EB.DL.UNIT.NAME.NOT.LONGER.THAN.22.CHARS'
* CALL ERR
* V$ERROR = 1
* END ; * TM_20120125 e
*
    IF NOT(V$ERROR) THEN
        IF TAF.ID THEN
            IF TAF.ID # 'TAF' AND TAF.ID # "ANO_DEV" AND TAF.ID # "ANO_PRE" AND TAF.ID # "ANO_SAS" AND TAF.ID # "FFT" THEN
                READ R.TEMP FROM F.FILE,COMI ELSE
                    E ='EB.DL.TAF.ID.DOES.NOT.MATCH'
                    CALL ERR
                    V$ERROR = 1
                    RETURN
                END
            END
        END ELSE
            READ R.TEMP FROM F.FILE,COMI ELSE
                TAF.ID = 'TAF'
                COMI = TAF.ID:'-':UNIT.NAME
                IF LEN(COMI) > ID.N[".", 1, 1] THEN ; * TM_20120125 s
                    E = "EB-TOO.MANY.CHARACTERS"
                    CALL ERR
                    V$ERROR = 1
                END ; * TM_20120125 e
                ID.NEW = COMI
            END
        END
    END

    TEXT = ''

*
RETURN
*
*===================================================================================
*
CHECK.RECORD:
*
RETURN
*
*===================================================================================
*
CHECK.FIELDS:
*
*=============================================================================
* Modification History :
* dd/mm/yyy    - CD_REFERENCE - author
*              Description of modification.
*-----------------------------------------------------------------------------
*   Date            who                      Reference            Description
* 25/09/2014   Thierry MARTIN            TM_140925            Add restriction to not save some applications
*-----------------------------------------------------------------------------
*=============================================================================
    E = ''
    BEGIN CASE
        CASE AF = T24.PM.DEF.DIRECTORY
            IF NOT(COMI) THEN
                COMI = '.' : SEP.DIR : 'LEUMI.PACKS'
            END
            IF COMI[LEN(ID.NEW) + 1] # SEP.DIR : ID.NEW THEN    ;* TM_061206a, TM_070502a
                COMI := SEP.DIR : ID.NEW    ;* TM_070502a
            END         ;* TM_061206a
* FROM.TO.FILE = COMI                                    ; * TM_070502a
*
        CASE AF = T24.PM.DEF.ACTION
            IF COMI = 'RESET' THEN
                R.LIST = ''
                R.NEW(T24.PM.DEF.ACTION) = ''
                GOSUB EXPAND.LIST
                COMI = ''
                CALL REBUILD.SCREEN
                GOTO END.CHECK.FIELDS
            END

        CASE AF = T24.PM.DEF.OPTION
            IF COMI THEN
                IF R.NEW(T24.PM.DEF.ACTION) = '' THEN
                    E ='EB.DL.TOP.LEVEL.TYPE.ENT'
                    GOTO END.CHECK.FIELDS
                END
                R.LIST = ''
                BEGIN CASE
                    CASE R.NEW(T24.PM.DEF.ACTION) = 'RESET'
                        R.LIST = ''
                    CASE R.NEW(T24.PM.DEF.ACTION)[1, 7] = 'RESTORE'
                        IF R.USER<EB.USE.LANGUAGE> # 1 THEN         ;* TM_060818a
                            E = "Impossible d'effectuer une restauration avec une langue autre que 1."      ;* TM_060818a
                            GOTO END.CHECK.FIELDS         ;* TM_060818a
                        END ;* TM_060818a
                        GOSUB CREATE.PACKAGE.LIST
                        IF E # "" THEN          ;* TM_060606a s
                            GOTO END.CHECK.FIELDS
                        END ;* TM_060606a e
                        R.LIST = FILE.CONTROL.LIST
                    CASE R.NEW(T24.PM.DEF.ACTION) = 'GENEREO'       ;* TM_070503a s
                        R.LIST = ""
                        GOSUB GENEREO
                        IF E # "" THEN
                            GOTO END.CHECK.FIELDS
                        END ;* TM_070503a e
                    CASE R.NEW(T24.PM.DEF.ACTION) = 'MAINMENU'
                        GOSUB GET.MENU.ITEM
                        R.LIST = NEW.MENU.ITEM.LIST
                    CASE R.NEW(T24.PM.DEF.ACTION) = 'MENU'
                        GOSUB GET.MENU.ITEM
                        R.LIST = NEW.MENU.ITEM.LIST
                    CASE R.NEW(T24.PM.DEF.ACTION) = 'TEMPLATE'
                        PRG.NAME = COMI         ;* TM_060410a
                        JUST.BP = 0   ;* TM_070503a
                        GOSUB CREATE.TEMPLATE.LIST
                        R.LIST = FILE.CONTROL.LIST
                    CASE R.NEW(T24.PM.DEF.ACTION) = 'DELIVERY'
                        R.LIST = 'DE.MESSAGE>':COMI
                        COMMAND = 'SELECT F.DE.MAPPING LIKE ':COMI:'... BY @ID'
                        CALL EB.READLIST(COMMAND,RECORD.LIST,'',TOTAL.NUM,CODE)
                        IF RECORD.LIST THEN
                            FOR YAV = 1 TO TOTAL.NUM
                                R.LIST<-1> = 'DE.MAPPING>':RECORD.LIST<YAV>
                            NEXT YAV
                        END
                        COMMAND = 'SELECT F.DE.FORMAT.SWIFT LIKE ':COMI:'... BY @ID'
                        CALL EB.READLIST(COMMAND,RECORD.LIST,'',TOTAL.NUM,CODE)
                        IF RECORD.LIST THEN
                            FOR YAV = 1 TO TOTAL.NUM
                                R.LIST<-1> = 'DE.FORMAT.SWIFT>':RECORD.LIST<YAV>
                            NEXT YAV
                        END
                        COMMAND = 'SELECT F.DE.FORMAT.PRINT LIKE ':COMI:'... BY @ID'
                        CALL EB.READLIST(COMMAND,RECORD.LIST,'',TOTAL.NUM,CODE)
                        IF RECORD.LIST THEN
                            FOR YAV = 1 TO TOTAL.NUM
                                R.LIST<-1> = 'DE.FORMAT.PRINT>':RECORD.LIST<YAV>
                            NEXT YAV
                        END
                    CASE R.NEW(T24.PM.DEF.ACTION) = 'REPGEN'
                        R.LIST = 'REPGEN.SORT>':COMI
                        R.LIST<-1> = 'REPGEN.CREATE>':COMI
                        R.LIST<-1> = 'REPGEN.OUTPUT>':COMI
                    CASE R.NEW(T24.PM.DEF.ACTION) = 'VERSION'
                        R.LIST = 'VERSION>':COMI
                    CASE R.NEW(T24.PM.DEF.ACTION) = 'ENQUIRY'
                        CALL OPF('F.ENQUIRY',F.ENQUIRY)
                        CALL F.READ('F.ENQUIRY',COMI,R.ENQUIRY,F.ENQUIRY,E)

                        IF E THEN
                            GOTO END.CHECK.FIELDS
                        END
                        R.LIST = 'ENQUIRY>':COMI
                        R.LIST<-1> = 'STANDARD.SELECTION>':R.ENQUIRY<ENQ.FILE.NAME>
                        TOTAL.NUM = DCOUNT(R.ENQUIRY<ENQ.BUILD.ROUTINE>,VM)
                        FOR YAV = 1 TO TOTAL.NUM
                            IF R.ENQUIRY<ENQ.BUILD.ROUTINE,YAV> THEN R.LIST<-1> = 'BP>':R.ENQUIRY<ENQ.BUILD.ROUTINE,YAV>
                        NEXT YAV
                END CASE
                GOSUB EXPAND.LIST
                IF NOT(R.NEW(T24.PM.DEF.ACTION)[1, 7] = 'RESTORE') THEN
                    R.NEW(T24.PM.DEF.ACTION) = ''
                END
                COMI = ''
                CALL REBUILD.SCREEN
            END         ;* IF COMI
*
        CASE AF = T24.PM.DEF.SELECT.LIST
            IF COMI THEN
                READ R.SAVEDLIST FROM SAVEDLISTS,COMI ELSE      ;* TM_060410a
                    E ='EB.DL.SELECT.LIST.DOES.NOT.EXIST'
                    GOTO END.CHECK.FIELDS
                END
                CONVERT CHARX(10):CHARX(26):CHARX(13):" " TO FM IN R.SAVEDLIST      ;* TM_060410a s
                MAX.ITEMS = DCOUNT(R.SAVEDLIST, FM)
                R.LIST = ''
                FOR YAV = 1 TO MAX.ITEMS
                    LIG.SAVEDLIST = R.SAVEDLIST<YAV>
                    BEGIN CASE
                        CASE LIG.SAVEDLIST[">", 1, 1] = 'TEMPLATE'
                            PRG.NAME = LIG.SAVEDLIST[">", 2, DCOUNT(LIG.SAVEDLIST, ">")]          ;* TM_070309a
                            JUST.BP = 0         ;* TM_070503a
                            GOSUB CREATE.TEMPLATE.LIST
                            R.LIST<-1> = FILE.CONTROL.LIST
                        CASE LIG.SAVEDLIST # ""
                            R.LIST<-1> = LIG.SAVEDLIST
                    END CASE
                NEXT YAV
                GOSUB EXPAND.LIST
                R.NEW(T24.PM.DEF.ACTION) = ''
                R.NEW(T24.PM.DEF.OPTION) = ''
                COMI = ''
                CALL REBUILD.SCREEN
            END
*
        CASE AF = T24.PM.DEF.FILE.NAME AND NOT(R.NEW(T24.PM.DEF.ACTION))
            IF COMI THEN
                LOCATE COMI IN R.PARAM.RESTRICTION<1> SETTING POS.RESTRIC THEN ; * TM_140925 s
                    E = "EB-PACK.MAN.DONT.SAVE.APPLI"
                    GOTO END.CHECK.FIELDS
                END ; * TM_140925 e
                BEGIN CASE
                    CASE COMI[2] = 'BP'
                        TEMP.BP = ''
                        OPEN '',COMI TO TEMP.BP ELSE
                            E ='EB.DL.MISS.FILE'
                        END
                    CASE COMI = 'FILE.CONTROL'
                    CASE COMI = 'F.FILE.CONTROL'
                        COMI = 'FILE.CONTROL'
                    CASE COMI = 'TEMPLATE'
                    CASE OTHERWISE
                        FILETYPE = ""
                        OPEN COMI TO F.CURRENT.FILE THEN  ;* TM_060426a s
                            STATUS FSTAT FROM F.CURRENT.FILE ELSE FSTAT = ""
                            FILETYPE = FSTAT<21>
                        END
                        IF FILETYPE # "UD" THEN ;* TM_060426a e
                            IF COMI[1,2] = 'F.' THEN
                                COMI = COMI[3,99]
                            END
                            IF FIELD(COMI,'.',1) = 'F':CMN THEN
                                COMI = FIELD(COMI,'.',2,99)
                            END
                            CHECKFILE1 = 'STANDARD.SELECTION':FM:SSL.SYS.FIELD.NO
                            DUMMY.ENRI = ''
                            CALL CACHE.DBR(CHECKFILE1<1>,CHECKFILE1<2>,COMI,DUMMY.ENRI)
                            IF ETEXT THEN
                                E = ETEXT
                                ERR.AB = "" ; R.AB = "" ;* TM_100804 s
                                CALL F.READ (FN.ABBREVIATION, COMI, R.AB, F.ABBREVIATION, ERR.AB)
                                IF ERR.AB # "" THEN
                                    GOTO END.CHECK.FIELDS
                                END
                                ETEXT = "" ; E = ""
                                COMI.AB = R.AB<EB.ABB.ORIGINAL.TEXT>[" ", 1, 1][",", 1, 1] ; * Pour extraire le nom de l'application
                                DUMMY.ENRI = ''
                                CALL CACHE.DBR(CHECKFILE1<1>, CHECKFILE1<2>, COMI.AB, DUMMY.ENRI)
                                IF ETEXT THEN
                                    E = ETEXT
                                    GOTO END.CHECK.FIELDS
                                END
                                COMI = COMI.AB ;* TM_100804 e
                            END
                            CHECKFILE1 = 'PGM.FILE':FM:EB.PGM.TYPE
                            DUMMY.ENRI = ''
                            CALL CACHE.DBR(CHECKFILE1<1>,CHECKFILE1<2>,COMI,DUMMY.ENRI)
                            IF NOT(DUMMY.ENRI MATCHES 'H':VM:'U':VM:'W':VM:'R') THEN
                                E ='EB.DL.INVALID.PGM.FILE.TYPE'
                                GOTO END.CHECK.FIELDS
                            END
                        END ;* IF FILETYPE # "UD"              ; * TM_060426a
                END CASE
            END
            IF AV = 1 AND COMI = '' THEN
                E ='EB.DL.CANT.NULL.FIRST.FILE'
                GOTO END.CHECK.FIELDS
            END
            IF COMI = '' AND AV <> 1 AND R.NEW(T24.PM.DEF.FILE.NAME)<1,AV> = '' THEN
                COMI = R.NEW(T24.PM.DEF.FILE.NAME)<1,AV-1>
            END
*
        CASE AF = T24.PM.DEF.RECORD.NAME AND NOT(R.NEW(T24.PM.DEF.ACTION))
            FILE.NAME = R.NEW(T24.PM.DEF.FILE.NAME)<1,AV>
            BEGIN CASE
                CASE FILE.NAME = ''
                    E ='EB.DL.MISS.FILE.NAME'
                CASE FILE.NAME = 'TEMPLATE'
                    PRG.NAME = COMI   ;* TM_060410a
                    JUST.BP = 0       ;* TM_070503a
                    GOSUB CREATE.TEMPLATE.LIST
                    R.LIST = FILE.CONTROL.LIST
                    GOSUB EXPAND.NEW.ITEM.LIST
                    R.LIST = R.NEW.LIST
                    GOSUB EXPAND.LIST
                    CALL REBUILD.SCREEN
                CASE FILE.NAME[2] = 'BP'
                    TEMP.BP = '' ; R.PROG = ""
                    OPEN '',FILE.NAME TO TEMP.BP THEN
                        READV R.PROG FROM TEMP.BP,COMI,0
                        ELSE E ='EB.DL.PROGRAM.MISS'
                    END ELSE
                        E ='EB.DL.FILE.DOES.NOT.EXIST'
                    END
                    IF R.PROG THEN
                        JUST.BP = 1   ;* TM_070503a
                        PRG.NAME = COMI         ;* TM_060410a
                        R.LIST = FILE.NAME : ">" : PRG.NAME         ;* TM_060410a
                        GOSUB CREATE.TEMPLATE.LIST
                        IF FILE.CONTROL.LIST # "" THEN    ;* TM_060606a
                            R.LIST<-1> = FILE.CONTROL.LIST          ;* TM_060410a
                        END ;* TM_060606a
                        GOSUB EXPAND.NEW.ITEM.LIST
                        R.LIST = R.NEW.LIST
                        GOSUB EXPAND.LIST
                        CALL REBUILD.SCREEN
                    END
                CASE OTHERWISE
                    FILETYPE = ""     ;* TM_070426a s
                    OPEN FILE.NAME TO F.APPLI THEN
                        STATUS FSTAT FROM F.APPLI ELSE FSTAT = ""
                        FILETYPE = FSTAT<21>
                    END
                    IF FILETYPE = "UD" THEN
                        ETEXT = ""
                    END ELSE
                        F.APPLI = ""
                        CALL OPF ("F." : FILE.NAME : FM : 'NO.FATAL.ERROR', F.APPLI)
                    END     ;* TM_070426a e
                    IF ETEXT THEN
                        E = 'EB.DL.FILE.DOES.NOT.EXIST'
                    END ELSE
                        READ R.APPLI FROM F.APPLI, COMI ELSE
                            E = "EB.DL.REC.MISS.FILE"
                        END
                    END     ;* TM_060403a e
            END CASE
            IF E THEN
                GOTO END.CHECK.FIELDS
            END
    END CASE

*
END.CHECK.FIELDS:
*
RETURN
*
*===================================================================================
*
GENEREO:
*
    LISTE.ABPMS = EREPLACE(TRIM(COMI), " ", FM)
* LISTE.EXCLUS = "" ;* TM_20100804
    LOOP
        REMOVE ID.ABPMS FROM LISTE.ABPMS SETTING POS.ABPMS
    WHILE ID.ABPMS # "" OR POS.ABPMS DO
        READ R.ABPMS FROM F.FILE, ID.ABPMS ELSE
            E = "EB-MISS.FILE.F..ID." : FM : APPLICATION : VM : ID.ABPMS
            RETURN
        END
        UNIX.FILENAME = R.ABPMS<T24.PM.DEF.DIRECTORY>
        OPEN UNIX.FILENAME TO F.UNIX.FILENAME ELSE
            E = "EB-MISS.FILE." : FM : UNIX.FILENAME
            RETURN
        END
        NB.REC = DCOUNT(R.ABPMS<T24.PM.DEF.FILE.NAME>, VM)
        FOR K.REC = 1 TO NB.REC
            APPLI = R.ABPMS<T24.PM.DEF.FILE.NAME, K.REC>
            IF APPLI[2] = "BP" THEN
                ID.APPLI = R.ABPMS<T24.PM.DEF.RECORD.NAME, K.REC>
                BEGIN CASE
* CASE ID.APPLI[1, 1] = "$" ;* TM_20100804 s
* IF LISTE.EXCLUS THEN
* LISTE.EXCLUS := FM
* END
* LISTE.EXCLUS := APPLI : ">" : ID.APPLI ;* TM_20100804 e
                    CASE ID.APPLI[1, 10] = "I_COMPILE_"
                        ID.DL.DIR = APPLI : "-" : ID.APPLI
                        GOSUB CAR.SPE.ID.DL.DIR
                        READ R.COMPILE FROM F.UNIX.FILENAME, ID.DL.DIR THEN
                            LOOP
                                REMOVE LIG.COMP FROM R.COMPILE SETTING POS.COMP
                            UNTIL LIG.COMP = "" AND NOT(POS.COMP) DO
                                LIG.COMP = TRIM(LIG.COMP)
                                REP.BASIC = LIG.COMP[" ", 1, 1]
                                OPEN REP.BASIC TO F.REP.OBJET THEN ;* TM_20100804
                                    LISTE.BASIC = LIG.COMP[" ", 2, 9999]
                                    IF LISTE.BASIC = "" OR LISTE.BASIC = "*" THEN
*                                        EXECUTE 'SSELECT ' : REP.BASIC : ' UNLIKE I_... AND UNLIKE $...' CAPTURING OUTPUT
*                                        READLIST LISTE.BASIC ELSE LISTE.BASIC = ""
                                        SEL.CMD = ' SSELECT ' : REP.BASIC : ' UNLIKE I_... AND UNLIKE $...'
                                        CALL EB.READLIST(SEL.CMD,LISTE.BASIC,'',SEL.CNT,SEL.ERR)
                                    END ELSE
                                        CONVERT " " TO FM IN LISTE.BASIC
                                    END
                                    LOOP
                                        REMOVE ID.BASIC FROM LISTE.BASIC SETTING POS.BASIC
                                    UNTIL ID.BASIC = "" AND NOT(POS.BASIC) DO
                                        READ R.SOURCE FROM F.REP.OBJET, ID.BASIC THEN ; * TM_20100804 s
                                            RECORD.ID = REP.BASIC : ">" : "$" : ID.BASIC
                                            LOCATE RECORD.ID IN R.LIST SETTING POS.LISTE ELSE
                                                IF R.LIST THEN
                                                    R.LIST := FM
                                                END
                                                R.LIST := RECORD.ID
                                            END
                                        END ; * READ R.SOURCE ;* TM_20100804 e
                                    REPEAT
                                END ; * OPEN REP.BASIC ;* TM_20100804
                            REPEAT
                        END       ;* READ R.COMPILE
                    CASE ID.APPLI[1, 2] # "I_"
                        RECORD.ID = APPLI : ">" : "$" : ID.APPLI
                        LOCATE RECORD.ID IN R.LIST SETTING POS.LISTE ELSE
                            IF R.LIST THEN
                                R.LIST := FM
                            END
                            R.LIST := RECORD.ID
                        END
                END CASE
            END     ;* IF APPLI[2] = "BP"
        NEXT K.REC
    REPEAT
* LOOP ; * TM_20100804 s
* REMOVE RECORD.ID FROM LISTE.EXCLUS SETTING POS.LISTE
* WHILE RECORD.ID # "" OR POS.LISTE DO
* LOCATE RECORD.ID IN R.LIST SETTING POS.LISTE THEN
* DEL R.LIST<POS.LISTE>
* END
* REPEAT ; * TM_20100804 e

*
RETURN
*
*===================================================================================
*
CROSS.VALIDATION:
*
*=============================================================================
* Modification History :
* dd/mm/yyy    - CD_REFERENCE - author
*              Description of modification.
*-----------------------------------------------------------------------------
*   Date            who                      Reference            Description
* 25/09/2014   Thierry MARTIN            TM_140925            Add restriction to not save some applications
*-----------------------------------------------------------------------------
*=============================================================================
    V$ERROR = ''    ; * TM_070502a
    ETEXT = ''      ; * TM_070502a
    TEXT = ''       ; * TM_070502a

* CALL CHECK FIELDS ; * TM_20100503 s
    AF.INI = AF ; AV.INI = AV ; AS.INI = AS
    IF R.NEW(T24.PM.DEF.SELECT.LIST) # "" THEN
        AF = T24.PM.DEF.SELECT.LIST ; AV = "" ; AS = ""
        COMI = R.NEW(AF)<1, AV, AS>
        GOSUB CHECK.FIELDS
        R.NEW(AF)<1, AV, AS> = COMI
        IF E THEN
            ETEXT = E
            E = ""
            CALL STORE.END.ERROR
        END
    END
    IF R.NEW(T24.PM.DEF.OPTION) # "" THEN
        AF = T24.PM.DEF.OPTION ; AV = "" ; AS = ""
        COMI = R.NEW(AF)<1, AV, AS>
        GOSUB CHECK.FIELDS
        R.NEW(AF)<1, AV, AS> = COMI
        IF E THEN
            ETEXT = E
            E = ""
            CALL STORE.END.ERROR
        END
    END
    AF = AF.INI ; AV = AV.INI ; AS = AS.INI ; * TM_20100503 e

    IF R.NEW(T24.PM.DEF.ACTION)[1, 7] EQ 'RESTORE' THEN
        IF R.USER<EB.USE.LANGUAGE> # 1 THEN ; * TM_060818a s
            E = "Impossible d'effectuer une restauration avec une langue autre que 1."
            CALL ERR
            V$ERROR = 1
            MESSAGE = 'ERROR'
            RETURN
        END ; * TM_060818a e
        RETURN
    END
    NO.OF.MULTIS = DCOUNT(R.NEW(T24.PM.DEF.FILE.NAME), VM)
    IF NO.OF.MULTIS = 0 THEN
        AF = T24.PM.DEF.FILE.NAME ; AV = 1 ; AS = ""
        ETEXT = 'EB.DL.REC.MISS.FILE'
        CALL STORE.END.ERROR
        V$ERROR = 1
        MESSAGE = 'ERROR'
        RETURN
    END
    AS = ""
    FOR AV = 1 TO NO.OF.MULTIS
        AF = T24.PM.DEF.RECORD.NAME
        ETEXT = ''
        FILE.NAME = R.NEW(T24.PM.DEF.FILE.NAME)<1,AV>
        RECORD.NAME = R.NEW(T24.PM.DEF.RECORD.NAME)<1,AV>
        LOCATE FILE.NAME IN R.PARAM.RESTRICTION<1> SETTING POS.RESTRIC THEN ; * TM_140925 s
            ETEXT = "EB-PACK.MAN.DONT.SAVE.APPLI"
        END ; * TM_140925 e
        BEGIN CASE
            CASE ETEXT ; * TM_140925
            CASE FILE.NAME = ''
                ETEXT ='EB.DL.INP.MISS'
            CASE FILE.NAME[2] = 'BP'
                TEMP.BP = '' ; R.PROG = ""
                OPEN '',FILE.NAME TO TEMP.BP THEN
                    READV R.PROG FROM TEMP.BP,RECORD.NAME,0 ELSE
                        ETEXT ='EB.DL.PROGRAM.MISS'
                    END
                END ELSE
                    ETEXT ='EB.DL.FILE.DOES.NOT.EXIST'
                END
            CASE OTHERWISE
                FILETYPE = ""                                   ; * TM_070426a s
                OPEN FILE.NAME TO F.APPLI THEN
                    STATUS FSTAT FROM F.APPLI ELSE FSTAT = ""
                    FILETYPE = FSTAT<21>
                END
                IF FILETYPE = "UD" THEN
                    ETEXT = ""
                END ELSE
                    F.APPLI = ""
                    CALL OPF ("F." : FILE.NAME : FM : 'NO.FATAL.ERROR', F.APPLI)
                END                                             ; * TM_070426a e
                IF ETEXT THEN
                    ETEXT ='EB.DL.FILE.DOES.NOT.EXIST'
                END ELSE
                    READ R.APPLI FROM F.APPLI, RECORD.NAME ELSE
                        ETEXT = "EB.DL.REC.MISS.FILE"
                    END
                END ; * TM_060403a e
        END CASE
        IF ETEXT THEN
            AF = T24.PM.DEF.FILE.NAME
            CALL STORE.END.ERROR
        END
    NEXT AV
    IF END.ERROR THEN
        V$ERROR = 1
        MESSAGE = 'ERROR'
    END

*
RETURN          ;* Back to field input via UNAUTH.RECORD.WRITE
*
*===================================================================================
*
OVERRIDES:
*
RETURN
*
*===================================================================================
*
AUTH.CROSS.VALIDATION:
*
RETURN
*
*===================================================================================
*
CHECK.DELETE:
*
RETURN
*
*===================================================================================
*
CHECK.REVERSAL:
*
RETURN
*
*===================================================================================
*
BEFORE.UNAU.WRITE:
*
    IF NOT(R.NEW(T24.PM.DEF.VERSION.CHECK) MATCH '1N0N') THEN
        R.NEW(T24.PM.DEF.VERSION.CHECK) = '0'
    END
    R.NEW(T24.PM.DEF.VERSION.CHECK) = R.NEW(T24.PM.DEF.VERSION.CHECK) + 1

    IF TEXT = "NO" THEN       ;* Said No to override
        CALL TRANSACTION.ABORT          ;* Cancel current transaction
        V$ERROR = 1
        MESSAGE = "ERROR"     ;* Back to field input
        RETURN
    END
*
RETURN
*
*===================================================================================
*
AFTER.UNAU.WRITE:
*
RETURN
*
*===================================================================================
*
AFTER.AUTH.WRITE:
*
RETURN
*
*===================================================================================
*
BEFORE.AUTH.WRITE:
*
    BEGIN CASE
        CASE R.NEW(V-8)[1,3] = "INA"        ;* Record status
            E = ""
            V$ERROR = ""
            HLD.ID = "" ; * TM_20100503
            IF R.NEW(T24.PM.DEF.ACTION)[1, 7] = 'RESTORE' THEN
                OVE.FORCE.INI = OVE$FORCE.OVERRIDES
                OVE$FORCE.OVERRIDES = 1
                GOSUB BEFORE.AUTH.WRITE.RESTORE.PACKAGE
                OVE$FORCE.OVERRIDES = OVE.FORCE.INI
            END ELSE
                GOSUB BEFORE.AUTH.WRITE.SAVE.PACKAGE
            END

            IF E THEN
                CALL ERR
                V$ERROR = 1
                MESSAGE = "ERROR"
            END ELSE
                HISTO.TYPE = R.NEW(T24.PM.DEF.ACTION)
                IF HISTO.TYPE[1, 7] # "RESTORE" THEN
                    HISTO.TYPE = "SAVE"
                END
                I.HISTO = DCOUNT(R.NEW(T24.PM.DEF.HISTO.TYPE), VM) + 1
                R.NEW(T24.PM.DEF.HISTO.TYPE)<1, I.HISTO> = HISTO.TYPE
                R.NEW(T24.PM.DEF.HISTO.USER)<1, I.HISTO> = OPERATOR
                DATE.YYYY = OCONV (DATE(),'DY4')
                DATE.MM = FMT(OCONV (DATE(),'DM'),"R%2")
                DATE.DD = FMT(OCONV (DATE(),'DD'),"R%2")
                DATE.HISTO = DATE.YYYY : DATE.MM : DATE.DD
                R.NEW(T24.PM.DEF.HISTO.DATE)<1, I.HISTO> = DATE.HISTO
                R.NEW(T24.PM.DEF.HISTO.TIME)<1, I.HISTO> = OCONV(TIME(),'MTS') ; * TM_20100503 s
                R.NEW(T24.PM.DEF.HISTO.LOG)<1, I.HISTO> = HLD.ID ; * TM_20100503 e
            END

        CASE R.NEW(V-8)[1,3] = "RNA"
    END CASE
*
RETURN
*
*===================================================================================
*
CHECK.FUNCTION:
*
    IF INDEX('V',V$FUNCTION,1) THEN
        E = 'FUNCTION NOT ALLOWED FOR THIS APPLICATION'
        CALL ERR
        V$FUNCTION = ''
    END
*
RETURN
*
*===================================================================================
*
INITIALISE:
*
    RETURN.OS = SYSTEM(1017)
    IF RETURN.OS <> 'UNIX' THEN
        RETURN.OS = 'NT'
    END
    IF RETURN.OS = 'NT' THEN
        SEP.DIR = "\"
    END ELSE
        SEP.DIR = "/"
    END
    W.SAVEDLISTS = "." : SEP.DIR : "&SAVEDLISTS&"
    W.COMO = "." : SEP.DIR : "&COMO&"

*AF
    COMPILED.OR.NOT = "YES"

    OPEN '','VOC' TO VOC ELSE
        TEXT = 'CANNOT OPEN VOC'
        CALL FATAL.ERROR('DL.PARAMETER')
        RETURN
    END
*
    SAVEDLISTS = ''
    OPEN '',W.SAVEDLISTS TO SAVEDLISTS ELSE
        TEXT = 'CANNOT OPEN &SAVEDLISTS&'
        CALL FATAL.ERROR('T24.W.PACK.MAN')
        RETURN
    END
*
    OPEN './PackMan.BP' TO F.BP ELSE
        TEXT = 'CANNOT OPEN PackMan.BP'
        CALL FATAL.ERROR('T24.W.PACK.MAN')
        RETURN
    END
    OPEN './LEUMI.PACKS' TO F.LEUMI.PACKS ELSE
        TEXT = 'CANNOT OPEN LEUMI.PACKS'
        CALL FATAL.ERROR('T24.W.PACK.MAN')
        RETURN
    END

    FN.ABBREVIATION = "F.ABBREVIATION" ; F.ABBREVIATION = "" ;* TM_20100804
    CALL OPF (FN.ABBREVIATION, F.ABBREVIATION) ;* TM_20100804
*
    CMN = R.COMPANY(3)
*
    ADDNL.INFO = ''
    ADDNL.INFO<1,1> = ''
    ADDNL.INFO<1,2> = ''
    ADDNL.INFO<2,1> = ''
    ADDNL.INFO<2,2> = ''
    ADDNL.INFO<2,3> = ''
    ADDNL.INFO<2,5> = '4'
    ADDNL.INFO<2,6> = '0'
*

*
    R.RECORD.ID = ''
    FILE.CONTROL.LIST = ''

    GOSUB INIT.CAR.SPE.ID.DL.DIR ; * TM_140120

    NOM.SUBR.TRANS = "EB.TRANS" ; * TM_20100806

    READ R.PARAM.RESTRICTION FROM F.BP, "I_T24.W.PACK.MAN-RESTRICTION" ELSE ; * TM_140925 s
        R.PARAM.RESTRICTION = ""
    END ; * TM_140925 e
*
RETURN
*
*===================================================================================
*
DEFINE.PARAMETERS:
*
    MAT F = "" ; MAT N = "" ; MAT T = ""
    MAT CHECKFILE = "" ; MAT CONCATFILE = ""
    ID.CHECKFILE = "" ; ID.CONCATFILE = ""

    ID.F = "REF" ; ID.N = "35..C" ; ID.T = 'ANY'
*
    Z=0
*
    Z+=1 ; F(Z) = 'VERSION.CHECK' ; N(Z) = '30' ; T(Z)<1> = 'A' ; T(Z)<3> = 'NOINPUT'
    Z+=1 ; F(Z) = 'COMPILE.CODE' ; N(Z) = '30' ; T(Z)<1> = '' ; T(Z)<9> = 'HOT.FIELD'
    T(Z)<2> = 'YES_NO_'
    Z += 1 ; F(Z) = "DIRECTORY" ; N(Z) = "50..C" ; T(Z)<1> = "ANY"; T(Z)<9> = 'HOT.FIELD'
    Z += 1 ; F(Z) = "SELECT.LIST" ; N(Z) = "35..C" ; T(Z)<1> = "ANY"; T(Z)<9> = 'HOT.FIELD'
    Z += 1 ; F(Z) = "ACTION" ; N(Z) = "35" ; T(Z)<1> = ""; T(Z)<9> = 'HOT.FIELD'
    T(Z)<2> = 'RESET_TEMPLATE_DELIVERY_MENU_REPGEN_VERSION_ENQUIRY_MAINMENU_RESTORE_RESTORE1_RESTORE1O_RESTORE2_RESTORE3_GENEREO_CHECKIN_CHECKOUT'
    Z += 1 ; F(Z) = "TOP.LEVEL.ITEM" ; N(Z) = "75..C" ; T(Z)<1> = "A"; T(Z)<9> = 'HOT.FIELD'
    Z += 1 ; F(Z) = "XX<FILE.NAME" ; N(Z) = "35..C" ; T(Z)<1> = "A"; T(Z)<9> = 'HOT.FIELD'
    Z += 1 ; F(Z) = "XX>RECORD.NAME" ; N(Z) = "75..C" ; T(Z)<1> = "ANY"; T(Z)<9> = 'HOT.FIELD' ; * TM_20100503
    Z+=1 ; F(Z) = 'XX<HISTO.TYPE' ; N(Z) = '35' ; T(Z) = 'A' ; T(Z)<3> = 'NOINPUT'
    Z+=1 ; F(Z) = 'XX-HISTO.USER' ; N(Z) = '16' ; T(Z) = 'AA' ; T(Z)<3> = 'NOINPUT'
    Z+=1 ; F(Z) = 'XX-HISTO.DATE' ; N(Z) = '11' ; T(Z) = 'D' ; T(Z)<3> = 'NOINPUT'
    Z+=1 ; F(Z) = 'XX-HISTO.TIME' ; N(Z) = '10' ; T(Z) = 'A' ; T(Z)<3> = 'NOINPUT' ; * TM_20100503
    Z+=1 ; F(Z) = 'XX>HISTO.LOG' ; N(Z) = '65' ; T(Z) = 'A' ; T(Z)<3> = 'NOINPUT' ; * TM_20100503
    Z+=1 ; F(Z) = 'RESERVED1' ; N(Z) = '1' ; T(Z) = '' ; T(Z)<3> = 'NOINPUT'
*
    V = Z + 9 ; PREFIX = "T24.PM.DEF."
*
RETURN
*
*===================================================================================
*
EXPAND.NEW.ITEM.LIST:
*
    R.NEW.LIST = ''
    FOR YAV = 1 TO (AV-1)
        R.NEW.LIST<-1> = R.NEW(T24.PM.DEF.FILE.NAME)<1,YAV>:'>':R.NEW(T24.PM.DEF.RECORD.NAME)<1,YAV>
    NEXT YAV
    FOR YAV = 1 TO DCOUNT(R.LIST,FM)
        R.NEW.LIST<-1> = R.LIST<YAV>
    NEXT YAV
    FOR YAV = AV+1 TO DCOUNT(R.NEW(T24.PM.DEF.FILE.NAME),VM)
        R.NEW.LIST<-1> = R.NEW(T24.PM.DEF.FILE.NAME)<1,YAV>:'>':R.NEW(T24.PM.DEF.RECORD.NAME)<1,YAV>
    NEXT YAV
*
RETURN
*
*===================================================================================
*
EXPAND.LIST:
*
    R.NEW(T24.PM.DEF.FILE.NAME) = ''
    R.NEW(T24.PM.DEF.RECORD.NAME) = ''
    MAX.ITEMS = DCOUNT(R.LIST,FM)
    FOR YAV = 1 TO MAX.ITEMS
        ELEM.LIST = R.LIST<YAV>
        IF ELEM.LIST[1, 1] = '"' AND ELEM.LIST[1] = '"' THEN
            ELEM.LIST = ELEM.LIST[2, LEN(ELEM.LIST) - 2]
        END
        IF ELEM.LIST[1,2] = 'F.' THEN
            ELEM.LIST = ELEM.LIST[3,99]
        END
        IF FIELD(ELEM.LIST,'.',1) = 'F':CMN THEN
            ELEM.LIST = FIELD(ELEM.LIST,'.',2,99)
        END

        R.NEW(T24.PM.DEF.FILE.NAME)<1,YAV> = ELEM.LIST['>', 1, 1]
        R.NEW(T24.PM.DEF.RECORD.NAME)<1,YAV> = ELEM.LIST['>', 2, DCOUNT(ELEM.LIST, '>')]
    NEXT YAV
*
RETURN
*
*===================================================================================
*
CREATE.TEMPLATE.LIST:
*
    F.STANDARD.SELECTION = ''
    CALL OPF('F.STANDARD.SELECTION', F.STANDARD.SELECTION)
    F.PGM.FILE = ''
    CALL OPF('F.PGM.FILE', F.PGM.FILE)
    F.EB.API = ''
    CALL OPF('F.EB.API', F.EB.API)
    F.MY.FILE.CONTROL = ''
    CALL OPF('F.FILE.CONTROL', F.MY.FILE.CONTROL)
    FILE.CONTROL.LIST = ''
*
    IF NOT(JUST.BP) THEN
        READ Y.FILE.CONTROL FROM F.MY.FILE.CONTROL, PRG.NAME THEN
            FILE.CONTROL.LIST<-1> = 'FILE.CONTROL>':PRG.NAME
        END
        READ Y.STANDARD.SELECTION FROM F.STANDARD.SELECTION, PRG.NAME THEN
            FILE.CONTROL.LIST<-1> = 'STANDARD.SELECTION>':PRG.NAME
        END
    END

    READ Y.PGM.FILE FROM F.PGM.FILE, PRG.NAME THEN
        FILE.CONTROL.LIST<-1> = 'PGM.FILE>':PRG.NAME
        IF JUST.BP AND Y.PGM.FILE<EB.PGM.TYPE> = "B" AND Y.PGM.FILE<EB.PGM.BATCH.JOB> = "@BATCH.JOB.CONTROL" THEN ;* TM_20100804 s
            READ R.PROG FROM TEMP.BP,PRG.NAME : '.LOAD' THEN
                FILE.CONTROL.LIST<-1> = FILE.NAME : '>' : PRG.NAME : '.LOAD'
            END
            READ R.PROG FROM TEMP.BP,PRG.NAME : '.SELECT' THEN
                FILE.CONTROL.LIST<-1> = FILE.NAME : '>' : PRG.NAME : '.SELECT'
            END
        END ; * IF batch job multi-thread ;* TM_20100804 e
    END
    READ Y.EB.API FROM F.EB.API, PRG.NAME THEN
        FILE.CONTROL.LIST<-1> = 'EB.API>':PRG.NAME
    END

    IF JUST.BP THEN
        RETURN
    END
    GOSUB GET.PGM.SOURCE

RETURN
*
*===================================================================================
*
GET.PGM.SOURCE:
*
    PRG.INFO = ''
    IF COMPILED.OR.NOT THEN
        FILE.NAME = "" ;* TM_20100804 s
        EXECUTE "jshow -c " : PRG.NAME CAPTURING JSHOW.OUTPUT
        NB.LIG = DCOUNT(JSHOW.OUTPUT, FM)
        FOR I.LIG = 1 TO NB.LIG
            OUT.LIG = JSHOW.OUTPUT<I.LIG>
            POS.SRC = INDEX(OUT.LIG, "source file", 1)
            IF POS.SRC THEN
                FILE.NAME = TRIM(OUT.LIG[POS.SRC + 11, LEN(OUT.LIG)])[" ", 1, 1]
                EXIT
            END
        NEXT I.LIG
        IF FILE.NAME NE 'GLOBUS.BP' THEN ;* TM_20100804 e
            TEMP.BP = ''
            R.PROG = ""
            OPEN '',FILE.NAME TO TEMP.BP THEN
                READ R.PROG FROM TEMP.BP,PRG.NAME THEN
                    FILE.CONTROL.LIST<-1> = FILE.NAME:'>':PRG.NAME
                END
                READ R.PROG FROM TEMP.BP,PRG.NAME:'.FIELD.DEFINITIONS' THEN
                    FILE.CONTROL.LIST<-1> = FILE.NAME:'>':PRG.NAME:'.FIELD.DEFINITIONS'
                END
                READ R.PROG FROM TEMP.BP,PRG.NAME:'.FLD.DEFS' THEN
                    FILE.CONTROL.LIST<-1> = FILE.NAME:'>':PRG.NAME:'.FLD.DEFS'
                END
                READ R.PROG FROM TEMP.BP,PRG.NAME:'.CHECK.FIELDS' THEN
                    FILE.CONTROL.LIST<-1> = FILE.NAME:'>':PRG.NAME:'.CHECK.FIELDS'
                END
                READ R.PROG FROM TEMP.BP,PRG.NAME:'.CROSSVAL' THEN
                    FILE.CONTROL.LIST<-1> = FILE.NAME:'>':PRG.NAME:'.CROSSVAL'
                END
                READ R.PROG FROM TEMP.BP,PRG.NAME:'.OVERRIDE' THEN
                    FILE.CONTROL.LIST<-1> = FILE.NAME:'>':PRG.NAME:'.OVERRIDE'
                END
                READ R.PROG FROM TEMP.BP,PRG.NAME:'.ACCOUNTING' THEN
                    FILE.CONTROL.LIST<-1> = FILE.NAME:'>':PRG.NAME:'.ACCOUNTING'
                END
                READ R.PROG FROM TEMP.BP,PRG.NAME:'.FIELDS' THEN ; * TM_20100805 s
                    FILE.CONTROL.LIST<-1> = FILE.NAME:'>':PRG.NAME:'.FIELDS'
                END
                READ R.PROG FROM TEMP.BP,PRG.NAME:'.VALIDATE' THEN
                    FILE.CONTROL.LIST<-1> = FILE.NAME:'>':PRG.NAME:'.VALIDATE'
                END ; * TM_20100805 e
                READ R.PROG FROM TEMP.BP,'I_F.':PRG.NAME THEN
                    FILE.CONTROL.LIST<-1> = FILE.NAME:'>':'I_F.':PRG.NAME
                END
            END
        END
    END
*
RETURN
*
*===================================================================================
*
CREATE.PACKAGE.LIST:
*
    FILE.CONTROL.LIST = ''
    CHEMIN.PACKAGE = R.NEW(T24.PM.DEF.DIRECTORY)
    IF CHEMIN.PACKAGE # "" THEN
        OPEN CHEMIN.PACKAGE TO F.DL.DIRECTORY THEN
* Open fonctionne mme si le dossier n'est pas accessible (droits utilisateurs)
* Open works even if the folder is not accessible (user rights)
            errornumber = ''
            READ RIEN FROM F.DL.DIRECTORY, "TEST" SETTING errornumber ON ERROR
                CRT errornumber
                E = "The folder " : CHEMIN.PACKAGE : " is missing"
                RETURN
            END THEN
                NULL
            END ELSE
                NULL
            END

*            COMMAND = 'SELECT ':CHEMIN.PACKAGE
*            EXECUTE COMMAND CAPTURING OUTPUT
*            READLIST RECORD.LIST ELSE RECORD.LIST = ''
            SEL.CMD1 = 'SELECT ':CHEMIN.PACKAGE
            CALL EB.READLIST(SEL.CMD1,RECORD.LIST,'',SEL.CNT1,SEL.ERR1)
            RECORD.LIST = SORT(RECORD.LIST)
            TOTAL.NUM = DCOUNT(RECORD.LIST,FM)
            IF RECORD.LIST THEN
                FOR RECORD.COUNT = 1 TO TOTAL.NUM
                    RECORD.ID = RECORD.LIST<RECORD.COUNT>
                    READ R.RECORD FROM F.DL.DIRECTORY, RECORD.ID ON ERROR
                        E = "the file Unix " : RECORD.ID : " is not accessible."
                        RETURN
                    END THEN
                        BEGIN CASE
                            CASE INDEX(RECORD.ID, "=", 1) ; * Ancienne forme de nom de fichiers a la Banque de France
                                FOR I.CAR = 1 TO NB.ID.DL.CAR.SPE - 1
                                    CHANGE "=" : ID.DL.CAR.SPE.UNIX[I.CAR, 1] TO ID.DL.CAR.SPE.ORIG[I.CAR, 1] IN RECORD.ID
                                NEXT I.CAR
                            CASE INDEX(RECORD.ID, "^", 1)
                                ID.DL.DIR = RECORD.ID ; * TM_140120
                                GOSUB REVERSE.CAR.SPE.ID.DL.DIR ; * TM_140120
                                RECORD.ID = ID.DL.DIR ; * TM_140120
                        END CASE
                        FILE.CONTROL.LIST<-1> = RECORD.ID['-', 1, 1] : '>' : RECORD.ID['-', 2, 9999]
                    END
                NEXT RECORD.COUNT
            END
        END ELSE
            E = "The folder " : CHEMIN.PACKAGE : " is missing."
        END
    END ELSE
        E ='EB.MUST.SPEC.DIRECTORY'
    END
*
RETURN
*

*
*===================================================================================

VALIDATE.OFS.SOURCE:

    F.OFS.SOURCE = ''
    CALL OPF('F.OFS.SOURCE',F.OFS.SOURCE)

    ID.PRE = 'PACK.MAN' ; * TM_140110
    ID.SUF = 0
    VALID.SOURCE.FOUND = 0

    OFSS.REC = ''
    OFSS.ID = ID.PRE:'.':ID.SUF

    READ OFSS.REC FROM F.OFS.SOURCE, OFSS.ID ELSE
        NULL
    END
    IF OFSS.REC<OFS.SRC.SOURCE.TYPE> = 'GLOBUS' THEN
        RETURN
    END

    OFSS.REC = ''
    OFSS.REC<OFS.SRC.DESCRIPTION> = 'OFS SOURCE FOR AUTHORISING'
    OFSS.REC<OFS.SRC.SOURCE.TYPE> = 'GLOBUS'
    OFSS.REC<OFS.SRC.LOG.FILE.DIR> = 'AUTH.LOG'
    OFSS.REC<OFS.SRC.LOG.DETAIL.LEVEL> = 'FULL'
    OFSS.REC<OFS.SRC.IN.QUEUE.DIR> = 'AUTH.IN'
    OFSS.REC<OFS.SRC.SYNTAX.TYPE> = 'OFS'
    OFSS.REC<OFS.SRC.CURR.NO> = 1
    OFSS.REC<OFS.SRC.INPUTTER> = TNO:'_':OPERATOR
    DATETIME = OCONV(DATE(),"D-")
    DATETIME = DATETIME[9,4]:DATETIME[1,2]:DATETIME[4,2]
    YTIME = OCONV(TIME(),'MT')
    DATETIME := YTIME[1,2]:YTIME[4,2]
    OFSS.REC<OFS.SRC.DATE.TIME> = DATETIME
    OFSS.REC<OFS.SRC.AUTHORISER> = TNO:'_':OPERATOR
    OFSS.REC<OFS.SRC.CO.CODE> = ID.COMPANY
    OFSS.REC<OFS.SRC.DEPT.CODE> = R.USER<EB.USE.DEPARTMENT.CODE>
    WRITE OFSS.REC TO F.OFS.SOURCE, OFSS.ID ON ERROR
        TEXT = 'CANNOT CREATE OFS SOURCE RECORD'
        CALL FATAL.ERROR('AUTH.RECORDS')
    END

    CHK.NAME.LIST = 'AUTH.IN':FM:'AUTH.OUT':FM:'AUTH.LOG'
    FOR I = 1 TO 3
        CHK.NAME = CHK.NAME.LIST<I>
        OPEN CHK.NAME TO F.TEMP ELSE
            CALL !HUSHIT(1)
            EXECUTE "CREATE-FILE ":CHK.NAME:" TYPE=UD"
            EXECUTE "DELETE ":CHK.NAME:" .jbase_header"
            CALL !HUSHIT(0)
            READ R.VOC FROM VOC, CHK.NAME ELSE
                R.VOC<1> = "F"
                R.VOC<2> = CHK.NAME
                R.VOC<3> = CHK.NAME:"]D"
                WRITE R.VOC TO VOC,CHK.NAME
            END
        END
    NEXT I

RETURN
*
*===================================================================================
*
PROCESS.DYN.TO.OFS:

    SS.ID = APPLI

    GOSUB BUILD.OFS.BODY

    OFS.HEADER = OFS.APP.VER :'/': OFS.FUNC :'/': OFS.ACTION :'/': OFS.CONTROL :'/': OFS.AUTH.NO :','
    OFS.HEADER := ',': CONVERT(",/", "?^", OFS.TXN.ID) :','
    OFS.MESSAGE = OFS.HEADER : OFS.BODY
*
RETURN
*
*===================================================================================
*
BUILD.OFS.BODY:
*
    IF NOT(R.DYN.MESSAGE) THEN RETURN
    CALL CACHE.READ(FN.SS,SS.ID,R.SS,ERR.SS)
    IF ERR.SS THEN
        ETEXT = SS.ID:' - ':FN.SS:' ':ERR.SS
        RETURN
    END

    NO.OF.FIELDS = DCOUNT(R.DYN.MESSAGE,@FM)
    FOR FLD.NO = 1 TO NO.OF.FIELDS
        LOCATE FLD.NO IN R.SS<SSL.SYS.FIELD.NO,1> SETTING FNO.POS THEN
            FLD.NAME = R.SS<SSL.SYS.FIELD.NAME,FNO.POS>
            FLD.PROP = CHANGE(R.SS<SSL.SYS.VAL.PROG,FNO.POS>,'&',@FM,0)
            INPUT.ENABLED = (FLD.PROP<3> NE 'NOINPUT') AND (FLD.PROP<3> NE 'EXTERN') AND NOT(FLD.NAME MATCHES AUDIT.FIELDS)
            IF INPUT.ENABLED THEN
                GOSUB APPEND.TO.OFS.BODY
            END
        END
    NEXT FLD.NO
*
RETURN
*
*===================================================================================
*
APPEND.TO.OFS.BODY:
*
    NO.OF.MVS = DCOUNT(R.DYN.MESSAGE<FLD.NO>,VM)
    IF NOT(NO.OF.MVS) THEN
        NO.OF.MVS = 1
    END

    FOR MV.NO = 1 TO NO.OF.MVS
        NO.OF.SVS = DCOUNT(R.DYN.MESSAGE<FLD.NO,MV.NO>,SM)
        IF NOT(NO.OF.SVS) THEN
            NO.OF.SVS = 1
        END

        FOR SV.NO = 1 TO NO.OF.SVS
            FLD.VAL = R.DYN.MESSAGE<FLD.NO,MV.NO,SV.NO>
            IF FLD.VAL EQ '' AND PROCESS.NULL THEN
                FLD.VAL = "NULL"
            END

            IF FLD.VAL # "" THEN
                CONVERT "'" : '",()' TO "@|?{}" IN FLD.VAL
                FLD.VAL = '"':FLD.VAL:'"'
                OFS.BODY := FLD.NAME :':': MV.NO :':': SV.NO :'=': FLD.VAL :','
            END
        NEXT SV.NO

        NOLD.OF.SVS = DCOUNT(R.OLD.DYN.MESSAGE<FLD.NO,MV.NO>,SM)
        FOR SV.NO = NO.OF.SVS + 1 TO NOLD.OF.SVS
            OFS.BODY := FLD.NAME :':': MV.NO :':': SV.NO :'=-,'
        NEXT SV.NO
    NEXT MV.NO

    NOLD.OF.MVS = DCOUNT(R.OLD.DYN.MESSAGE<FLD.NO>,VM)
    FOR MV.NO = NO.OF.MVS + 1 TO NOLD.OF.MVS
        OFS.BODY := FLD.NAME :':': MV.NO :':1=-,'
    NEXT MV.NO
*
RETURN
*
*===================================================================================
*
INIT.DYN.TO.OFS:
*
    OFS.BODY = ''
    OFS.HEADER = ''
    OFS.MESSAGE = ''
*
    FN.SS = 'F.STANDARD.SELECTION'
    AUDIT.FIELDS = 'RECORD.STATUS' :VM: 'CURR.NO' :VM: 'INPUTTER'
    AUDIT.FIELDS := VM: 'DATE.TIME' :VM: 'AUTHORISER' :VM: 'CO.CODE'
    AUDIT.FIELDS := VM: 'DEPT.CODE' :VM: 'AUDITOR.CODE' :VM: 'AUDIT.DATE.TIME'
    OFS.VER = ADDNL.INFO<1,1>
    OFS.FUNC = ADDNL.INFO<1,2>

    IF NOT(OFS.FUNC) THEN
        OFS.FUNC = 'I'
    END

    OFS.ACTION = ADDNL.INFO<2,1>
    IF NOT(OFS.ACTION) THEN
        OFS.ACTION = 'PROCESS'
    END

    OFS.TXN.ID = ADDNL.INFO<2,4>
    OFS.CONTROL = ADDNL.INFO<2,5>
    OFS.AUTH.NO = ADDNL.INFO<2,6>
    OFS.APP.VER = APPLI :',': OFS.VER
*
RETURN
*===================================================================================

*
BEFORE.AUTH.WRITE.SAVE.PACKAGE:
*
    FN.SS = 'F.STANDARD.SELECTION'
    FN.PGM.FILE = 'F.PGM.FILE'
    F.PGM.FILE = ''
    CALL OPF (FN.PGM.FILE, F.PGM.FILE)

    PATH.SAVE = R.NEW(T24.PM.DEF.DIRECTORY)
    
    OPEN PATH.SAVE TO F.DL.DIRECTORY THEN
        COMMAND = 'SELECT ' : PATH.SAVE
        CALL EB.READLIST (COMMAND,RECORD.LIST, '', TOTAL.NUM,CODE)
        IF RECORD.LIST THEN
            FOR RECORD.COUNT = 1 TO TOTAL.NUM
                DELETE F.DL.DIRECTORY, RECORD.LIST<RECORD.COUNT> ON ERROR
*                    E = "Impossible d'effacer " : RECORD.LIST<RECORD.COUNT> : " dans " : PATH.SAVE
                    E = "Can not delete " : RECORD.LIST<RECORD.COUNT> : " in " : PATH.SAVE
                    RETURN
                END
            NEXT RECORD.COUNT
        END
    END ELSE
        EXECUTE "CREATE-FILE DATA " : PATH.SAVE : " TYPE=UD" CAPTURING RIEN
        EXECUTE "DELETE " : PATH.SAVE : " .jbase_header" CAPTURING RIEN
        OPENSEQ PATH.SAVE,'\\.' TO F.DL.DIRECTORY THEN
            CRT 'Ok'
        END ELSE
            CREATE F.DL.DIRECTORY
            IF F.DL.DIRECTORY THEN
                GOTO BEFORE.AUTH.WRITE.SAVE.PACKAGE
            END ELSE
*            E = "Impossible de creer le repertorie " : PATH.SAVE
                E = "Can not create directory " : PATH.SAVE
                RETURN
            END
        END

    END

    PROCESS.RESULT = ''

    T24.PM.DEF.FILE = CHANGE(R.NEW(T24.PM.DEF.FILE.NAME),VM,FM)
    T24.PM.DEF.RECORD = CHANGE(R.NEW(T24.PM.DEF.RECORD.NAME),VM,FM)
    NBR.DL.DEF.FILE = DCOUNT(T24.PM.DEF.FILE,FM)
*
    FOR I = 1 TO NBR.DL.DEF.FILE
        FILETYPE = 'J4'
        APPLI = T24.PM.DEF.FILE<I>
        ID.APPLI = T24.PM.DEF.RECORD<I>
        CALL DISPLAY.MESSAGE('Processing : ':I:' on ':NBR.DL.DEF.FILE:' - ':APPLI:'.':ID.APPLI,1)
        OPEN APPLI TO F.CURRENT.FILE THEN
            STATUS FSTAT FROM F.CURRENT.FILE ELSE FSTAT = ""
            FILETYPE = FSTAT<21>
        END
        N0.CHAMP.RECORD.STATUS = 0
        IF FILETYPE = "UD" THEN
            F.APPLI = F.CURRENT.FILE
        END ELSE
            F.APPLI = ''
            FN.APPLI = 'F.':APPLI
            CALL OPF(FN.APPLI : FM : "NO.FATAL.ERROR", F.APPLI)
            IF ETEXT THEN
                E = "The application " : APPLI : " is missing (unable to open the table)"
                RETURN
            END
            CALL CACHE.READ(FN.SS,APPLI,R.SS,ERR.SS)
            IF ERR.SS THEN
                E = 'UNABLE TO READ STANDARD.SELECTION ' : APPLI
                RETURN
            END
            LOCATE "RECORD.STATUS" IN R.SS<SSL.SYS.FIELD.NAME, 1> SETTING MV.FIELD THEN
                N0.CHAMP.RECORD.STATUS = R.SS<SSL.SYS.FIELD.NO, MV.FIELD>
            END
        END

        READ R.APPLI FROM F.APPLI, ID.APPLI THEN
            IF FILETYPE = "UD" AND APPLI[2] = "BP" AND ID.APPLI[1, 1] # "$" THEN
                IF INDEX(R.APPLI, "DEBUG", 1) THEN
                    TEXT = "**********" ; * TM_100331
                    CALL REM ; * TM_100331
                    TEXT = 'The routine ' : ' ' : ID.APPLI : ' contains a DEBUG' ; * TM_100331
                    PROCESS.RESULT<-1> = TEXT ; * TM_100331
                    CALL REM ; * TM_100331
                    TEXT = "**********" ; * TM_100331
                    CALL REM ; * TM_100331
                END
            END
            OFS.LINE = R.APPLI
            IF N0.CHAMP.RECORD.STATUS THEN
                OFS.LINE<N0.CHAMP.RECORD.STATUS> = "IHLD"
                FOR I.CHAMP = 1 TO 8
                    OFS.LINE<N0.CHAMP.RECORD.STATUS + I.CHAMP> = ""
                NEXT I.CHAMP
            END
            CHANGE "\" TO "/" IN APPLI
            ID.DL.DIR = APPLI : '-' : ID.APPLI
            GOSUB CAR.SPE.ID.DL.DIR
            IF FILETYPE = "UD" AND APPLI[2] = "BP" AND ID.APPLI[1, 1] = "$" THEN
* Pour les codes objets BASIC on fait une copie Unix, sinon jBase transforme les CHAR(10) en CHAR(254)
* L'option -f permet de supprimer les questions
* For BASIC object codes we make a Unix copy, otherwise jBase transforms CHAR (10) into CHAR (254)
* The -f option suppress the questions
                COMMAND = "cp -fp " : APPLI : SEP.DIR : ID.APPLI : " " : PATH.SAVE : SEP.DIR : ID.DL.DIR
                EXECUTE COMMAND CAPTURING RIEN
* Pour traiter les cas d'erreurs de copie on fait une comparaison
* For the treatment in case of errors when comparing copies
                COMMAND = "cmp -s " : APPLI : SEP.DIR : "\" : ID.APPLI : " " : PATH.SAVE : SEP.DIR : ID.DL.DIR : " ; echo $?"
                EXECUTE CHARX(255) : "k" : COMMAND CAPTURING RESULTAT.CMP
                IF RESULTAT.CMP THEN
                    E = "Unable to re-copy " : APPLI : " " : ID.APPLI : " in " : PATH.SAVE : SEP.DIR : ID.DL.DIR
                    RETURN
                END
            END ELSE
                WRITE OFS.LINE TO F.DL.DIRECTORY, ID.DL.DIR ON ERROR
                    E = "Unable to write " : ID.DL.DIR : " in " : PATH.SAVE
                    RETURN
                END
            END
        END

    NEXT I

*
    COMMAND = 'SELECT ':PATH.SAVE
;*    COMMAND = 'SELECT ':  Y.FILENAME
    CALL EB.READLIST(COMMAND,RECORD.LIST,'',TOTAL.NUM,CODE)
    IF PROCESS.RESULT # "" THEN
        PROCESS.RESULT<-1> = '--------------------------------------------------------'
        FOR I.LIG = 1 TO 10
            PROCESS.RESULT<-1> = ''
        NEXT I.LIG
    END

    PROCESS.RESULT<-1> = '--------------------------------------------------------'
    PROCESS.RESULT<-1> = 'START PROCESSING UNIT ':PATH.SAVE
    IF RECORD.LIST THEN
        FOR RECORD.COUNT = 1 TO TOTAL.NUM
            PROCESS.RESULT<-1> = 'ELEMENT PROCESSED - ':RECORD.LIST<RECORD.COUNT>
        NEXT RECORD.COUNT
    END

    PROCESS.RESULT<-1> = '--------------------------------------------------------'
    PROCESS.RESULT<-1> = 'END PROCESSING UNIT ':PATH.SAVE
    F.LISTS = ''
    TEXT = ''

    WRITE PROCESS.RESULT TO SAVEDLISTS, ID.NEW ON ERROR
        E = 'UNABLE TO WRITE LOG FILE'
        RETURN
    END

    HLD.ID = ID.NEW
    IF NOT(GTSACTIVE) THEN
        CALL REPORT.VIEW(W.SAVEDLISTS,HLD.ID)
    END
*
RETURN
*===================================================================================

*
*===================================================================================
*
*===================================================================================
*
BEFORE.AUTH.WRITE.RESTORE.PACKAGE:
*
* Preparation avant restauration
    FN.PGM.FILE = 'F.PGM.FILE'
    F.PGM.FILE = ''
    CALL OPF (FN.PGM.FILE, F.PGM.FILE)

    GOSUB VALIDATE.OFS.SOURCE
        
    UNIX.FILENAME = R.NEW(T24.PM.DEF.DIRECTORY)
    OPEN UNIX.FILENAME TO F.UNIX.FILENAME ELSE
        E = 'UNABLE TO OPEN ' : UNIX.FILENAME
        RETURN
    END
*
    INI.UNIX.FILENAME = "PackMan.BP"
    OPEN INI.UNIX.FILENAME TO F.UNIX.FILENAME.INI ELSE
        E = 'UNABLE TO OPEN ' : INI.UNIX.FILENAME
        RETURN
    END

    READ PRIORITY.LIST1 FROM F.UNIX.FILENAME.INI, "I_T24.W.PACK.MAN-RESTORE1" ELSE
        READ PRIORITY.LIST1 FROM F.BP, "I_T24.W.PACK.MAN-RESTORE1" ELSE
            E = 'UNABLE TO READ I_T24.W.PACK.MAN-RESTORE1 FROM PackMan.BP'
            RETURN
        END
    END
    READ PRIORITY.LIST2 FROM F.UNIX.FILENAME.INI, "I_T24.W.PACK.MAN-RESTORE2" ELSE
        READ PRIORITY.LIST2 FROM F.BP, "I_T24.W.PACK.MAN-RESTORE2" ELSE
            E = 'UNABLE TO READ I_T24.W.PACK.MAN-RESTORE2 FROM PackMan.BP'
            RETURN
        END
    END
    READ PRIORITY.LIST3 FROM F.UNIX.FILENAME.INI, "I_T24.W.PACK.MAN-RESTORE3" ELSE
        READ PRIORITY.LIST3 FROM F.BP, "I_T24.W.PACK.MAN-RESTORE3" ELSE
            E = 'UNABLE TO READ I_T24.W.PACK.MAN-RESTORE3 FROM PackMan.BP'
            RETURN
        END
    END

    READ LIST.APPLI.INTERNAL.DEPENDENCE FROM F.UNIX.FILENAME.INI, "I_T24.W.PACK.MAN-APPLI.INTERNAL.DEPENDENCE" ELSE  ;* TM_140110 s
        READ LIST.APPLI.INTERNAL.DEPENDENCE FROM F.BP, "I_T24.W.PACK.MAN-APPLI.INTERNAL.DEPENDENCE" ELSE
            E = 'UNABLE TO READ I_T24.W.PACK.MAN-APPLI.INTERNAL.DEPENDENCE FROM PackMan.BP'
            RETURN
        END
    END   ;* TM_140110 e

    READ LIST.APPLI.TO.IGNORE FROM F.UNIX.FILENAME.INI, "I_T24.W.PACK.MAN-APPLI.TO.IGNORE" ELSE  ;* TM_140120 s
        READ LIST.APPLI.TO.IGNORE FROM F.BP, "I_T24.W.PACK.MAN-APPLI.TO.IGNORE" ELSE
            E = 'UNABLE TO READ I_T24.W.PACK.MAN-APPLI.TO.IGNORE FROM PackMan.BP'
            RETURN
        END
    END   ;* TM_140120 e

    PRIORITY.LIST = PRIORITY.LIST1 : FM : PRIORITY.LIST2 : FM : PRIORITY.LIST3

    NBR.PRIORITY.LIST = DCOUNT(PRIORITY.LIST,FM)
    SORTED.LIST.ID = ''
    FOR I = 1 TO NBR.PRIORITY.LIST
        SORTED.LIST.ID<I> = ''
    NEXT I

    R.RECORD.ID = ""
    REMOVE.LIST = ""
    NBR.DL.DEF.FILE = DCOUNT(R.NEW(T24.PM.DEF.RECORD.NAME), @VM)
    FOR I = 1 TO NBR.DL.DEF.FILE
        TABLE.NAME = R.NEW(T24.PM.DEF.FILE.NAME)<1, I>      ;* TM_20120125 s
        LOCATE TABLE.NAME IN LIST.APPLI.TO.IGNORE<1> SETTING POS.IGNORE THEN    ;* TM_140120 s
            CONTINUE
        END         ;* TM_140120 e
        ID.APPLI = R.NEW(T24.PM.DEF.RECORD.NAME)<1, I>
        RECORD.ID = TABLE.NAME : "-" : ID.APPLI
        R.RECORD.ID<-1> = RECORD.ID
        IF TABLE.NAME[2] = "BP" AND ID.APPLI[1, 9] = "I_REMOVE_" THEN
            IF REMOVE.LIST THEN
                REMOVE.LIST := FM
            END
            REMOVE.LIST := RECORD.ID
        END         ;* TM_20120125 e
    NEXT I

* Remove I_REMOVE_ objects from list
    LOOP  ;* TM_20120125 s
        REMOVE RECORD.ID FROM REMOVE.LIST SETTING POS.REMOVE
    WHILE RECORD.ID : POS.REMOVE DO
        ID.DL.DIR = RECORD.ID
        GOSUB CAR.SPE.ID.DL.DIR
        READ R.LIST.REMOVE FROM F.UNIX.FILENAME, ID.DL.DIR THEN
            NB.LIG = DCOUNT(R.LIST.REMOVE, FM)
            FOR I.LIG = 1 TO NB.LIG
                GOSUB REMOVE.R.RECORD.ID
            NEXT I.LIG
        END
    REPEAT          ;* TM_20120125 e

    NBR.DL.DEF.FILE = DCOUNT(R.RECORD.ID,FM)
    FOR I = 1 TO NBR.DL.DEF.FILE
        RECORD.ID = R.RECORD.ID<I>
        ID.DL.DIR = RECORD.ID
        GOSUB CAR.SPE.ID.DL.DIR
        TABLE.NAME = FIELD(RECORD.ID,'-',1)
        ID.APPLI = RECORD.ID["-", 2, 9999]
        BEGIN CASE
            CASE TABLE.NAME[LEN(TABLE.NAME)-2,3] = '.BP'
                BEGIN CASE
                    CASE ID.APPLI[1, 10] = 'I_COMPILE_'
                        TABLE.NAME = 'I_COMPILE_.BP'
                    CASE ID.APPLI[1, 9] = 'I_REMOVE_'     ;* TM_20100422, TM_20120125
                        TABLE.NAME = 'I_REMOVE_.BP'       ;* TM_20100422
                    CASE ID.APPLI[1, 2] = 'I_'
                        TABLE.NAME = 'I_.BP'
                    CASE OTHERWISE
                        TABLE.NAME = '.BP'
                END CASE
            CASE TABLE.NAME = 'VERSION' AND ID.APPLI[10] = ",MIGRATION"
                TABLE.NAME := "_MIGRATION"
            CASE TABLE.NAME = 'VERSION'
                READ R.APPLI FROM F.UNIX.FILENAME, ID.DL.DIR THEN
                    IF R.APPLI<EB.VER.ASSOC.VERSION> # '' THEN
                        TABLE.NAME := "_ASSOC"
                    END
                END
        END CASE

        ID.SS = ""
        BEGIN CASE
            CASE TABLE.NAME = ".BP"
                ID.SS.TEST = ""   ;* TM_20100506 s
                IF ID.APPLI[7] = ".FIELDS" THEN       ;* TM_20100113, TM_20100419
                    ID.SS.TEST = ID.APPLI[".", 1, DCOUNT(ID.APPLI, ".") - 1]        ;* TM_20100113
                END ELSE IF ID.APPLI[9] = ".FLD.DEFS" OR ID.APPLI[18] = ".FIELD.DEFINITIONS" THEN
                    ID.SS.TEST = ID.APPLI[".", 1, DCOUNT(ID.APPLI, ".") - 2]
                END ELSE
                    ID.SS.TEST = ID.APPLI
                END
                IF ID.SS.TEST[1, 1] = "$" THEN
                    ID.SS.TEST = ID.SS.TEST[2, LEN(ID.SS.TEST)]       ;* TM_20100806
                END
                CALL F.READ (FN.PGM.FILE, ID.SS.TEST, R.PGM.FILE, F.PGM.FILE, ERR.PGM.FILE)
                IF ERR.PGM.FILE = "" THEN
                    MY.PGM.TYPE = R.PGM.FILE<EB.PGM.TYPE>
                    IF MY.PGM.TYPE # "" AND INDEX("HULTWD", MY.PGM.TYPE, 1) THEN
                        ID.SS = ID.SS.TEST
                    END
                END ;* TM_20100506 e
            CASE TABLE.NAME = "PGM.FILE"
                READ R.APPLI FROM F.UNIX.FILENAME, ID.DL.DIR THEN
                    MY.PGM.TYPE = R.APPLI<EB.PGM.TYPE>
                    IF MY.PGM.TYPE # "" AND INDEX("HULTWD", MY.PGM.TYPE, 1) THEN
                        ID.SS = ID.APPLI
                        TABLE.NAME := "_TABLE"
                    END
                END
            CASE TABLE.NAME = "FILE.CONTROL"
                ID.SS = ID.APPLI
            CASE TABLE.NAME = "EB.TABLE.DEFINITION"         ;* TM_20100401
                READ R.APPLI FROM F.UNIX.FILENAME, ID.DL.DIR THEN     ;* TM_20100401
                    ID.SS = R.APPLI<DYN.ACT.PRODUCT> : "." : ID.APPLI ;* TM_20100401
                END ;* TM_20100401
        END CASE
* TM_20100506 : Move 3 lines
        IF ID.SS # "" THEN
            LOCATE "REGEN_STANDARD.SELECTION" IN PRIORITY.LIST<1> SETTING WHERE.IT.IS THEN
                ID.SS = "REGEN_STANDARD.SELECTION-" : ID.SS
                LOCATE ID.SS IN SORTED.LIST.ID<WHERE.IT.IS, 1> SETTING POS.ID ELSE
                    SORTED.LIST.ID<WHERE.IT.IS, -1> = ID.SS
                END
            END
        END
* Ajout d'autres objets ;* TM_20100804 s
        IF TABLE.NAME = "EB.ALTERNATE.KEY" THEN
            READ R.APPLI FROM F.UNIX.FILENAME, ID.DL.DIR THEN
                IF R.APPLI<EB.ALT.KEY.BUILD.ROUTINE> # "" THEN
                    LOCATE "BUILD_EB.ALTERNATE.KEY" IN PRIORITY.LIST<1> SETTING WHERE.IT.IS THEN
                        ID.BUILD = "BUILD_EB.ALTERNATE.KEY-" : ID.APPLI
                        LOCATE ID.BUILD IN SORTED.LIST.ID<WHERE.IT.IS, 1> SETTING POS.ID ELSE
                            SORTED.LIST.ID<WHERE.IT.IS, -1> = ID.BUILD
                        END
                    END   ;* LOCATE BUILD_EB.ALTERNATE.KEY
                END       ;* IF presence build routine
            END ;* READ
        END     ;* IF EB.ALTERNATE.KEY ; * TM_20100804 e
        LOCATE TABLE.NAME IN PRIORITY.LIST<1> SETTING WHERE.IT.IS ELSE
            WHERE.IT.IS = NBR.PRIORITY.LIST
        END
        IF SORTED.LIST.ID<WHERE.IT.IS> # "" THEN
            SORTED.LIST.ID<WHERE.IT.IS> := VM
        END
        SORTED.LIST.ID<WHERE.IT.IS> := RECORD.ID
    NEXT I

    POS.LIST.FIN1 = DCOUNT(PRIORITY.LIST1, FM)
    POS.LIST.FIN2 = POS.LIST.FIN1 + DCOUNT(PRIORITY.LIST2, FM)

    BEGIN CASE
        CASE R.NEW(T24.PM.DEF.ACTION)[1, 8] = "RESTORE1"
            FOR I.LIST = POS.LIST.FIN1 + 1 TO NBR.PRIORITY.LIST
                SORTED.LIST.ID<I.LIST> = ""
            NEXT I.LIST
        CASE R.NEW(T24.PM.DEF.ACTION) = "RESTORE2"
            FOR I.LIST = 1 TO POS.LIST.FIN1
                SORTED.LIST.ID<I.LIST> = ""
            NEXT I.LIST
            FOR I.LIST = POS.LIST.FIN2 + 1 TO NBR.PRIORITY.LIST
                SORTED.LIST.ID<I.LIST> = ""
            NEXT I.LIST
        CASE R.NEW(T24.PM.DEF.ACTION) = "RESTORE3"
            FOR I.LIST = 1 TO POS.LIST.FIN2
                SORTED.LIST.ID<I.LIST> = ""
            NEXT I.LIST
    END CASE

    R.RECORD.ID = SORTED.LIST.ID
    CONVERT VM : FM TO "  " IN R.RECORD.ID
    R.RECORD.ID = TRIM(R.RECORD.ID)
    CONVERT " " TO FM IN R.RECORD.ID
    NBR.ITEM = DCOUNT(R.RECORD.ID, FM)

    LIST.ID.INTERNAL.DEPENDENCE = ""          ;* TM_140110
    R.STD.SEL.LR.ID = ""
    NBR.ERREUR = 0
    PROCESS.RESULT = ''
    RESULT.ERRORS = ''

    DATE.YY = OCONV (DATE(),'DY2')
    DATE.MM = FMT(OCONV (DATE(),'DM'),"R%2")
    DATE.DD = FMT(OCONV (DATE(),'DD'),"R%2")
    DATE.STATUS = DATE.YY : DATE.MM : DATE.DD
    HEURE.STATUS = OCONV(TIME(), "MT")
    CONVERT ":" TO "" IN HEURE.STATUS
    DATE.HEURE.STATUS = DATE.STATUS : HEURE.STATUS

    FOR I = 1 TO NBR.ITEM
        RECORD.ID = R.RECORD.ID<I>
        IF NOT(RECORD.ID) THEN CONTINUE
        GOSUB CLEAR.STATIC.CACHE    ;* TM_20100809
        ID.DL.DIR = RECORD.ID
        GOSUB CAR.SPE.ID.DL.DIR
        PROCESS.RESULT<-1> = '--------------------------------------------------------'
        PROCESS.RESULT<-1> = RECORD.ID:'-':' Start installation'
        CALL DISPLAY.MESSAGE('Processing: ':I:' on ':NBR.ITEM:' - ':RECORD.ID,1)
        APPLI = RECORD.ID["-", 1, 1]
        ID.APPLI = RECORD.ID["-", 2, 9999]
        IF APPLI = "REGEN_STANDARD.SELECTION" THEN
            NEW.FILE = ''
            NEW.FILE<1> = 'F.':ID.APPLI
            NEW.FILE<2> = 'NO.FATAL.ERROR'
            CALL OPF(NEW.FILE,F.NEW.FILE)
            IF NOT(ETEXT) THEN
                FN.STANDARD.SELECTION = 'F.STANDARD.SELECTION'    ;* TM_140110 s
                F.STANDARD.SELECTION = ''
                CALL OPF(FN.STANDARD.SELECTION, F.STANDARD.SELECTION)
                FN.STANDARD.SELECTION$NAU = 'F.STANDARD.SELECTION$NAU'
                F.STANDARD.SELECTION$NAU = ''
                CALL OPF(FN.STANDARD.SELECTION$NAU, F.STANDARD.SELECTION$NAU)

* Before rebuild, remove all SYS.REL.FILE
                READ R.SS.LIVE FROM F.STANDARD.SELECTION, ID.APPLI ELSE
                    R.SS.LIVE = ""
                END
                READU R.SS$NAU FROM F.STANDARD.SELECTION$NAU, ID.APPLI ELSE
                    R.SS$NAU = R.SS.LIVE
                    IF R.SS$NAU THEN
                        R.SS$NAU<SSL.RECORD.STATUS> = "IHLD"
                        FOR I.FLD = SSL.CURR.NO TO SSL.AUDIT.DATE.TIME
                            R.SS$NAU<I.FLD> = ""
                        NEXT I.FLD
                    END
                END
                SS.MODIFIED = 0
                FOR I.SS = DCOUNT(R.SS$NAU<SSL.SYS.REL.FILE>, VM) TO 1 STEP -1
                    IF R.SS$NAU<SSL.SYS.GENERATED, I.SS> = "Y" AND R.SS$NAU<SSL.SYS.REL.FILE, I.SS> THEN
                        R.SS$NAU<SSL.SYS.REL.FILE, I.SS> = ""
                        SS.MODIFIED = 1
                    END
                NEXT I.SS
                IF SS.MODIFIED THEN
                    WRITE R.SS$NAU ON F.STANDARD.SELECTION$NAU, ID.APPLI
                END ELSE
;*      RELEASE F.STANDARD.SELECTION$NAU, ID.APPLI
                    CALL F.RELEASE (F.STANDARD.SELECTION$NAU,ID.APPLI,FN.STANDARD.SELECTION$NAU)
                END       ;* TM_140110 e

                OFS.MESSAGE = 'STANDARD.SELECTION,/I/PROCESS/1/0,,' : CONVERT(",/", "?^", ID.APPLI)       ;* TM_140210
                OFS.MESSAGE := ',REBUILD.SYS.FLDS=Y'
                CALL OFS.GLOBUS.MANAGER(OFSS.ID,OFS.MESSAGE)
                IF OFS.MESSAGE['/', 3 + COUNT(ID.APPLI, "/"), 1] = -1 THEN
                    MESSAGE.RESULT = "! " : RECORD.ID:'-':' Error re-generation ':OFS.MESSAGE:' for STANDARD.SELECTION ':ID.APPLI
                    PROCESS.RESULT<-1> = MESSAGE.RESULT
                    RESULT.ERRORS<-1> = MESSAGE.RESULT
                    NBR.ERREUR = NBR.ERREUR + 1
                END ELSE
                    PROCESS.RESULT<-1> = RECORD.ID:'-':' Regeneration correcte de STANDARD.SELECTION ':ID.APPLI
                    READ A.SS FROM F.STANDARD.SELECTION, ID.APPLI THEN
                        PROCESS.RESULT<-1> = RECORD.ID:'-':' STANDARD.SELECTION ' : ID.APPLI : " contains " : DCOUNT(A.SS<SSL.SYS.FIELD.NAME>, @VM) : " field(s)"
                    END ELSE
                        MESSAGE.RESULT = "! " : RECORD.ID:'-':" Nothing generate in STANDARD.SELECTION " : ID.APPLI
                        PROCESS.RESULT<-1> = MESSAGE.RESULT
                        RESULT.ERRORS<-1> = MESSAGE.RESULT
                        NBR.ERREUR = NBR.ERREUR + 1
                    END
                END
            END ELSE
                MESSAGE.RESULT = "! " : RECORD.ID:'-':' unknown table, regeneration impossible STANDARD.SELECTION ':ID.APPLI
                PROCESS.RESULT<-1> = MESSAGE.RESULT
                RESULT.ERRORS<-1> = MESSAGE.RESULT
                NBR.ERREUR = NBR.ERREUR + 1
            END
        END ELSE IF APPLI = "BUILD_EB.ALTERNATE.KEY" THEN     ;* TM_20100804 s
            OFS.MESSAGE = 'EB.ALTERNATE.KEY,/V/PROCESS//0,,' : CONVERT(",/", "?^", ID.APPLI)          ;* Fonction Verify pour generer les concat et GTS.CONTROL vide pour ne jamais mettre en IHLD
            GOSUB TRANS.END     ;* TM_20100806
            CALL OFS.GLOBUS.MANAGER(OFSS.ID,OFS.MESSAGE)
            IF OFS.MESSAGE['/', 3 + COUNT(ID.APPLI, "/"), 1][",", 1, 1] # 1 THEN
                MESSAGE.RESULT = "! " : RECORD.ID:'-':' Erreur OFS ':OFS.MESSAGE:' pendant la creation des concat pour EB.ALTERNATE.KEY ':ID.APPLI
                PROCESS.RESULT<-1> = MESSAGE.RESULT
                RESULT.ERRORS<-1> = MESSAGE.RESULT
                NBR.ERREUR = NBR.ERREUR + 1
            END
            GOSUB TRANS.START   ;* TM_20100806
        END ELSE
            FILETYPE = 'J4'
            OPEN APPLI TO F.CURRENT.FILE THEN
                STATUS FSTAT FROM F.CURRENT.FILE ELSE FSTAT = ""
                FILETYPE = FSTAT<21>
            END
            BEGIN CASE
                CASE FILETYPE = "UD"
*AF                        OPEN APPLI TO F.APPLI ELSE
*AF                            EXECUTE "CREATE-FILE DATA " : APPLI : " TYPE=UD" CAPTURING RIEN
*AF                            EXECUTE "DELETE " : APPLI : " .jbase_header" CAPTURING RIEN
                    OPEN APPLI TO F.APPLI ELSE
                        MESSAGE.RESULT = "! " : RECORD.ID:'-':" Unable to open the folder ":APPLI
                        PROCESS.RESULT<-1> = MESSAGE.RESULT
                        RESULT.ERRORS<-1> = MESSAGE.RESULT
                        NBR.ERREUR = NBR.ERREUR + 1
                        CONTINUE
*AF                            END
                    END
                CASE OTHERWISE
                    F.APPLI = ''
                    FN.APPLI = 'F.':APPLI
                    CALL OPF(FN.APPLI : FM : "NO.FATAL.ERROR", F.APPLI)
                    IF ETEXT THEN
*the folder .BP doesn't exist
                        NB.DOT = DCOUNT(APPLI,".")
*check if the last 2 characters are BP
                        W.LAST.2 = FIELDS(APPLI, "." ,NB.DOT)
                        IF W.LAST.2 EQ "BP" THEN
                            ETEXT.SAV = ETEXT ; ETEXT = ''
                            EXECUTE "CREATE-FILE DATA " : APPLI : " TYPE=UD" CAPTURING RIEN
                            EXECUTE "DELETE " : APPLI : " .jbase_header" CAPTURING RIEN
                            OPEN APPLI TO F.APPLI THEN
                                CONTINUE
                            END
                            ETEXT = ETEXT.SAV
                        END
                        MESSAGE.RESULT = "! " : RECORD.ID:"- Unable to open the table ":APPLI
                        PROCESS.RESULT<-1> = MESSAGE.RESULT
                        RESULT.ERRORS<-1> = MESSAGE.RESULT
                        NBR.ERREUR = NBR.ERREUR + 1
                        CONTINUE
                    END
            END CASE

            READ R.APPLI FROM F.UNIX.FILENAME, ID.DL.DIR THEN
                BEGIN CASE
                    CASE APPLI = 'FILE.CONTROL'
                        R.APPLI<EB.FILE.RECORD.STATUS> = ""
                        R.APPLI<EB.FILE.INPUTTER> = TNO:"_":OPERATOR
                        R.APPLI<EB.FILE.DATE.TIME> = DATE.HEURE.STATUS
                        R.APPLI<EB.FILE.AUTHORISER> = TNO:"_":OPERATOR
                        R.APPLI<EB.FILE.CO.CODE> = ID.COMPANY
                        R.APPLI<EB.FILE.DEPT.CODE> = R.USER<EB.USE.DEPARTMENT.CODE>
                        WRITE R.APPLI TO F.APPLI, ID.APPLI ON ERROR
                            MESSAGE.RESULT = "! " : RECORD.ID:'-':" Unable to write the record ":ID.APPLI:' in ':APPLI
                            PROCESS.RESULT<-1> = MESSAGE.RESULT
                            RESULT.ERRORS<-1> = MESSAGE.RESULT
                            NBR.ERREUR = NBR.ERREUR + 1
                            CONTINUE
                        END
                        NEW.FILE = ''
                        NEW.FILE<1> = 'F.':ID.APPLI
                        NEW.FILE<2> = 'NO.FATAL.ERROR'
                        CALL OPF(NEW.FILE,F.NEW.FILE)
                        IF NOT(ETEXT) THEN    ;* TM_20100804 s
                            NB.SUFFIXE = DCOUNT(R.APPLI<EB.FILE.CONTROL.SUFFIXES>, VM)
                            FOR I.SUFFIXE = 1 TO NB.SUFFIXE UNTIL ETEXT
                                NEW.FILE = ''
                                NEW.FILE<1> = 'F.' : ID.APPLI : R.APPLI<EB.FILE.CONTROL.SUFFIXES, I.SUFFIXE>
                                NEW.FILE<2> = 'NO.FATAL.ERROR'
                                CALL OPF (NEW.FILE, F.NEW.FILE)
                            NEXT I.SUFFIXE
                        END         ;* TM_20100804 e
                        IF ETEXT THEN
                            ERROR.MESSAGE = ''
                            ETEXT = ''
                            FILE.TO.CREATE = ID.APPLI
                            CALL EBS.CREATE.FILE(FILE.TO.CREATE,'',ERROR.MESSAGE)
                            IF ERROR.MESSAGE THEN
                                MESSAGE.RESULT = "! " : RECORD.ID:'-':' Unable to create the table ':ID.APPLI
                                PROCESS.RESULT<-1> = MESSAGE.RESULT
                                RESULT.ERRORS<-1> = MESSAGE.RESULT
                                NBR.ERREUR = NBR.ERREUR + 1
                            END ELSE
                                PROCESS.RESULT<-1> = RECORD.ID:'-':' Table ':ID.APPLI:' created'
                            END
                        END
                    CASE APPLI[2] = 'BP' AND ID.APPLI[1, 9] = "I_REMOVE_"   ;* TM_20100422 s
* Suppression d'objets
                        CALL T24.W.PACK.MAN.REMOVE (OFSS.ID, R.APPLI, ENS.MSG)
                        IF ENS.MSG = "" THEN
                            PROCESS.RESULT<-1> = RECORD.ID:'-':' Objets de la liste supprimes'
                        END ELSE
                            MESSAGE.RESULT = "! " : RECORD.ID:'-':' Error during the deleting of objets'
                            PROCESS.RESULT<-1> = MESSAGE.RESULT : FM : ENS.MSG
                            RESULT.ERRORS<-1> = MESSAGE.RESULT : FM : ENS.MSG
                            NBR.ERREUR = NBR.ERREUR + 1
                        END         ;* TM_20100422 e
                    CASE FILETYPE = 'UD'
* Source BASIC ou script
                        WRITE R.APPLI TO F.APPLI, ID.APPLI ON ERROR
                            MESSAGE.RESULT = "! " : RECORD.ID:'-':" Unable to write ":ID.APPLI:' in ':APPLI
                            PROCESS.RESULT<-1> = MESSAGE.RESULT
                            RESULT.ERRORS<-1> = MESSAGE.RESULT
                            NBR.ERREUR = NBR.ERREUR + 1
                            CONTINUE
                        END
                        IF APPLI[2] = "BP" AND ID.APPLI[1, 2] # 'I_' AND ID.APPLI[1, 2] # '$' THEN        ;* SL_140818
* Source a compiler
                            REP.BASIC = APPLI
                            ID.BASIC = ID.APPLI
                            GOSUB T24.F.COMPILE
                        END
                    CASE OTHERWISE
                        CALL F.READ (FN.PGM.FILE, APPLI, R.PGM.FILE, F.PGM.FILE, ERR.MSG)       ;* TM_20100401
                        IF R.PGM.FILE<EB.PGM.TYPE> = "D" THEN     ;* TM_20100401
                            COMPILED.OR.NOT = 1         ;* TM_20100401
                        END ELSE    ;* TM_20100401
                            PRG.INFO = ''
                            APPLI.COMP = APPLI
*AF                                COMPILED.OR.NOT = CALLC JBASESubroutineExist (APPLI.COMP, PRG.INFO)
                            COMPILED.OR.NOT = "YES"
                        END         ;* TM_20100401
                        IF COMPILED.OR.NOT AND APPLI = "VERSION" THEN
                            PRG.INFO = ''
                            APPLI.COMP = ID.APPLI[",", 1, 1]
                            CALL F.READ (FN.PGM.FILE, APPLI.COMP, R.PGM.FILE, F.PGM.FILE, ERR.MSG)        ;* TM_20100401
                            IF R.PGM.FILE<EB.PGM.TYPE> = "D" THEN ;* TM_20100401
                                COMPILED.OR.NOT = 1     ;* TM_20100401
*AF                                END ELSE          ;* TM_20100401
*AF                                    COMPILED.OR.NOT = CALLC JBASESubroutineExist (APPLI.COMP, PRG.INFO)

                            END     ;* TM_20100401
                        END
                        IF COMPILED.OR.NOT THEN
                            BEGIN CASE
                                CASE APPLI = "STANDARD.SELECTION"
* Applique uniquement les modification sur les champs USR
                                    R.APPLI.NEW = R.APPLI
                                    CALL F.READ (FN.APPLI, ID.APPLI, R.APPLI, F.APPLI, ERR.SS)
                                    IF ERR.SS # "" THEN
                                        R.APPLI = ""
                                    END
                                    R.APPLI<SSL.RECORD.STATUS> = "IHLD"
* Conserve uniquement les LOCAL.REF
                                    FOR I.FLD = DCOUNT(R.APPLI<SSL.USR.FIELD.NAME>, VM) TO 1 STEP -1          ;* TM_20120913
                                        IF NOT(R.APPLI<SSL.USR.FIELD.NO, I.FLD> MATCH '"LOCAL.REF<1,"1N0N">"' : VM : '"LOCAL.REF<1," 1N0N">"') THEN
                                            FOR I.SS = SSL.USR.FIELD.NAME TO SSL.USR.REL.FILE
                                                DEL R.APPLI<I.SS, I.FLD>
                                            NEXT I.SS
                                        END
                                    NEXT I.FLD
* Recupere les nouveaux champs autres que les LOCAL.REF
                                    I.CRT = DCOUNT(R.APPLI<SSL.USR.FIELD.NAME>, VM)       ;* TM_20120913
                                    NB.FLD = DCOUNT(R.APPLI.NEW<SSL.USR.FIELD.NAME>, VM)  ;* TM_20120913
                                    FOR I.FLD = 1 TO NB.FLD
                                        IF NOT(R.APPLI.NEW<SSL.USR.FIELD.NO, I.FLD> MATCH '"LOCAL.REF<1,"1N0N">"' : VM : '"LOCAL.REF<1," 1N0N">"') THEN
                                            I.CRT = I.CRT + 1
                                            FOR I.SS = SSL.USR.FIELD.NAME TO SSL.USR.REL.FILE
                                                R.APPLI<I.SS, I.CRT> = R.APPLI.NEW<I.SS, I.FLD>
                                            NEXT I.SS
                                        END
                                    NEXT I.FLD
                                CASE APPLI = "BATCH"
* Le calendrier n'est pas le meme sur les 2 environnements
                                    R.APPLI<BAT.LAST.RUN.DATE> = ""
                                    R.APPLI<BAT.NEXT.RUN.DATE> = ""
                                CASE APPLI = "EB.PHANTOM"
                                    R.APPLI<TD.STATUS> = ""
                                CASE APPLI = "LOCAL.TABLE" ; * TM_141027 s
                                    IF R.APPLI<EB.LTA.APPLICATION.VET> THEN
                                        CALL F.READ (FN.APPLI, ID.APPLI, R.APPLI.OLD, F.APPLI, ERR.LT)
                                        IF ERR.LT THEN
                                            R.APPLI<EB.LTA.MAXIMUM.CHAR> = ""
                                        END
                                    END ; * TM_141027 e
                                CASE APPLI = "TSA.SERVICE"
                                    IF R.APPLI<TS.TSM.SERVICE.CONTROL> # "AUTO" THEN
                                        R.APPLI<TS.TSM.SERVICE.CONTROL> = "STOP"
                                    END
                            END CASE
                            F.APPLI$NAU = ''
                            FN.APPLI$NAU = 'F.':APPLI:'$NAU' : FM : 'NO.FATAL.ERROR'
                            CALL OPF(FN.APPLI$NAU,F.APPLI$NAU)
                            IF ETEXT THEN
* Si $NAU n'existe pas, enregistrement en OFS
                                PRES.NAU = 0
                                R.DYN.MESSAGE = R.APPLI
                                CALL F.READ (FN.APPLI, ID.APPLI, R.OLD.DYN.MESSAGE, F.APPLI, ERR.READ)
                                IF ERR.READ # "" THEN
                                    R.OLD.DYN.MESSAGE = ""
                                END
                                ADDNL.INFO<2, 4> = ID.APPLI
                                ADDNL.INFO<2, 5> = ""
                                PROCESS.NULL = 1
                                GOSUB INIT.DYN.TO.OFS
                                GOSUB PROCESS.DYN.TO.OFS
                            END ELSE
                                PRES.NAU = 1
                                WRITE R.APPLI TO F.APPLI$NAU, ID.APPLI ON ERROR
                                    MESSAGE.RESULT = "! " : RECORD.ID:'-':" Unable to write the record ":R.APPLI:' in ':F.APPLI$NAU
                                    PROCESS.RESULT<-1> = MESSAGE.RESULT
                                    RESULT.ERRORS<-1> = MESSAGE.RESULT
                                    NBR.ERREUR = NBR.ERREUR + 1
                                    CONTINUE
                                END
                                OFS.MESSAGE = APPLI : ',/I/PROCESS/1/0,,'
                                IF ID.APPLI MATCH '1A' THEN
                                    OFS.MESSAGE := "."
                                END
                                OFS.MESSAGE := CONVERT(",/", "?^", ID.APPLI)
                                GOSUB TRANS.ENDSTART    ;* TM_20100806
                            END
                            CALL OFS.GLOBUS.MANAGER(OFSS.ID,OFS.MESSAGE)
                            BEGIN CASE
                                CASE OFS.MESSAGE['/', 3 + COUNT(ID.APPLI, "/"), 1] = -1 AND NOT(INDEX(OFS.MESSAGE,'LIVE RECORD NOT CHANGED',1)) AND NOT(INDEX(OFS.MESSAGE,'NOT AUTH. RECORD NOT CHANGED',1)) 
                                    LOCATE APPLI IN LIST.APPLI.INTERNAL.DEPENDENCE<1> SETTING POS.APPLI THEN  ;* TM_140110 s
                                        LOCATE ID.APPLI IN LIST.ID.INTERNAL.DEPENDENCE<POS.APPLI, 1> SETTING POS.ID.APPLI ELSE
                                            INS ID.APPLI BEFORE LIST.ID.INTERNAL.DEPENDENCE<POS.APPLI, POS.ID.APPLI>
                                        END       ;* TM_140110 e
                                        PROCESS.RESULT<-1> = RECORD.ID:'- ':ID.APPLI:' in ':APPLI : " placed in the queue"
                                    END ELSE
                                        MESSAGE.RESULT = "! " : RECORD.ID:'-':' Erreur OFS ':OFS.MESSAGE:' pour  ':ID.APPLI:' dans ':APPLI
                                        PROCESS.RESULT<-1> = MESSAGE.RESULT
                                        RESULT.ERRORS<-1> = MESSAGE.RESULT
                                        NBR.ERREUR = NBR.ERREUR + 1
                                    END
                                    
                                CASE OFS.MESSAGE['/', 3 + COUNT(ID.APPLI, "/"), 1] = -1
* LIVE RECORD NOT CHANGED
                                    GOSUB MAJ.LISTE.TAB.LR
                                    PROCESS.RESULT<-1> = RECORD.ID:'-':' Avertissement OFS ':OFS.MESSAGE:' pour ':ID.APPLI:' dans ':APPLI
                                    IF PRES.NAU THEN
                                        DELETE F.APPLI$NAU,ID.APPLI
                                    END
                                CASE OFS.MESSAGE['/', 3, 1] = 1 AND NOT(INDEX(OFS.MESSAGE, ",AUTHORISER:", 1))
                                    MESSAGE.RESULT = "! " : RECORD.ID:'-':' Erreur non reportee dans le rapport OFS mais il manque AUTHORISER (':OFS.MESSAGE:') pour  ':ID.APPLI:' dans ':APPLI
                                    PROCESS.RESULT<-1> = MESSAGE.RESULT
                                    RESULT.ERRORS<-1> = MESSAGE.RESULT
                                    NBR.ERREUR = NBR.ERREUR + 1
                                CASE OTHERWISE
                                    MAJ.OK = 1
                                    IF PRES.NAU THEN
                                        READ RECORD.STAT FROM F.APPLI$NAU, ID.APPLI THEN
                                            MAJ.OK = 0
                                        END
                                    END
                                    IF MAJ.OK THEN
                                        MESSAGE.RESULT = RECORD.ID:'-':' Successful update for ':ID.APPLI:' in ':APPLI      ;* TM_20100331
                                        GOSUB MAJ.LISTE.TAB.LR
                                    END ELSE
                                        MESSAGE.RESULT = "! " : RECORD.ID:'-':' Application ':ID.APPLI:' unauthorized'
                                        RESULT.ERRORS<-1> = MESSAGE.RESULT
                                        NBR.ERREUR = NBR.ERREUR + 1
                                    END
                                    PROCESS.RESULT<-1> = MESSAGE.RESULT
                            END CASE
                        END ELSE
                            MESSAGE.RESULT = "! " : RECORD.ID:'-':' Application ' : APPLI.COMP : " n'est pas un programme catalogue"
                            PROCESS.RESULT<-1> = MESSAGE.RESULT
                            RESULT.ERRORS<-1> = MESSAGE.RESULT
                            NBR.ERREUR = NBR.ERREUR + 1
                        END
                END CASE
            END ELSE
                MESSAGE.RESULT = "! " : RECORD.ID:'-':" The Unix file " : ID.DL.DIR : " is missing"
                PROCESS.RESULT<-1> = MESSAGE.RESULT
                RESULT.ERRORS<-1> = MESSAGE.RESULT
                NBR.ERREUR = NBR.ERREUR + 1
            END
        END
        PROCESS.RESULT<-1> = RECORD.ID:'-':' End installation'
        GOSUB TRANS.ENDSTART    ;* TM_20100806
    NEXT I
    NB.APPLI.DEPINT = DCOUNT(LIST.APPLI.INTERNAL.DEPENDENCE, FM)        ;* TM_140110 s
    FOR I.APPLI.DEPINT = 1 TO NB.APPLI.DEPINT
        LIST.ID.PROCESS = LIST.ID.INTERNAL.DEPENDENCE<I.APPLI.DEPINT>
        IF LIST.ID.PROCESS # "" THEN
            APPLI = LIST.APPLI.INTERNAL.DEPENDENCE<I.APPLI.DEPINT>
            PROCESS.RESULT<-1> = '--------------------------------------------------------'
            PROCESS.RESULT<-1> = APPLI:' Start installation'
            NBOLD.REC.DEPINT = 0
            LOOP
                NB.REC.DEPINT = DCOUNT(LIST.ID.PROCESS, VM)
                FOR I.REC.DEPINT = NB.REC.DEPINT TO 1 STEP -1
                    GOSUB CLEAR.STATIC.CACHE        ;* TM_20100809
                    ID.APPLI = LIST.ID.PROCESS<1, I.REC.DEPINT>
                    OFS.MESSAGE = APPLI : ',/I/PROCESS/1/0,,' : CONVERT(",/", "?^", ID.APPLI)         ;* TM_140210
                    CALL OFS.GLOBUS.MANAGER(OFSS.ID,OFS.MESSAGE)
                    BEGIN CASE
                        CASE OFS.MESSAGE['/', 3 + COUNT(ID.APPLI, "/"), 1] # -1
                            DEL LIST.ID.PROCESS<1, I.REC.DEPINT>
                            PROCESS.RESULT<-1> = ID.APPLI : ' Update OK'   ;* TM_20100331
                        CASE NB.REC.DEPINT = NBOLD.REC.DEPINT
                            MESSAGE.RESULT = "! " : APPLI : "-" : ID.APPLI : ' error OFS ' : OFS.MESSAGE
                            PROCESS.RESULT<-1> = MESSAGE.RESULT
                            RESULT.ERRORS<-1> = MESSAGE.RESULT
                            NBR.ERREUR = NBR.ERREUR + 1
                    END CASE
                    GOSUB TRANS.ENDSTART  ;* TM_20100806
                NEXT I.REC.DEPINT
            UNTIL NB.REC.DEPINT = NBOLD.REC.DEPINT DO
                NBOLD.REC.DEPINT = NB.REC.DEPINT
            REPEAT
            PROCESS.RESULT<-1> = APPLI:' End installation'
        END ;* IF LIST.ID.INTERNAL.DEPENDENCE
    NEXT I.APPLI.DEPINT         ;* TM_140110 e

    IF R.STD.SEL.LR.ID # "" THEN
* Classe les I desc USR LOCAL.REF et supprime les anciennes LOCAL.REF
        APPLI = "STANDARD.SELECTION"
        PROCESS.RESULT<-1> = '--------------------------------------------------------'
        PROCESS.RESULT<-1> = APPLI:' Start installation'

        FN.STANDARD.SELECTION = 'F.STANDARD.SELECTION'
        F.STANDARD.SELECTION = ''
        CALL OPF(FN.STANDARD.SELECTION, F.STANDARD.SELECTION)

        FN.STANDARD.SELECTION$NAU = 'F.STANDARD.SELECTION$NAU'
        F.STANDARD.SELECTION$NAU = ''
        CALL OPF(FN.STANDARD.SELECTION$NAU, F.STANDARD.SELECTION$NAU)

        FN.LOCAL.REF.TABLE = 'F.LOCAL.REF.TABLE'
        F.LOCAL.REF.TABLE = ""
        CALL OPF (FN.LOCAL.REF.TABLE, F.LOCAL.REF.TABLE)

        FN.LOCAL.TABLE = 'F.LOCAL.TABLE'
        F.LOCAL.TABLE = ""
        CALL OPF (FN.LOCAL.TABLE, F.LOCAL.TABLE)

        LOOP
            REMOVE ID.SS FROM R.STD.SEL.LR.ID SETTING POS.SS
        WHILE ID.SS # "" OR POS.SS DO
            READ R.SS.LIVE FROM F.STANDARD.SELECTION, ID.SS ELSE
                R.SS.LIVE = ""
            END
            READ R.SS$NAU FROM F.STANDARD.SELECTION$NAU, ID.SS ELSE
                R.SS$NAU = R.SS.LIVE
            END
            IF R.SS$NAU # "" THEN
                GOSUB CLEAR.STATIC.CACHE  ;* TM_20100809
                R.SS = R.SS$NAU
                N.RECUP.LR = 0
                N.RECUP.IDESC = 0
                N.SUPP = DCOUNT(R.SS<SSL.USR.FIELD.NAME>, @VM)
                ID.DOUBLON = ""
* Vide les champs USR
                FOR I.SS = SSL.USR.FIELD.NAME TO SSL.USR.REL.FILE
                    R.SS<I.SS> = ""
                NEXT I.SS
* Ajoute les LOCAL.REF
                I.USR = 0
                READ R.LRT FROM F.LOCAL.REF.TABLE, ID.SS THEN
                    NB.LRT = DCOUNT(R.LRT<EB.LRT.LOCAL.TABLE.NO>, VM)
                    FOR I.LRT = 1 TO NB.LRT
                        ID.LT = R.LRT<EB.LRT.LOCAL.TABLE.NO, I.LRT>
                        READ R.LT FROM F.LOCAL.TABLE, ID.LT THEN
                            ID.FLD = R.LT<EB.LTA.SHORT.NAME, 1>
                            CONVERT " " TO "." IN ID.FLD
                            LOCATE ID.FLD IN R.SS.LIVE<SSL.USR.FIELD.NAME, 1> SETTING POS.FLD THEN
                                LOCATE ID.FLD IN R.SS<SSL.USR.FIELD.NAME, 1> SETTING POS.CTRL THEN
                                    ID.DOUBLON = ID.FLD
                                    EXIT
                                END
                                LOCATE ID.FLD IN R.SS<SSL.SYS.FIELD.NAME, 1> SETTING POS.CTRL THEN
                                    ID.DOUBLON = ID.FLD
                                    EXIT
                                END
                                I.USR = I.USR + 1
                                FOR I.SS = SSL.USR.FIELD.NAME TO SSL.USR.REL.FILE
                                    R.SS<I.SS, I.USR> = R.SS.LIVE<I.SS, POS.FLD>
                                NEXT I.SS
                                N.RECUP.LR = N.RECUP.LR + 1
                            END ELSE
                                MESSAGE.RESULT = "! " : ID.FLD : " missing from STANDARD.SELECTION " : ID.SS
                                PROCESS.RESULT<-1> = MESSAGE.RESULT
                                RESULT.ERRORS<-1> = MESSAGE.RESULT
                                NBR.ERREUR = NBR.ERREUR + 1
                            END
                        END ELSE
                            MESSAGE.RESULT = "! " : ID.LT : " missing LOCAL.TABLE for STANDARD.SELECTION " : ID.SS
                            PROCESS.RESULT<-1> = MESSAGE.RESULT
                            RESULT.ERRORS<-1> = MESSAGE.RESULT
                            NBR.ERREUR = NBR.ERREUR + 1
                        END
                    NEXT I.LRT
                END
* Ajoute les autres champs
                NB.FLD = DCOUNT(R.SS$NAU<SSL.USR.FIELD.NAME>, VM)
                FOR I.FLD = 1 TO NB.FLD
                    IF NOT(R.SS$NAU<SSL.USR.FIELD.NO, I.FLD> MATCH '"LOCAL.REF<1,"1N0N">"' : VM : '"LOCAL.REF<1," 1N0N">"') THEN
                        ID.FLD = R.SS$NAU<SSL.USR.FIELD.NAME, I.FLD>
                        LOCATE ID.FLD IN R.SS<SSL.USR.FIELD.NAME, 1> SETTING POS.CTRL THEN
                            ID.DOUBLON = ID.FLD
                            EXIT
                        END
                        LOCATE ID.FLD IN R.SS<SSL.SYS.FIELD.NAME, 1> SETTING POS.CTRL THEN
                            ID.DOUBLON = ID.FLD
                            EXIT
                        END
                        I.USR = I.USR + 1
                        FOR I.SS = SSL.USR.FIELD.NAME TO SSL.USR.REL.FILE
                            R.SS<I.SS, I.USR> = R.SS$NAU<I.SS, I.FLD>
                        NEXT I.SS
                        N.RECUP.IDESC = N.RECUP.IDESC + 1
                    END
                NEXT I.FLD
                IF ID.DOUBLON = "" THEN
                    PROCESS.RESULT<-1> = "Update of " : ID.SS : ", deleting " : N.SUPP : ", creating LOCAL.REF " : N.RECUP.LR : " I-DESC " : N.RECUP.IDESC  ;* TM_20100331
                    R.SS<SSL.RECORD.STATUS> = "IHLD"
                    OFS.MESSAGE = APPLI : ',/I/PROCESS/1/0,,' : CONVERT(",/", "?^", ID.SS)  ;* TM_140210
                    WRITE R.SS TO F.STANDARD.SELECTION$NAU, ID.SS ON ERROR
                        MESSAGE.RESULT = "! Unable to write the record ":ID.SS:' in ':FN.STANDARD.SELECTION$NAU
                        PROCESS.RESULT<-1> = MESSAGE.RESULT
                        RESULT.ERRORS<-1> = MESSAGE.RESULT
                        NBR.ERREUR = NBR.ERREUR + 1
                        OFS.MESSAGE = ""
                    END
                    GOSUB TRANS.ENDSTART  ;* TM_20100806
                    IF OFS.MESSAGE # "" THEN
                        CALL @NOM.SUBR.TRANS ("END", MSG.TRANS)
                        CALL @NOM.SUBR.TRANS ("START", MSG.TRANS)
                        CALL OFS.GLOBUS.MANAGER(OFSS.ID,OFS.MESSAGE)
                        BEGIN CASE
                            CASE OFS.MESSAGE['/', 3 + COUNT(ID.SS, "/"), 1] = -1 AND NOT(INDEX(OFS.MESSAGE,'LIVE RECORD NOT CHANGED',1))
                                MESSAGE.RESULT = '! Error OFS ':OFS.MESSAGE:' for  ':ID.SS
                                PROCESS.RESULT<-1> = MESSAGE.RESULT
                                RESULT.ERRORS<-1> = MESSAGE.RESULT
                                NBR.ERREUR = NBR.ERREUR + 1
                            CASE OFS.MESSAGE['/', 3, 1] = -1
                                PROCESS.RESULT<-1> = ID.SS : ' No modification'
                                DELETE F.STANDARD.SELECTION$NAU, ID.SS
                            CASE OTHERWISE
                                PROCESS.RESULT<-1> = ID.SS : ' Update done'  ;* TM_20100331
                        END CASE
                        GOSUB TRANS.ENDSTART        ;* TM_20100806
                    END
                END ELSE
                    MESSAGE.RESULT = "! Field " : ID.DOUBLON : " duplicate in STANDARD.SELECTION " : ID.SS : ", le STANDARD.SELECTION n'a pas ete trie"
                    PROCESS.RESULT<-1> = MESSAGE.RESULT
                    RESULT.ERRORS<-1> = MESSAGE.RESULT
                    NBR.ERREUR = NBR.ERREUR + 1
                END
            END ELSE
                MESSAGE.RESULT = "! " : ID.SS : ' missing from STANDARD.SELECTION'
                PROCESS.RESULT<-1> = MESSAGE.RESULT
                RESULT.ERRORS<-1> = MESSAGE.RESULT
                NBR.ERREUR = NBR.ERREUR + 1
            END
        REPEAT
        PROCESS.RESULT<-1> = APPLI:' End of installation'
    END

    IF NBR.ERREUR THEN
        INS NBR.ERREUR : " error(s) during installation" BEFORE PROCESS.RESULT<1>
        INS RESULT.ERRORS BEFORE PROCESS.RESULT<2>
    END ELSE
        INS "No error during installation" BEFORE PROCESS.RESULT<1>
    END

    F.LISTS = ''
    TEXT = ''
    BASE.ID = ID.NEW  ;* TM_20100503 s
    PHASE = OCONV(R.NEW(T24.PM.DEF.ACTION), "MCN")
    IF PHASE # "" THEN
        BASE.ID := ".PHASE" : PHASE
    END
    CHR.HLD = 0
    LOOP
        HLD.ID = BASE.ID
        IF CHR.HLD THEN
            HLD.ID := "." : CHR.HLD
        END
        READU RIEN FROM SAVEDLISTS, HLD.ID LOCKED
        END THEN
;*  RELEASE SAVEDLISTS, HLD.ID
            CALL F.RELEASE (SAVEDLISTS,HLD.ID,SAVEDLISTS)
        END ELSE
            EXIT
        END
        CHR.HLD += 1
    REPEAT  ;* TM_20100503 e
    WRITE PROCESS.RESULT TO SAVEDLISTS, HLD.ID ON ERROR
        E = 'UNABLE TO WRITE LOG FILE'
        RETURN
    END

    IF NOT(GTSACTIVE) THEN
        CALL REPORT.VIEW(W.SAVEDLISTS,HLD.ID)
    END
*
RETURN
*===================================================================================
*
REMOVE.R.RECORD.ID: * TM_20120125 s

    LIG.REMOVE = TRIM(R.LIST.REMOVE<I.LIG>)
    NBR.ESP = DCOUNT(LIG.REMOVE, " ")
    SUPP.HIS = 0
    IF LIG.REMOVE[" ", NBR.ESP, 1] = "$HIS" THEN
        SUPP.HIS = 1
        NBR.ESP = NBR.ESP - 1
    END
    IF NBR.ESP > 1 THEN
        NOM.TABLE = LIG.REMOVE[" ", 1, 1]
        FOR I.REC = 2 TO NBR.ESP
            ID.REC.REMOVE = NOM.TABLE : "-" : LIG.REMOVE[" ", I.REC, 1]
            LOCATE ID.REC.REMOVE IN R.RECORD.ID<1> SETTING POS.REC.REMOVE THEN
                DEL R.RECORD.ID<POS.REC.REMOVE>
            END
        NEXT I.REC
    END

RETURN  ;* TM_20120125 e

*
T24.F.COMPILE:

    OPEN REP.BASIC TO F.BASIC THEN
        READ R.BASIC FROM F.BASIC, ID.BASIC THEN
            GOSUB TRANS.ENDSTART ; * TM_20100806
            W.EXEC.CMD.1 = "T24.T.COMPILE ":REP.BASIC: : SEP.DIR : ID.BASIC
*            IF RETURN.OS = 'NT' THEN
*                W.EXEC.CMD = "DOS /c tRun " : W.EXEC.CMD.1
*            END ELSE
*                W.EXEC.CMD = "SH -c tRun " : W.EXEC.CMD.1
*            END
            IF RUNNING.UNDER.BATCH THEN
                CALL !HUSHIT(0)
                EXECUTE W.EXEC.CMD.1 SETTING RETURN.STATUS CAPTURING CAPTURE.MSG
                CALL !HUSHIT(1)
            END ELSE
                EXECUTE W.EXEC.CMD.1 SETTING RETURN.STATUS CAPTURING CAPTURE.MSG
            END
*
            GOSUB TRANS.ENDSTART ; * TM_20100806
            OK.OUTPUT = DCOUNT(CAPTURE.MSG,'COMPILE:OK')
            IF OK.OUTPUT GT 1 THEN
                PROCESS.RESULT<-1> = RECORD.ID:'-':' ':ID.BASIC:" compiled in ":REP.BASIC
            END ELSE
                MESSAGE.RESULT = "! " : RECORD.ID:'-':' ':ID.BASIC:" compiled in ":REP.BASIC:' with error(s) or warnings(s) :' : FM : CAPTURE.MSG
                PROCESS.RESULT<-1> = MESSAGE.RESULT
                RESULT.ERRORS<-1> = MESSAGE.RESULT
                NBR.ERREUR = NBR.ERREUR + 1
            END
        END ELSE
            MESSAGE.RESULT = "! " : RECORD.ID:'-':' Rtn/program ':ID.BASIC:' missing from ':REP.BASIC
            PROCESS.RESULT<-1> = MESSAGE.RESULT
            RESULT.ERRORS<-1> = MESSAGE.RESULT
            NBR.ERREUR = NBR.ERREUR + 1
        END
    END ELSE
        MESSAGE.RESULT = "! " : RECORD.ID:'-':' The folder ' : REP.BASIC : ' absent for the program ':ID.BASIC
        PROCESS.RESULT<-1> = MESSAGE.RESULT
        RESULT.ERRORS<-1> = MESSAGE.RESULT
        NBR.ERREUR = NBR.ERREUR + 1
    END

RETURN
*
*===================================================================================
*
MAJ.LISTE.TAB.LR:
*
    BEGIN CASE
        CASE APPLI = "LOCAL.REF.TABLE"
            LOCATE ID.APPLI IN R.STD.SEL.LR.ID<1> BY "AL" SETTING POS.APPLI ELSE
                INS ID.APPLI BEFORE R.STD.SEL.LR.ID<POS.APPLI>
            END
        CASE APPLI = "LOCAL.TABLE"
            CMD.SEL = 'SELECT F.LOCAL.REF.TABLE WITH LOCAL.TABLE.NO = "' : ID.APPLI : '"'
            CALL EB.READLIST (CMD.SEL, LISTE.LRT, NOM.LISTE, N.LRT, LIST.ERR)
            IF N.LRT THEN
                LOOP
                    REMOVE ID.LRT FROM LISTE.LRT SETTING POS.LIST
                WHILE ID.LRT # "" OR POS.LIST DO
                    LOCATE ID.LRT IN R.STD.SEL.LR.ID<1> BY "AL" SETTING POS.APPLI ELSE
                        INS ID.LRT BEFORE R.STD.SEL.LR.ID<POS.APPLI>
                    END
                REPEAT
            END
    END CASE

RETURN
*

*===================================================================================
*
GET.MENU.ITEM:
*
    F.HELPTEXT.MAINMENU = ''
    FN.HELPTEXT.MAINMENU = 'F.HELPTEXT.MAINMENU'
    CALL OPF(FN.HELPTEXT.MAINMENU, F.HELPTEXT.MAINMENU)
*
    F.HELPTEXT.MENU = ''
    FN.HELPTEXT.MENU = 'F.HELPTEXT.MENU'
    CALL OPF(FN.HELPTEXT.MENU, F.HELPTEXT.MENU)
*
    M.TEXT = ''
    DL.DEFINE = ''
    M.MENU.ID = COMI

    M.HELPTEXT.MAINMENU.ID = M.MENU.ID
    CALL F.READ(FN.HELPTEXT.MAINMENU, M.HELPTEXT.MAINMENU.ID, R.HELPTEXT.MAINMENU, F.HELPTEXT.MAINMENU, ETEXT)
    IF NOT(ETEXT) THEN
        PA.CNT= DCOUNT(R.HELPTEXT.MAINMENU<EB.MME.ID.OF.HELP.MENU>, VM)
        M.TEXT := R.HELPTEXT.MAINMENU<EB.MME.TITLE>:FM:FM
        DL.DEFINE := 'HELPTEXT.MAINMENU>':M.HELPTEXT.MAINMENU.ID:FM
        FOR PA.I = 1 TO PA.CNT
            CALL T24.S.PM.MENU.STRUCT.WRITE(R.HELPTEXT.MAINMENU<EB.MME.ID.OF.HELP.MENU, PA.I>, R.HELPTEXT.MAINMENU<EB.MME.DESCRIPT, PA.I>, 1, M.TEXT,DL.DEFINE)
            M.TEXT := FM
        NEXT PA.I
    END
*
    IF NOT(M.TEXT) THEN
        M.HELPTEXT.MENU.ID = M.MENU.ID
        CALL F.READ(FN.HELPTEXT.MENU, M.HELPTEXT.MENU.ID, R.HELPTEXT.MENU, F.HELPTEXT.MENU, ETEXT)
        IF NOT(ETEXT) THEN
            PA.CNT= 1
            M.TEXT := '':FM:FM
            CALL T24.S.PM.MENU.STRUCT.WRITE(M.HELPTEXT.MENU.ID, '', 1, M.TEXT,DL.DEFINE)
            M.TEXT := FM
        END
    END
*
    NBR.MENU.ITEM = DCOUNT(DL.DEFINE,FM)
    NEW.MENU.ITEM.LIST = ''
    FOR COUNT.MENU.ITEM = 1 TO NBR.MENU.ITEM
        IF DL.DEFINE<COUNT.MENU.ITEM> THEN
            NEW.MENU.ITEM.LIST<-1> = DL.DEFINE<COUNT.MENU.ITEM>
        END
    NEXT COUNT.MENU.ITEM
*
RETURN
*
*===================================================================================
*
INIT.CAR.SPE.ID.DL.DIR: ; * TM_140120 s

    ID.DL.CAR.SPE.ORIG = "*|<>?@ &();#/'" : '"' : "`$%" : "=^"        ;* Laisser =^ et 98 toujours la fin
    ID.DL.CAR.SPE.UNIX = "ABCDEFGHIJKLMN" : 'O' : "PQR" : "98"

    NB.ID.DL.CAR.SPE = LEN(ID.DL.CAR.SPE.ORIG)

RETURN
*
*===================================================================================
*
REVERSE.CAR.SPE.ID.DL.DIR:

    CHANGE "7^7" TO "" IN ID.DL.DIR
    FOR I.CAR = 1 TO NB.ID.DL.CAR.SPE
        CHANGE "^" : ID.DL.CAR.SPE.UNIX[I.CAR, 1] TO ID.DL.CAR.SPE.ORIG[I.CAR, 1] IN ID.DL.DIR
    NEXT I.CAR

RETURN ; * TM_140120 e
*
*===================================================================================
*
CAR.SPE.ID.DL.DIR:
* Remplace les caracteres speciaux dans la variable ID.DL.DIR

    FOR I.CAR = NB.ID.DL.CAR.SPE TO 1 STEP -1
        CHANGE ID.DL.CAR.SPE.ORIG[I.CAR, 1] TO "^" : ID.DL.CAR.SPE.UNIX[I.CAR, 1] IN ID.DL.DIR
    NEXT I.CAR

* NB.CAR = LEN(ID.DL.DIR) ; * TM_140120
    CAR.PREC = OCONV(ID.DL.DIR[1], "MC/A" : VM : "MC/N")
    FOR I.CAR = LEN(ID.DL.DIR) - 1 TO 1 STEP -1
        CAR.CRT = OCONV(ID.DL.DIR[I.CAR, 1], "MC/A" : VM : "MC/N")
        IF CAR.PREC # "" AND CAR.CRT # "" THEN
            ID.DL.DIR = ID.DL.DIR[1, I.CAR] : "7^7" : ID.DL.DIR[I.CAR + 1, LEN(ID.DL.DIR)] ; * TM_140120
        END
        CAR.PREC = CAR.CRT
    NEXT I.CAR
    IF ID.DL.DIR[1, 1] = "." THEN ; * TM_140120 s
        ID.DL.DIR = "7^7" : ID.DL.DIR
    END ; * TM_140120 e

RETURN
*
*===================================================================================
* TM_20100806 s
SS.ICOMP:
* Apres la mise a jour du STANDARD.SELECTION en mode service il faut executer ICOMP pour tous les I-Desc

    IF RUNNING.UNDER.BATCH AND ID.APPLI[".", 1, 1] # "NOFILE" THEN
        GOSUB TRANS.END
        COMMAND = 'SELECT DICT F.' : ID.APPLI : ' WITH F1 = "I"'
        EXECUTE COMMAND CAPTURING OUTPUT
        IF @SELECTED THEN
            COMMAND = 'ICOMP F.' : ID.APPLI
            EXECUTE COMMAND CAPTURING OUTPUT
        END
        GOSUB TRANS.START
    END ; * IF RUNNING.UNDER.BATCH

RETURN
*
*===================================================================================
* TM_20100806 e

*
*===================================================================================
*
*=============================================================================
* Modification History :
* dd/mm/yyy    - CD_REFERENCE - author
*              Description of modification.
*-----------------------------------------------------------------------------
*   Date            who                      Reference            Description
* 20/01/2014   Thierry MARTIN            TM_140120            Create a new insert for IO subroutine
*-----------------------------------------------------------------------------
*===================================================================================
* TM_20100806 s
TRANS.ENDSTART:

    GOSUB TRANS.END
    GOSUB TRANS.START

RETURN
*
*===================================================================================
*
TRANS.END:

    CALL JOURNAL.UPDATE ("") ;* TM_20100809 s
    MAT FWC = ""
    FWT = ""
    MAT FWF = "" ;* TM_20100809 s

    IF RUNNING.UNDER.BATCH THEN
        CALL @NOM.SUBR.TRANS ("END", MSG.TRANS)
    END

RETURN
*
*===================================================================================
*
TRANS.START:

    IF RUNNING.UNDER.BATCH THEN
        CALL @NOM.SUBR.TRANS ("START", MSG.TRANS)
    END

RETURN
* TM_20100806 e
*===================================================================================
* TM_20100809 s
* Vide le cache static (utilise par CACHE.READ)
CLEAR.STATIC.CACHE:

    STATIC.INDEX = 0

RETURN
*
*===================================================================================
* TM_20100809 e

