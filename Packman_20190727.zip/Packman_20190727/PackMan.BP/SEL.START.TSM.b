*-----------------------------------------------------------------------------
* <Rating>794</Rating>
*-----------------------------------------------------------------------------
    PROGRAM SEL.START.TSM
*===================================================================================
*
* Demarrage de TSM
*
* Author : B.H/MOE.SEL
* Version : 20090617
*===================================================================================

    $INSERT I_F.TSA.SERVICE
    $INSERT I_F.TSA.PARAMETER
    $INSERT I_F.TSA.STATUS

    GOSUB INITIALISE
    GOSUB OPEN.FILES
    GOSUB PROCESS

    RETURN

***********
INITIALISE:
***********
    FN.TSA.SERVICE = "F.TSA.SERVICE" ; F.TSA.SERVICE = ""
    FN.TSA.PARAMETER = "F.TSA.PARAMETER" ; F.TSA.PARAMETER = ""
    FN.TSA.STATUS = "F.TSA.STATUS" ; F.TSA.STATUS = ""

    ID.SERVICE = "TSM"
    ID.SYSTEM = "SYSTEM"
    STR.CODE = '0'
    ERR.MSG = ''

    CMD="whoami"
* CMD ="WHO"
    EXECUTE CMD RTNLIST LIST.WHO CAPTURING CAPT.WHO
* STR.CURRENT.ENV=FIELD(CAPT.WHO,' ',2)
    STR.CURRENT.ENV = TRIM(CAPT.WHO)


    RETURN

***********
OPEN.FILES:
***********
    OPEN FN.TSA.SERVICE TO F.TSA.SERVICE ELSE
        ERR.MSG = "Impossible d'ouvrir " : FN.TSA.SERVICE : "."
        GOTO FATAL.ERROR99
    END

    OPEN FN.TSA.PARAMETER TO F.TSA.PARAMETER ELSE
        ERR.MSG = "Impossible d'ouvrir " : FN.TSA.PARAMETER : "."
        GOTO FATAL.ERROR99
    END

    OPEN FN.TSA.STATUS TO F.TSA.STATUS ELSE
        ERR.MSG = "Impossible d'ouvrir " : FN.TSA.STATUS : "."
        GOTO FATAL.ERROR99
    END

    OPEN "&COMO&" TO F.COMO ELSE
        ERR.MSG = "Impossible d'ouvrir &COMO&"
        DISPLAY ERR.MSG
        STOP
    END

    RETURN

********
PROCESS:
********
    GOSUB ARRET.TSM

    RETURN

**********
ARRET.TSM:
***********

    GOSUB VERIFY.TSM

    IF SW.TSM.OK THEN
        PRINT OCONV(TIME(),"MTS"):"TSM Service Déjà demarré"
        GOTO FATAL.ERROR99
    END

*    PRINT OCONV(TIME(),"MTS"):" CLEAR TSA.STATUS ..."
*    CMD.CLEAR="CLEAR-FILE DATA F.TSA.STATUS"
*    EXECUTE CMD.CLEAR RTNLIST LIST.STATUS CAPTURING CAPT.STATUS

    CMD.SELECT = "SELECT F.TSA.STATUS WITH CURRENT.SERVICE # 'OLTP'"
    NUM.PROCESS = ""
    SLCT.NB = ""
    LIST.OF.ID = ""
    CALL EB.READLIST(CMD.SELECT,LIST.OF.ID,LST.NAME,NUM.PROCESS,SLCT.NB)
    IF LIST.OF.ID THEN
        LOOP
            REMOVE REC.ID FROM LIST.OF.ID SETTING RECDELIM
        WHILE REC.ID:RECDELIM
            READ R.REC FROM F.TSA.STATUS,REC.ID ELSE NULL
            IF R.REC THEN
                DELETE F.TSA.STATUS,REC.ID
                PRINT OCONV(TIME(),"MTS"):" Deleting TSA.STATUS ":REC.ID
            END
        REPEAT
    END
 
    READU R.SERVICE FROM F.TSA.SERVICE, ID.SERVICE ELSE
        ERR.MSG = "Le service " : ID.SERVICE : " n'existe pas dans " : FN.TSA.SERVICE : "."
        GOTO FATAL.ERROR99
    END

    R.SERVICE<TS.TSM.SERVICE.CONTROL> = "START"
    WRITE R.SERVICE ON F.TSA.SERVICE, ID.SERVICE

    GOSUB RUN.TSM

    RETURN

***********
VERIFY.TSM:
***********
    SW.TSM.OK=0
    NB.TST.TSM=0
    KEY.TSM = 1
    NB.TSM = 0
    NB.SELECTED = 0

    CMD.TSM= "SELECT F.TSA.STATUS WITH CURRENT.SERVICE EQ 'TSM' AND AGENT.STATUS = 'RUNNING' "
    EXECUTE CMD.TSM RTNLIST LIST.TSM CAPTURING CAPT.TSM
    NB.SELECTED = @SELECTED
    LOOP
    WHILE KEY.TSM
        REMOVE KEY.TSM FROM LIST.TSM SETTING KEY.TSM.MORE
        IF KEY.TSM THEN
            READ REC.TSA.STATUS FROM F.TSA.STATUS,KEY.TSM  ELSE NULL
            IF REC.TSA.STATUS THEN
                CMD="WHERE V( ":REC.TSA.STATUS<TS.TSS.PORT.ID>
                PORT.NO = REC.TSA.STATUS<TS.TSS.PORT.ID>
                EXECUTE CMD RTNLIST LIST.WHERE CAPTURING CAPT.WHERE
                CAPT.TSM = ''
                CAPT.TSM = 'tSA ':KEY.TSM

                IF INDEX (CAPT.WHERE, 'User not logged on', 1) THEN
                    PRINT OCONV(TIME(),"MTS"):" Info. - PORT TSA.STATUS TSM HORS SERVICE: ":PORT.NO
                END ELSE
                    IF INDEX (CAPT.WHERE,CAPT.TSM,1) THEN
                        PRINT OCONV(TIME(),"MTS"):" Info. - PORT TSA.STATUS TSM Running: ":PORT.NO
                        PRINT OCONV(TIME(),"MTS"):" Info. - RIEN A FAIRE "
                        SW.TSM.OK = 1
                    END
                END
            END
        END

    REPEAT

    RETURN

********
RUN.TSM:
********

    CMD.START.TSM="START.TSM"
    EXECUTE CMD.START.TSM RTNLIST LIST.START.TSM CAPTURING CAPT.START.TSM
    PRINT OCONV(TIME(),"MTS"):" TSM En cours de demarrage..."
    SW.TSM.OK=0
    NB.TST.TSM=0
    LOOP
    WHILE SW.TSM.OK=0
        CMD.TSM="SELECT F.TSA.STATUS WITH CURRENT.SERVICE EQ 'TSM'"
        EXECUTE CMD.TSM RTNLIST LIST.TSM CAPTURING CAPT.TSM
        KEY.TSM=''
        REMOVE KEY.TSM FROM LIST.TSM SETTING KEY.TSM.MORE
        IF KEY.TSM THEN
            READ REC.TSA.STATUS FROM F.TSA.STATUS,KEY.TSM  ELSE
                PRINT OCONV(TIME(),"MTS"):"TSM TSA.STATUS pas trouvé ... - TSM"
                GOSUB FATAL.ERROR99
            END
            CMD="WHERE V( ":REC.TSA.STATUS<TS.TSS.PORT.ID>
            EXECUTE CMD RTNLIST LIST.WHERE CAPTURING CAPT.WHERE
            FINDSTR 'tSM' IN CAPT.WHERE SETTING POS1.TSM THEN
                CONVERT CHAR(254) TO @FM IN CAPT.WHERE
                STR.STATUS.ENV=CAPT.WHERE<2>
                STR.STATUS.ENV=TRIM(STR.STATUS.ENV[20,10])
                IF STR.STATUS.ENV = STR.CURRENT.ENV THEN
                    SW.TSM.OK=1
                END
            END
        END
        NB.TST.TSM++
        IF NB.TST.TSM > 12 THEN
            PRINT OCONV(TIME(),"MTS"):"Error. TSM n'a pas demarré..."
            GOSUB FATAL.ERROR99
        END
        IF SW.TSM.OK=0 THEN SLEEP 5
    REPEAT
    PRINT OCONV(TIME(),"MTS"):" TSM est maintenant active"
    GOSUB WRITE.COMO
    RETURN


***********
WRITE.COMO:
***********

    WRITE STR.CODE TO F.COMO,'TSM' ON ERROR
        PRINT OCONV(TIME(),"MTS"):"  Error. Impossible de rederiger vers COMO."
        PRINT OCONV(TIME(),"MTS"):"99"
        STOP
    END

    CLOSE F.COMO

    EXIT(STR.CODE)

    STOP

**************
FATAL.ERROR99:
**************

    DISPLAY ERR.MSG
    STR.CODE = '99'
    GOSUB WRITE.COMO
    STOP
