* Version 1 13/04/00  GLOBUS Release No. 200508 30/06/05
*-----------------------------------------------------------------------------
* <Rating>0</Rating>
*-----------------------------------------------------------------------------
      SUBROUTINE TOOL.PERF.TEST.READ.SELECT
*-----------------------------------------------------------------------------
* Dror Traub 2017-01-13
*-----------------------------------------------------------------------------
$INSERT I_COMMON
$INSERT I_EQUATE
$INSERT I_BATCH.FILES
$INSERT I_TOOL.PERF.TEST.READ.COMMON
*-----------------------------------------------------------------------------

	Y.KEY.LIST = ""
    SELECTED = '' 
    Y.SEL.STMT = 'SELECT ':FN.TOOL.TEST.PERF.TABLE
    CALL EB.READLIST (Y.SEL.STMT, Y.KEY.LIST, LIST.NAME, SELECTED, SYSTEM.RETURN.CODE)
    
    CALL BATCH.BUILD.LIST('',Y.KEY.LIST)
    
	RETURN
	
   END
 
