*-----------------------------------------------------------------------------
* <Rating>-1</Rating>
*-----------------------------------------------------------------------------
*    $PACKAGE LB.PackManTool
    PROGRAM EXEC.COPY
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Modification History :
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE 
*-----------------------------------------------------------------------------

    IF SENTENCE(1) EQ '' OR SENTENCE(2) = '' OR SENTENCE(3) EQ '' THEN
        CRT "Param missing!"
        CRT "3 param mandatory: "
        CRT "           - the path and filename from where the record is copied"
        CRT "           - application(the path) where the record will be copied"
        CRT "           - ID(flat file name) "
        CRT "           - do write(Y) or COPY command(otherwise)?(not mandatory.Default: COPY)"
        RETURN
    END

    CALL T24.INITIALISE
    R.COMO := 'T24 initialised - ' : TIMEDATE() : FM : FM

    CALL S.INITIALISE.COMMON
    R.COMO := 'T24 Common Variables Initialised - ' : TIMEDATE() : FM : FM

    CALL LOAD.COMPANY ('IL0010001')
    R.COMO := 'Loaded T24 Company IL0010001 - ' : TIMEDATE() : FM : FM



    CALL COPY.FROM.FILE.TO.DB(SENTENCE(1),SENTENCE(2),SENTENCE(3),SENTENCE(4))

    END
