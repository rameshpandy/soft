*-----------------------------------------------------------------------------
* <Rating>268</Rating>
*-----------------------------------------------------------------------------
    PROGRAM SEL.START.SERVICE

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.SPF
    $INSERT I_F.JOB.TIMES
    $INSERT I_F.BATCH
    $INSERT I_F.TSA.SERVICE
    $INSERT I_F.TSA.STATUS
    $INSERT I_F.TSA.PARAMETER
    $INSERT I_F.COMPANY
    $INSERT I_F.EB.EOD.ERROR
    $INSERT I_F.BATCH
    $INSERT I_F.PGM.FILE
    $INSERT I_F.DATES
    $INSERT I_F.SEL.SCHEDULE


    GOSUB INITIALISE
    GOSUB PROCESS.START.TSA
    GOSUB WRITE.COMO

    RETURN

**********
INITIALISE:
**********

    F.TSA.SERVICE = ""
    OPEN "F.TSA.SERVICE" TO F.TSA.SERVICE ELSE
        PRINT "F.TSA.SERVICE : Not found ..."
        GOSUB FATAL.ERROR99
    END

    F.TSA.STATUS = ""
    OPEN "F.TSA.STATUS" TO F.TSA.STATUS ELSE
        PRINT "F.TSA.STATUS : Not found ..."
        GOSUB FATAL.ERROR99
    END

    F.TSA.PARAMETER = ''
    OPEN 'F.TSA.PARAMETER' TO F.TSA.PARAMETER ELSE
        PRINT 'F.TSA.PARAMETER : Not found ...'
        GOSUB FATAL.ERROR99
    END

    F.BATCH = ''
    OPEN 'F.BATCH' TO F.BATCH ELSE
        PRINT 'F.BATCH : Not found...'
    END

    F.PGM.FILE = ''
    OPEN 'F.PGM.FILE' TO F.PGM.FILE ELSE
        PRINT 'F.PGM.FILE : Not found...'
    END

    OPEN "&COMO&" TO F.COMO ELSE
        PRINT '&COMO& : Not found ...'
        GOSUB FATAL.ERROR99
    END

    F.SEL.SCHEDULE = ''
    OPEN "F.SEL.SCHEDULE" TO F.SEL.SCHEDULE ELSE
        PRINT 'F.SEL.SCHEDULE : Not found...'
        GOSUB FATAL.ERROR99
    END

    STR.CODE = 0

    PAUSE.SERVICE = 60

    CMD="whoami"
* CMD ="WHO"
    EXECUTE CMD RTNLIST LIST.WHO CAPTURING CAPT.WHO
* STR.CURRENT.ENV=FIELD(CAPT.WHO,' ',2)
    STR.CURRENT.ENV = TRIM(STR.CURRENT.ENV)

    LIST.SERVICE = ''
    LIST.TSA = ''

    R.LIST.SERVICE = ''
    LIST.TSA = ''
    SCH.KEY = ''

    COMMAND.LINE.ARGUMENT = TRIM(@SENTENCE, SPACE(1), 'R')
    COMMAND.LINE.ARGUMENT =  TRIM(FIELD(COMMAND.LINE.ARGUMENT,' ',2))

    SCH.KEY = COMMAND.LINE.ARGUMENT
    READ R.LIST.SERVICE FROM F.SEL.SCHEDULE,SCH.KEY ELSE NULL
    IF R.LIST.SERVICE = '' THEN
        PRINT ' Argument ':COMMAND.LINE.ARGUMENT:' Not Valid....'
        PRINT ' No Record Found to process...'
        GOSUB FATAL.ERROR99
    END


    RETURN

*****************
PROCESS.START.TSA:
*****************

    PRINT OCONV(TIME(),"MTS"):"TSA SERVICE ":COMMAND.LINE.ARGUMENT:" En cours de demarrage..."
    LIST.SERVICE = R.LIST.SERVICE<SEL.SCH.TSA.SERVICE>
    CONVERT @VM TO @FM IN LIST.SERVICE
    NB.FM = 1
    NB.FM = DCOUNT(LIST.SERVICE,@FM)
    FOR I = 1 TO NB.FM
        KEY.SERVICE = ''
        R.KEY.SERVICE = ''
        SERV.CONTROL = ''
        UPDATE.CONTROL = ''
        KEY.SERVICE = LIST.SERVICE<I>
        READ R.KEY.SERVICE FROM F.TSA.SERVICE,KEY.SERVICE ELSE NULL
        IF R.KEY.SERVICE THEN
            SERV.CONTROL = R.LIST.SERVICE<SEL.SCH.SERVICE.CONTROL,I>
            UPDATE.CONTROL = R.KEY.SERVICE<TS.TSM.SERVICE.CONTROL>
            IF UPDATE.CONTROL = 'STOP' OR UPDATE.CONTROL ='' THEN
                GOSUB CHECK.AND.UPDATE
            END
        END ELSE
            PRINT OCONV(TIME(),"MTS"):" TSA SERVICE ":KEY.SERVICE:" Inexistant..."
            STR.CODE = 77
        END
    NEXT I

    RETURN

*****************
CHECK.AND.UPDATE:
*****************

    GOSUB VERIFY.TSA

    IF SW.TSM.OK THEN
        PRINT OCONV(TIME(),"MTS"):" TSA Service ":KEY.SERVICE:" Deja running"
        STR.CODE = 77
    END

    R.SERVICE = ''
    READU R.SERVICE FROM F.TSA.SERVICE, KEY.SERVICE ELSE
        PRINT OCONV(TIME(),"MTS"):" ":KEY.SERVICE :" n'existe pas dans " : F.TSA.SERVICE : "."
        STR.CODE = 77
    END


    IF (SERV.CONTROL = 'START' OR SERV.CONTROL = 'AUTO') AND R.SERVICE  AND NOT(SW.TSM.OK) THEN
        R.SERVICE<TS.TSM.SERVICE.CONTROL> = SERV.CONTROL
        WRITE R.SERVICE ON F.TSA.SERVICE, KEY.SERVICE
        RELEASE F.TSA.SERVICE, KEY.SERVICE

        PRINT OCONV(TIME(),"MTS"):" ": KEY.SERVICE :" Updated..."
    END ELSE
        PRINT OCONV(TIME(),"MTS"):" ": KEY.SERVICE :" Non mis a jour."
        STR.CODE = 77
    END

    RETURN

***********
VERIFY.TSA:
***********
    SW.TSM.OK=0
    NB.TST.TSA=0
    KEY.TSA = 1
    NB.TSM = 0
    NB.SELECTED = 0

    CMD.TSM= "SELECT F.TSA.STATUS WITH CURRENT.SERVICE EQ ":KEY.SERVICE:" AND AGENT.STATUS = 'RUNNING' "
    EXECUTE CMD.TSM RTNLIST LIST.TSA CAPTURING CAPT.TSA
    NB.SELECTED = @SELECTED
    LOOP
    WHILE KEY.TSA
        REMOVE KEY.TSA FROM LIST.TSA SETTING KEY.TSA.MORE
        IF KEY.TSA THEN
            READ REC.TSA.STATUS FROM F.TSA.STATUS,KEY.TSA  ELSE NULL
            IF REC.TSA.STATUS THEN
                CMD="WHERE V( ":REC.TSA.STATUS<TS.TSS.PORT.ID>
                PORT.NO = REC.TSA.STATUS<TS.TSS.PORT.ID>
                EXECUTE CMD RTNLIST LIST.WHERE CAPTURING CAPT.WHERE
                CAPT.TSM = ''
                CAPT.TSM = 'tSA ':KEY.TSA

                IF INDEX (CAPT.WHERE, 'User not logged on', 1) THEN
                    PRINT OCONV(TIME(),"MTS"):" Info. - PORT TSA.STATUS ":KEY.SERVICE:" HORS SERVICE: ":PORT.NO
                    PRINT OCONV(TIME(),"MTS"):" Info. - RIEN A FAIRE, Vider peut etre TSA.STATUS "
                    SW.TSM.OK = 1
                END ELSE
                    IF INDEX (CAPT.WHERE,CAPT.TSM,1) THEN
                        PRINT OCONV(TIME(),"MTS"):" Info. - PORT TSA.STATUS ":KEY.SERVICE:" EST Running: ":PORT.NO
                        PRINT OCONV(TIME(),"MTS"):" Info. - RIEN A FAIRE, TSA est actif (Attendre Arret) "
                        SW.TSM.OK = 1
                    END
                END
            END
        END

    REPEAT

    RETURN

*******************
EXECUTE.DAEMON.CMD:
******************

    RETURN.VALUE = ''
    CAPTURE.VALUE = ''
    CALL SYSTEM.CALL ("EXECUTE","UNIX",DAEMON.CMD,CAPTURE.VALUE,RETURN.VALUE)
    RETURN.VALUE = @SYSTEM.RETURN.CODE
    IF RETURN.VALUE <> '0' THEN
        RETURN.VALUE = "UNABLE TO RUN ":DAEMON.CMD
    END

    RETURN

**********
WRITE.COMO:
***********

    WRITE STR.CODE TO F.COMO,'TSA.START' ON ERROR
        PRINT OCONV(TIME(),"MTS"):"  Error. Impossible de rederiger vers COMO."
        PRINT '99'
        STOP
    END

    CLOSE F.COMO
    EXIT(STR.CODE)
    STOP

**************
FATAL.ERROR99:
**************

    STR.CODE = '99'
    GOSUB WRITE.COMO
    STOP
