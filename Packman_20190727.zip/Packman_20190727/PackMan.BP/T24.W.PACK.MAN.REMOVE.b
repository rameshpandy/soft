*-----------------------------------------------------------------------------
* <Rating>2205</Rating>
*-----------------------------------------------------------------------------
*   $PACKAGE Tool_Packman
    
    SUBROUTINE T24.W.PACK.MAN.REMOVE (OFSS.ID, R.LIST.REMOVE, ENS.MSG)
*-----------------------------------------------------------------------------
* author Thierry MARTIN
*=============================================================================
* Modification History :
* dd/mm/yyy    - CD_REFERENCE - author
*              Description of modification.
*-----------------------------------------------------------------------------
*   Date            who                      Reference            Description
* 22/04/2010   Thierry MARTIN                                 Initial Version
* 30/08/2010   Thierry MARTIN            TM_20100830          Correct wrong name when execute T24.F.DECATALOG.
*-----------------------------------------------------------------------------
*=============================================================================
*
    $INSERT I_COMMON
    $INSERT I_EQUATE

    $INSERT I_F.FILE.CONTROL

    GOSUB INITIALISE
    GOSUB OPEN.FILES
    GOSUB PROCESS

    RETURN
*
*===================================================================================
*
INITIALISE:

    ENS.MSG = ""
    NOM.SUBR.TRANS = "EB.TRANS"

    RETURN
*
*===================================================================================
*
OPEN.FILES:

    OPEN "VOC" TO F.VOC ELSE
        IF ENS.MSG # "" THEN ENS.MSG := @FM
        ENS.MSG := "Impossible d'ouvrir la table VOC"
        GO ON.ERROR
    END

    F.MY.FILE.CONTROL = "" ; FN.MY.FILE.CONTROL = "F.FILE.CONTROL"
    CALL OPF (FN.MY.FILE.CONTROL, F.MY.FILE.CONTROL)

    RETURN
*
*===================================================================================
*
PROCESS:

    NB.LIG = DCOUNT(R.LIST.REMOVE, @FM)
    FOR I.LIG = 1 TO NB.LIG
        LIG.REMOVE = TRIM(R.LIST.REMOVE<I.LIG>)
        NB.ESP = DCOUNT(LIG.REMOVE, " ")
        SUPP.HIS = 0
        IF LIG.REMOVE[" ", NB.ESP, 1] = "$HIS" THEN
            SUPP.HIS = 1
            NB.ESP = NB.ESP - 1
        END
        IF NB.ESP > 1 THEN
            NOM.TABLE = LIG.REMOVE[" ", 1, 1]
            BEGIN CASE
            CASE NOM.TABLE = "FILE.CONTROL"
                GOSUB REMOVE.FILE.CONTROL
            CASE NOM.TABLE[3] = ".BP"
                GOSUB REMOVE.BP
            CASE OTHERWISE
                GOSUB REMOVE.RECORD
            END CASE
        END ELSE ; * IF NB.ESP > 1
            IF ENS.MSG # "" THEN ENS.MSG := @FM
            ENS.MSG := "La ligne " : I.LIG : " ne contient pas de table ou pas de cle, elle est ignoree"
        END ; * ELSE IF NB.ESP > 1
    NEXT I.LIG

    RETURN
*
*===================================================================================
*
REMOVE.BP:
* Suppression des programmes BASIC

    LISTE.BP = LIG.REMOVE[" ", 2, NB.ESP - 1]
* Decatalogue les programmes
    CMD.DECATALOG = "T24.F.DECATALOG " : NOM.TABLE : " " : LISTE.BP ; * TM_20100830
    EXECUTE CMD.DECATALOG CAPTURING RIEN
* Supprime les sources et codes objets
    CMD.DELETE = "DELETE " : NOM.TABLE : " " : LISTE.BP : " $" : EREPLACE(LISTE.BP, " ", " $")
    EXECUTE CMD.DELETE CAPTURING RIEN
* Supprime l'entree de VOC
    FOR I.ESP = 2 TO NB.ESP
        ID.BP = LIG.REMOVE[" ", I.ESP, 1] ; RETRY = ""
        READU A.VOC FROM F.VOC, ID.BP THEN
            IF A.VOC = "GLOBUS.BP" : @FM : NOM.TABLE THEN
                DELETE F.VOC, ID.BP
            END ELSE
                RELEASE F.VOC, ID.BP
            END
        END ELSE
            RELEASE F.VOC, ID.BP
        END
    NEXT I.ESP

    GOSUB TRANS.ENDSTART

    RETURN
*
*===================================================================================
*
REMOVE.FILE.CONTROL:
* Suppression dans FILE.CONTROL

    FOR I.ESP = 2 TO NB.ESP
        ID.FILE.CONTROL = LIG.REMOVE[" ", I.ESP, 1] ; RETRY = ""
        CALL F.READU (FN.MY.FILE.CONTROL, ID.FILE.CONTROL, R.FILE.CONTROL, F.MY.FILE.CONTROL, ERR.FC, RETRY)
        IF ERR.FC = "" THEN
* Suppression du VOC de la table live
            FN.REMOVE = "F." : ID.FILE.CONTROL : @FM : "NO.FATAL.ERROR" ; F.REMOVE = ""
            CALL OPF (FN.REMOVE, F.REMOVE)
            IF NOT(ETEXT) THEN
                CLOSE F.REMOVE
                CMD.DEL = "DELETE.FILE " : FN.REMOVE
                EXECUTE CMD.DEL CAPTURING SORTIE
                DELETE F.VOC, FN.REMOVE
                IF FN.REMOVE[".", 1, 1] # "F" THEN
* Suppression de F. dans le VOC qui contient uniquement le DICT 
                    DELETE F.VOC, "F." : ID.FILE.CONTROL
                END
            END ; * IF NOT(ETEXT)
* Suppression du VOC des tables secondaires
            NB.SUFFIXE = DCOUNT(R.FILE.CONTROL<EB.FILE.CONTROL.SUFFIXES>, @VM)
            FOR I.SUFFIXE = 1 TO NB.SUFFIXE
                FN.REMOVE = "F." : ID.FILE.CONTROL : R.FILE.CONTROL<EB.FILE.CONTROL.SUFFIXES, I.SUFFIXE> : @FM : "NO.FATAL.ERROR"
                F.REMOVE = ""
                CALL OPF (FN.REMOVE, F.REMOVE)
                IF NOT(ETEXT) THEN
                    CLOSE F.REMOVE
                    CMD.DEL = "DELETE.FILE " : FN.REMOVE
                    EXECUTE CMD.DEL CAPTURING SORTIE
                    DELETE F.VOC, FN.REMOVE
                END
            NEXT I.SUFFIXE
        END ; * IF ERR.FC = ""
* Suppression de FILE.CONTROL
        CALL F.DELETE (FN.MY.FILE.CONTROL, ID.FILE.CONTROL)
    NEXT I.ESP
    GOSUB TRANS.ENDSTART

    RETURN
*
*===================================================================================
*
REMOVE.RECORD:
* Suppression d'enregistrements

    CALL F.READ (FN.MY.FILE.CONTROL, NOM.TABLE, R.FILE.CONTROL, F.MY.FILE.CONTROL, ERR.FC)
    IF ERR.FC = "" THEN
        PRG.INFO = ""
        APPLI.COMP = NOM.TABLE
*        TABLE.CORRECTE = CALLC JBASESubroutineExist (APPLI.COMP, PRG.INFO)
    END ELSE ; * IF ERR.FC = ""
        TABLE.CORRECTE = 0
    END
    IF TABLE.CORRECTE THEN
* Pas de suppression si la table n'existe plus
        FN.REMOVE = "F." : NOM.TABLE : @FM : "NO.FATAL.ERROR" ; F.REMOVE = ""
        CALL OPF (FN.REMOVE, F.REMOVE)
        IF ETEXT THEN
            RETURN
        END
* Controle l'existance de la table $NAU
        LOCATE "$NAU" IN R.FILE.CONTROL<EB.FILE.CONTROL.SUFFIXES, 1> SETTING I.NAU THEN
            FN.REMOVE$NAU = "F." : NOM.TABLE : "$NAU" : @FM : "NO.FATAL.ERROR" ; F.REMOVE$NAU = ""
            CALL OPF (FN.REMOVE$NAU, F.REMOVE$NAU)
            IF NOT(ETEXT) THEN
                PRES.NAU = 1
            END
        END
* Controle l'existance de la table $HIS
        PRES.HIS = 0
        IF SUPP.HIS THEN
            LOCATE "$HIS" IN R.FILE.CONTROL<EB.FILE.CONTROL.SUFFIXES, 1> SETTING I.HIS THEN
                FN.REMOVE$HIS = "F." : NOM.TABLE : "$HIS" : @FM : "NO.FATAL.ERROR" ; F.REMOVE$HIS = ""
                CALL OPF (FN.REMOVE$HIS, F.REMOVE$HIS)
                IF NOT(ETEXT) THEN
                    PRES.HIS = 1
                END
            END
        END ; * IF SUPP.HIS
        FOR I.ESP = 2 TO NB.ESP
            ID.REMOVE = LIG.REMOVE[" ", I.ESP, 1]
            TABLE.CORRECTE = 1
            IF NOM.TABLE = "VERSION" THEN
                APPLI.COMP = ID.REMOVE[",", 1, 1]
                PRG.INFO = ""
*                TABLE.CORRECTE = CALLC JBASESubroutineExist (APPLI.COMP, PRG.INFO)
            END
            IF TABLE.CORRECTE THEN
                IF PRES.NAU THEN
                    READ R.REMOVE FROM F.REMOVE$NAU, ID.REMOVE THEN
* Delete l'enregistrement dans $NAU
                        FCT.OFS = "D"
                        GOSUB APPEL.OFS
                        IF OFS.MESSAGE['/', 3 + COUNT(ID.REMOVE, "/"), 1] = -1 THEN
                            IF ENS.MSG # "" THEN ENS.MSG := @FM
                            ENS.MSG := "Erreur OFS " : OFS.MESSAGE : " pour supprimer (Delete) " : ID.REMOVE : " dans " : NOM.TABLE : "$NAU"
                        END ELSE ; * IF OFS erreur
                            READ R.REMOVE FROM F.REMOVE$NAU, ID.REMOVE THEN
                                IF ENS.MSG # "" THEN ENS.MSG := @FM
                                ENS.MSG := "Sans erreur OFS " : ID.REMOVE : " n'a pas ete supprime (Delete) de " : NOM.TABLE : "$NAU"
                            END
                        END ; * ELSE IF OFS erreur
                        GOSUB TRANS.ENDSTART
                    END ; * READ FROM F.REMOVE$NAU
                END ; * IF PRES.NAU
                READ R.REMOVE FROM F.REMOVE, ID.REMOVE THEN
* Reverse l'enregistrement dans live
                    FCT.OFS = "R"
                    GOSUB APPEL.OFS
                    IF OFS.MESSAGE['/', 3 + COUNT(ID.REMOVE, "/"), 1] = -1 THEN
                        IF ENS.MSG # "" THEN ENS.MSG := @FM
                        ENS.MSG := "Erreur OFS " : OFS.MESSAGE : " pour annuler (Reverse) " : ID.REMOVE : " dans " : NOM.TABLE
                    END ELSE ; * IF OFS erreur
                        READ R.REMOVE FROM F.REMOVE, ID.REMOVE THEN
                            IF ENS.MSG # "" THEN ENS.MSG := @FM
                            ENS.MSG := "Sans erreur OFS " : ID.REMOVE : " n'a pas ete annule (Reverse) de " : NOM.TABLE
                        END ELSE ; * READ R.REMOVE
                            IF PRES.HIS THEN
* Supprime les historiques
                                I.HIS = 1
                                LOOP
                                    ID.HIS = ID.REMOVE : ";" : I.HIS
                                    READU R.REMOVE FROM F.REMOVE$HIS, ID.HIS ELSE
                                        RELEASE F.REMOVE$HIS, ID.HIS
                                        EXIT
                                    END
                                    DELETE F.REMOVE$HIS, ID.HIS
                                    I.HIS = I.HIS + 1
                                REPEAT
                            END ; * IF PRES.HIS
                        END ; * ELSE READ R.REMOVE
                    END ; * ELSE IF OFS erreur
                    GOSUB TRANS.ENDSTART
                END ; * READ FROM F.REMOVE
            END ; * IF TABLE.CORRECTE
        NEXT I.ESP
    END ; * IF TABLE.CORRECTE

    RETURN
*
*===================================================================================
*
APPEL.OFS:
* Appel OFS pour D ou R de l'enregistrement

    OFS.MESSAGE = NOM.TABLE : ",/" : FCT.OFS : "/PROCESS//0,,"
    IF ID.REMOVE MATCH '1A' THEN
        OFS.MESSAGE := "."
    END
    OFS.MESSAGE := CONVERT(",/", "?^", ID.REMOVE)
    CALL OFS.GLOBUS.MANAGER (OFSS.ID, OFS.MESSAGE)

    RETURN
*
*===================================================================================
*
TRANS.ENDSTART:

* Decoupe les actions en transactions unitaires, sinon en cas d'erreur OFS le TRANSACTION.ABORT va annuler tout ce qui a ete fait avant
    IF RUNNING.UNDER.BATCH THEN
        GOSUB TRANS.END
        GOSUB TRANS.START
    END ELSE
        CALL JOURNAL.UPDATE ("AB.PACK.MAN.REMOVE")
    END

    RETURN
*
*===================================================================================
*
TRANS.END:

    IF RUNNING.UNDER.BATCH THEN
        CALL @NOM.SUBR.TRANS ("END", MSG.TRANS)
    END

    RETURN
*
*===================================================================================
*
TRANS.START:

    IF RUNNING.UNDER.BATCH THEN
        CALL @NOM.SUBR.TRANS ("START", MSG.TRANS)
    END

    RETURN
*
*===================================================================================
*
ON.ERROR:
    RETURN TO ON.ERROR
