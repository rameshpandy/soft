*-----------------------------------------------------------------------------
* <Rating>5</Rating>
*-----------------------------------------------------------------------------
    PROGRAM ESB.OUTBOUND

************************************************************************
* T24 OFS Source Configuration
************************************************************************

    GOSUB OPEN.FILES
*
    GOSUB GET.DATE.TIME
*
*    ctxenv<-1> = "MQSeries"
*    ctxenv<-1> = "NTAS107703T74"
*    ctxenv<-1> = "1414"
*    ctxenv<-1> = "IIB.INT01"
*    ctxenv<-1> = "T24.JMS_CHANNEL"
*    ctxenv<-1> = "uttmq01"
*    ctxenv<-1> = "pass@123"
*    requestQueue="T24.OUTBOUND_REQUEST"
*    replyQueue="T24.OUTBOUND_REPLY"


    ctxenv<-1> = "MQSeries"
    ctxenv<-1> = "NTAS102083T14"
    ctxenv<-1> = "1414"
    ctxenv<-1> = "TST.LDBSRV1"
    ctxenv<-1> = "CLI.LDB_2"
    ctxenv<-1> = "mquser"
    ctxenv<-1> = "123"
    requestQueue="DEV.Z6.LDB.LDB2T24_REQUEST.R.Z6"
    replyQueue="DEV.Z6.LDB.T242LDB_RESPONSE.R.Z6"

	
    replyQueue="DEV.Z6.LDB.LDB2T24_REQUEST.R.Z6"
    requestQueue="DEV.Z6.LDB.T242LDB_RESPONSE.R.Z6"
	
	
*DEV.Z6.LDB.T242LDB_REQUEST.W.Z6 IF.INTEGRATION.FRAMEWORK	
DEBUG	
	
    PRINT W.ACTUAL.DATETIME : "starting.. ":ctxenv<4>
    CONNECTION = JMSGETCONNECTION(ctxenv) ;* Create a initial JMS Context
    PRINT "Connected: ":CONNECTION<1>:" with ":CONNECTION<2>
    CONTEXT = CONNECTION
    SUCCESS = CONNECTION<1>
    IF NOT(SUCCESS) THEN
        CRT W.ACTUAL.DATETIME : "Error : " : CONTEXT<2>
        STOP
    END
*    CRT "conexiune buna":CONTEXT
************************************************************************
* JMS Session
************************************************************************

    SESSION = JMSGETSESSION(CONTEXT, connectionFactory)  ;* Create a JMS QueueSession giving a valid QueueConnectionFactory, passing the initial JMS Context


************************************************************************
* Queue Connection
************************************************************************
    SUCCESS = SESSION<1>
    IF NOT(SUCCESS) THEN
        CRT "Error : " : SESSION<2>
        STOP
    END

    QUEUEReceive = JMSGETQUEUE(SESSION, requestQueue, 0) ;* Create a Queue for get (last parameter is 1-Post or 0-Get

    SUCCESS = QUEUEReceive<1>
    IF NOT(SUCCESS) THEN
        CRT "Error : " : QUEUEReceive<2>
        STOP
    END


    QUEUEPost = JMSGETQUEUE(SESSION, replyQueue, 1) ;* Create a Queue for post (last parameter is 1-Post or 0-Get

    SUCCESS = QUEUEPost<1>
    IF NOT(SUCCESS) THEN
        CRT "Error : " : QUEUEPost<2>
        STOP
    END

************************************************************************
* T24 OFS Source Configuration
************************************************************************
    OFSSource = "ESBIF"

    IF GETENV("OFS_SOURCE") = "" THEN
        IF PUTENV("OFS_SOURCE=":OFSSource) THEN
            CRT W.ACTUAL.DATETIME : "OFS_SOURCE defaulted to '":OFSSource:"'"
        END
    END


***********************************************************************
* Start T24
************************************************************************
    CALL JF.INITIALISE.CONNECTION ;* INITIALIZE T24 Session
*    CRT "BEFORE LOOP"
************************************************************************
* Loop Read Queue
************************************************************************
AGAIN:

    GOSUB GET.DATE.TIME
    CRT W.ACTUAL.DATETIME : "Waiting/Retrieve a message" 
    R.COMO = " " 
    CALL OCOMO("TEST MESSAGE" : W.ACTUAL.DATETIME)    

    REQUEST = JMSGET(QUEUEReceive) ;* Waiting/Retrieve a message

    R.COMO<-1> = W.ACTUAL.DATETIME : "message received from MQ: ":REQUEST

    CRT W.ACTUAL.DATETIME : "message received: ":REQUEST
    CORRID = REQUEST<1>
    REQUEST = REQUEST<2>

*    REQUEST = FORMATTERSET(FORMATTER, REQUEST)

    CHANGE "optOperation" TO "ofsOperation" IN REQUEST
    RESPONSE = REQUEST
    CRT W.ACTUAL.DATETIME : "Send the message to T24: ":REQUEST

    CALL OFS.BULK.MANAGER(REQUEST, RESPONSE, COMMITED) ;* Pass the message to OFS.BULK.MANAGER
    
*    CALL JOURNAL.UPDATE("")

    CRT W.ACTUAL.DATETIME : "reply from T24 ":RESPONSE

*	RESPONSE = FORMATTERPROCESS(FORMATTER, REQUEST, RESPONSE)
 
    
    GOSUB GET.DATE.TIME

    CRT W.ACTUAL.DATETIME : "message sent to MQ: "
    CRT RESPONSE
    R.COMO<-1> = W.ACTUAL.DATETIME : "message sent to MQ: ":RESPONSE

    SUCCESS = JMSPOST(QUEUEPost, RESPONSE, CORRID) ;* Send the response back.

    GOSUB WRITE.COMO
    GOTO AGAIN


    RETURN



*****************************************************
GET.DATE.TIME:
*****************************************************
    DATETIME = OCONV(DATE(),"D-")
*    DATETIME = DATETIME[7,4]:DATETIME[1,2]:DATETIME[4,2]
    YTIME = OCONV(TIME(),'MT')
    DATETIME := " " : YTIME[1,2] : ":" : YTIME[4,2]

    W.ACTUAL.DATETIME = "[" : DATETIME : "]"
    RETURN

*****************************************************
OPEN.FILES:
*****************************************************

    OPEN './&COMO&' TO F.COMO ELSE
        STOP 201,'CANT OPEN &COMO&'
    END

    COMO.ID = "ESB.OUTBOUND." : TIME() : ".log"

    RETURN
*------------------------------------------------------------------------------
*
WRITE.COMO:
*
    READU W.DUMMY FROM F.COMO, COMO.ID ELSE
        NULL
    END

    R.COMO = W.DUMMY : R.COMO 


    WRITE R.COMO TO F.COMO, COMO.ID ON ERROR
        RELEASE F.COMO, COMO.ID
    END
*
    RETURN
