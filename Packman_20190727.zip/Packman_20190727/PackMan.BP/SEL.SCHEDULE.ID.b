*-----------------------------------------------------------------------------
* <Rating>-23</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE SEL.SCHEDULE.ID

*** <region name= PROGRAM DESCRIPTION>
***
* Program Description

*-----------------------------------------------------------------------------
*** </region>

*** <region name= MODIFICATION HISTORY>
***
* Modification History :
*=========================================================================
*========================================================================
*-----------------------------------------------------------------------------
*** </region>

*** <region name= INSERTS>
***
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.TSA.SERVICE
    $INSERT I_F.BATCH
    $INSERT I_F.TSA.STATUS
*-----------------------------------------------------------------------------
*** </region>

*** <region name= MAIN PROCESSING>
***
    GOSUB INITIALISE
*
    GOSUB CHECK.ID
*
    RETURN
*-----------------------------------------------------------------------------
*** </region>

*** <region name= DEFINE FIELDS>
***
CHECK.ID:
**************
    IF ID.NEW # 'COB' AND ID.NEW # 'DAY' AND ID.NEW # 'HOLIDAY' THEN
*        E = "ID MUST BE COB_DAY_HOLIDAY"
    END

    RETURN
*-----------------------------------------------------------------------------
*** </region>

*** <region name= INIT>
***
INITIALISE:
***********
*
*
    RETURN
*-----------------------------------------------------------------------------
*** </region>
END
