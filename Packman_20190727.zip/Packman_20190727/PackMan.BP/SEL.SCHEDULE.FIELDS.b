*-----------------------------------------------------------------------------
* <Rating>-22</Rating>
*-----------------------------------------------------------------------------
    SUBROUTINE SEL.SCHEDULE.FIELDS

*** <region name= PROGRAM DESCRIPTION>
***
* Program Description

*-----------------------------------------------------------------------------
*** </region>

*** <region name= MODIFICATION HISTORY>
***
* Modification History :
*=========================================================================
*========================================================================
*-----------------------------------------------------------------------------
*** </region>

*** <region name= INSERTS>
***
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.TSA.SERVICE
    $INSERT I_F.BATCH
    $INSERT I_F.TSA.STATUS
*-----------------------------------------------------------------------------
*** </region>

*** <region name= MAIN PROCESSING>
***
    GOSUB INITIALISE
*
    GOSUB DEFINE.FIELDS
*
    RETURN
*-----------------------------------------------------------------------------
*** </region>

*** <region name= DEFINE FIELDS>
***
DEFINE.FIELDS:
**************

    ID.F = "TSA.PROG.ID"
    ID.N = '016.1'
    ID.T<1> = "A"
    ID.CONCATFILE = 'AR'

*
    Z = 0

    Z+=1
    F(Z) = "DESCRIPTION" ; N(Z) = "35.1.C" ; T(Z) = "A"

    Z+=1
    F(Z) = "XX<TSA.SERVICE" ; N(Z) = "35.1.C" ; T(Z) = "A"
    CHECKFILE(Z) = "TSA.SERVICE":FM:TS.TSM.DESCRIPTION

    Z+=1
    F(Z) = "XX-VERIFICATION" ; N(Z) = "35" ; T(Z) = "A"
    CHECKFILE(Z) = "TSA.SERVICE":FM:TS.TSM.DESCRIPTION

    Z+=1
    F(Z)='XX>SERVICE.CONTROL'
    N(Z)='10.1'
    T(Z)<2>='STOP_START_AUTO'

    Z+=1 ; F(Z) = "XX.LOCAL.REF" ; N(Z) = "35" ; T(Z) = "A"

    Z+=1 ; F(Z) = "RESERVED10" ; N(Z) = "35" ; T(Z) = ''
    T(Z)<3> = "NOINPUT"

    Z+=1 ; F(Z) = "RESERVED09" ; N(Z) = "35" ; T(Z) = ''
    T(Z)<3> = "NOINPUT"

    Z+=1 ; F(Z) = "RESERVED08" ; N(Z) = "35" ; T(Z) = ''
    T(Z)<3> = "NOINPUT"

    Z+=1 ; F(Z) = "RESERVED07" ; N(Z) = "35" ; T(Z) = ''
    T(Z)<3> = "NOINPUT"

    Z+=1 ; F(Z) = "RESERVED06" ; N(Z) = "35" ; T(Z) = ''
    T(Z)<3> = "NOINPUT"

    Z+=1 ; F(Z) = "RESERVED05" ; N(Z) = "35" ; T(Z) = ''
    T(Z)<3> = "NOINPUT"

    Z+=1 ; F(Z) = "RESERVED04" ; N(Z) = "35" ; T(Z) = ''
    T(Z)<3> = "NOINPUT"

    Z+=1 ; F(Z) = "RESERVED03" ; N(Z) = "35" ; T(Z) = ''
    T(Z)<3> = "NOINPUT"

    Z+=1 ; F(Z) = "RESERVED02" ; N(Z) = "35" ; T(Z) = ''
    T(Z)<3> = "NOINPUT"

    Z+=1 ; F(Z) = "RESERVED01" ; N(Z) = "35" ; T(Z) = ''
    T(Z)<3> = "NOINPUT"

*
    V = Z + 9
*
    RETURN
*-----------------------------------------------------------------------------
*** </region>

*** <region name= INIT>
***
INITIALISE:
***********
    MAT F = "" ; MAT N = "" ; MAT T = ""
    MAT CHECKFILE = "" ; MAT CONCATFILE = ""
    ID.CHECKFILE = "" ; ID.CONCATFILE = ""
*
*
    RETURN
*-----------------------------------------------------------------------------
*** </region>
END
