    PROGRAM PACK.DELETE.REC.INAU
*-----------------------------------------------------------------------------
* program to save and to delete records from INAU
*-----------------------------------------------------------------------------
    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.FILE.CONTROL
*-----------------------------------------------------------------------------
* 20190103 - MCAPPA - EXIT() does not work (!). Using returned string (CRT) instead.
*-----------------------------------------------------------------------------

    GOSUB INITIALISE
    IF W.CONTINUE = 'Y' THEN
        GOSUB PROCESS
    END
    IF W.CONTINUE NE 'IP' THEN
        GOSUB WRITE.LOG
    END    
    
	*** ERROR: EXIT() ALWAYS returns '1' !!! -- MCAPPA 20190103.
	IF W.RET.CODE GT 0 THEN
		EXIT(W.RET.CODE)
	END

    RETURN    
********************************************************************************
INITIALISE:
********************************************************************************
    W.CONTINUE = 'Y'
    W.RET.CODE = 0
    Y.LOG.MSG = "TABLE;ID;STATUS"
    
    IF SENTENCE(1) = '' OR SENTENCE(2) = '' THEN
        CRT 'INPUT PATH AND FILE NAME ARE REQUIRED'
        W.CONTINUE='IP'
        W.RET.CODE=1  
        RETURN 
    END
    
    OPEN 'F.FILE.CONTROL' TO F.FILE.CONTROL ELSE
        CRT 'UNABLE TO OPEN FILE.CONTROL'
        W.CONTINUE='IP'
        W.RET.CODE=2  
        RETURN 
    END
     
* Open table
    FN.PATH = SENTENCE(1)
    F.PATH = ''
    OPEN FN.PATH TO F.PATH ELSE 
        CRT 'COULD NOT OPEN THE FILE: ' : FN.PATH
        W.CONTINUE='IP'
        W.RET.CODE=3
        RETURN   
    END
    
    FILE.IN = SENTENCE(2)
    READ FILES.REC FROM F.PATH,FILE.IN ELSE
        Y.LOG.MSG<-1> = "MISSING INPUT FILE: " : FILE.IN
		CRT 'MISSING INPUT FILE: ' : FILE.IN
        W.RET.CODE=4
        RETURN
    END

    EXECUTE "CREATE-FILE SAVE.REC.INAU.UPGRADE TYPE=UD" CAPTURING W.ERR
    FN.SAVE = "SAVE.REC.INAU.UPGRADE"
    F.SAVE = ''
    OPEN FN.SAVE TO F.SAVE ELSE 
        Y.LOG.MSG<-1> = "ERROR DURING THE CREATION OF THE SAVE FOLDER: " : W.ERR
		CRT 'ERROR DURING THE CREATION OF THE SAVE FOLDER: ' : W.ERR
        W.RET.CODE=5
        RETURN 
    END    
    
    RETURN

********************************************************************************
PROCESS:
********************************************************************************
    YPREV.TABLE.ID = ''
    LOOP
        REMOVE W.REC FROM FILES.REC SETTING YPOS
    WHILE W.REC : YPOS
        YDO.OPF = ''
        YFILE.CLASS.TYPE = ''
        W.TABLE.NAME = TRIM(FIELDS(W.REC,";",1))
        W.TABLE.ID = TRIM(FIELDS(W.REC,";",2))
        IF W.TABLE.NAME = '' OR W.TABLE.ID = '' THEN
            Y.LOG.MSG<-1> = W.REC : ";" : "MISSING FILE NAME OR ID"
            CONTINUE
        END
 
        IF NOT(YPREV.TABLE.ID) THEN
            YPREV.TABLE.ID = W.TABLE.NAME
            YDO.OPF = 1
        END ELSE
            IF YPREV.TABLE.ID NE W.TABLE.NAME THEN
               YPREV.TABLE.ID = W.TABLE.NAME
               YDO.OPF = 1
            END
        END 

        YFC.REC = ''
        READ YFC.REC FROM F.FILE.CONTROL, W.TABLE.NAME THEN
              YFILE.CLASS.TYPE = YFC.REC<EB.FILE.CONTROL.CLASS>     ;** GET CLASSIFICATION FROM FILE.CONTROL
        END ELSE
              Y.LOG.MSG<-1> = W.REC : ";" : "COULDN'T OPEN FILE.CONTROL:" : W.TABLE.NAME
              CONTINUE  
        END

        IF NOT(INDEX(W.TABLE.NAME,"$NAU",1)) THEN
            W.TABLE.NAME = W.TABLE.NAME : '$NAU'
        END

        IF NOT(W.TABLE.NAME[1,2]='F.') THEN
            IF NOT(W.TABLE.NAME[1,5]='FBNK.') THEN
                IF YFILE.CLASS.TYPE EQ 'INT' THEN 
                    W.TABLE.NAME = 'F.' : W.TABLE.NAME
                END ELSE
                    W.TABLE.NAME = 'FBNK.' : W.TABLE.NAME
                END 
            END
        END

        IF YDO.OPF THEN
            FN.TABLE = W.TABLE.NAME
            F.TABLE = ''
            OPEN FN.TABLE TO F.TABLE ELSE 
                 Y.LOG.MSG<-1> = W.REC : ";" : "COULDN'T OPEN TABLE:" : FN.TABLE
                 CONTINUE  
            END
        END
        
        READ REC.TO.MOVE FROM F.TABLE,W.TABLE.ID ELSE
            Y.LOG.MSG<-1> = W.REC : ";" : "MISSING ID"
            CONTINUE 
        END        
        
**SG        W.TABLE.ID = W.TABLE.NAME : ";" : W.TABLE.ID 
**SG        WRITE REC.TO.MOVE TO F.SAVE,W.TABLE.ID ON ERROR

** W.TABLE.ID IS ALREADY USED SO USE DIFFERENT VARIABLE NAME HERE

        W.TABLE.ID.SG = W.TABLE.NAME : ";" : W.TABLE.ID    ;**SG
        WRITE REC.TO.MOVE TO F.SAVE, W.TABLE.ID.SG ON ERROR    ;**SG
            Y.LOG.MSG<-1> = W.REC : ";" : "FAILING TO SAVE THIS RECORD"
            CONTINUE         
        END
        
        DELETE F.TABLE, W.TABLE.ID
        Y.LOG.MSG<-1> = W.REC : ";" : "DONE"
        CALL HUSHIT(1)       
        CALL JOURNAL.UPDATE('')
        CALL HUSHIT(0)
    REPEAT
    
    RETURN
    
********************************************************************************
WRITE.LOG:
********************************************************************************
    W.LOG.FILE.NAME = FILE.IN : ".log"
    WRITE Y.LOG.MSG TO F.PATH, W.LOG.FILE.NAME
    CALL HUSHIT(1)
    CALL JOURNAL.UPDATE('')
    CALL HUSHIT(0)
    RETURN
END
