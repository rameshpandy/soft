* Version 1 13/04/00  GLOBUS Release No. 200508 30/06/05
*-----------------------------------------------------------------------------
* <Rating>0</Rating>
*-----------------------------------------------------------------------------
      SUBROUTINE TOOL.PERF.TEST.WRITE.SELECT
*-----------------------------------------------------------------------------
* Dror Traub 2017-01-13
*-----------------------------------------------------------------------------
$INSERT I_COMMON
$INSERT I_EQUATE
$INSERT I_BATCH.FILES
$INSERT I_TOOL.PERF.TEST.WRITE.COMMON
*-----------------------------------------------------------------------------

	Y.KEY.LIST = ""
    
    W.NR.REC = 10000
    
    IF BATCH.DETAILS<3,1,1> THEN
         W.NR.REC = BATCH.DETAILS<3,1,1>
    END
    
    FOR I = 1 TO W.NR.REC
        W.KEY.LIST = W.KEY.LIST : FM : I
    NEXT I

   
    *SELECTED = '' 
    *Y.SEL.STMT = 'SELECT ':FN.ILMB.DD.MANDATE:' ' 
    *CALL EB.READLIST (Y.SEL.STMT, Y.KEY.LIST, LIST.NAME, SELECTED, SYSTEM.RETURN.CODE)
    
    CALL BATCH.BUILD.LIST('',Y.KEY.LIST)
    
	RETURN
	
   END
 
