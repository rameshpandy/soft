*-----------------------------------------------------------------------------
* <Rating>1039</Rating>
*-----------------------------------------------------------------------------
    PROGRAM SEL.TSA.UPDATE

    $INSERT I_F.TSA.SERVICE
    $INSERT I_F.TSA.STATUS
* ==================================================================================================================
*
*  Syntax
*  1.         SEL.TSA.UPDATE <STOP> ALL_TSA
*  2.         SEL.TSA.UPDATE <STOP> <TSA.SERVICE.ID>
*  3.         SEL.TSA.UPDATE <STOPWAIT> ALL_TSA
*  4.         SEL.TSA.UPDATE <STOPWAIT> <TSA.SERVICE.ID> [<TSA.SERVICE.ID> [<TSA.SERVICE.ID> etc. ]]
*  5.         SEL.TSA.UPDATE <START> <TSA.SERVICE.ID> [<TSA.SERVICE.ID> [<TSA.SERVICE.ID> etc. ]]
*  6.         SEL.TSA.UPDATE <STARTWAIT> <TSA.SERVICE.ID> [<TSA.SERVICE.ID> [<TSA.SERVICE.ID> etc. ]]
*  7.         SEL.TSA.UPDATE <RESTART> ALL_TSA
*  8.         SEL.TSA.UPDATE <RESTART> <TSA.SERVICE.ID> [<TSA.SERVICE.ID> [<TSA.SERVICE.ID> etc. ]]
*  9.         SEL.TSA.UPDATE <AUTO> <TSA.SERVICE.ID> [<TSA.SERVICE.ID> [<TSA.SERVICE.ID> etc. ]]
*  10.        SEL.TSA.UPDATE <STATUS> ALL_TSA
*  11.        SEL.TSA.UPDATE <STATUS> <TSA.SERVICE.ID>
*
*  Version  : 1.0
*  Created  : 20090721 - Ches Rodrigues
*  Function : Start, stop, display and amend statuses for tSAs. This program has been written for use with
*             Tivoli in order to facilitate controlled starting and stopping of interfaces. It can also be used
*             for COB Automation.
*
* ===================================================================================================================
*
* Modifications :
*   29/11/2011, TM_111129 :
*     Ajout du mode STARTWAIT pour demarrer un service et attendre qu'il soit executer.
*   23/01/2014, TM_140123 :
*     Ajout des modes STOPWAIT et RESTART.
*
* ===================================================================================================================

! open tables for read/write

    FN.TSA.SERVICE = 'F.TSA.SERVICE'
    F.TSA.SERVICE  = ''

    OPEN FN.TSA.SERVICE TO F.TSA.SERVICE ELSE
        V_ERROR = 'Unable to open file ':FN.TSA.SERVICE
        GOTO EXIT.PROGRAM
    END

    FN.TSA.STATUS  = 'F.TSA.STATUS'
    F.TSA.STATUS   = ''

    OPEN FN.TSA.STATUS TO F.TSA.STATUS ELSE
        V_ERROR = 'Unable to open file ':FN.TSA.STATUS
        GOTO EXIT.PROGRAM
    END

! define variables

    V_ARGUMENTS           = ''
    V_NUMBER.OF.ARGUMENTS = ''



! validate arguments

    V_UPDATE.MODE = SENTENCE(1)
    V_TSA.ID      = SENTENCE(2)
    V_TSA.MODE.PREC   = ""


    BEGIN CASE

    CASE V_UPDATE.MODE = 'STOP'

        GOSUB READ.ARGUMENTS
        GOSUB UPDATE.TSA

    CASE V_UPDATE.MODE = 'STOPWAIT' ; * TM_140123 s

        GOSUB READ.ARGUMENTS
        V_UPDATE.MODE = "STOP"
        GOSUB UPDATE.TSA
        GOSUB WAIT.AGENT.END ; * TM_140123 e

    CASE V_UPDATE.MODE = 'START'

        GOSUB READ.ARGUMENTS
        GOSUB UPDATE.TSA

    CASE V_UPDATE.MODE = 'STARTWAIT' ; * TM_111129 s

        GOSUB READ.ARGUMENTS
        V_UPDATE.MODE = "START"
        GOSUB UPDATE.TSA
        GOSUB WAIT.TSA.STOP ; * TM_111129 e

    CASE V_UPDATE.MODE = 'RESTART' ; * TM_140123 s

        GOSUB READ.ARGUMENTS
        V_UPDATE.MODE = "STOP"
        GOSUB UPDATE.TSA
        GOSUB WAIT.AGENT.END
        V_UPDATE.MODE = V_TSA.MODE.PREC
        GOSUB UPDATE.TSA ; * TM_140123 e

    CASE V_UPDATE.MODE = 'AUTO'

        GOSUB READ.ARGUMENTS
        GOSUB UPDATE.TSA

    CASE V_UPDATE.MODE = 'STATUS'

        GOSUB READ.ARGUMENTS
        GOSUB DISPLAY.TSA.STATUS

    CASE 1

        GOTO EXIT.PROGRAM

    END CASE

    STOP ; * TM_140123


! read arguments from input buffer

*--------------
READ.ARGUMENTS:
*--------------

    V_TSA.LIST        = ''        ;* a list of all TSA.SERVICE ids - excluding TSM and OLTP
    V_TSA.UPDATE.LIST = ''        ;* a list of tSA agents to be updates
    V_ERROR           = ''        ;* set to 1 if an error is found

! now get a list of all records from TSA.SERVICE

    SELECT F.TSA.SERVICE TO V_TSA.LIST ON ERROR
        V_ERROR = 'Unable to perform SSELECTV on F.TSA.SERVICE'
        GOTO EXIT.PROGRAM
    END

! don't permit a status of START or AUTO for all tSAs

    IF V_TSA.ID = 'ALL_TSA' THEN

        IF V_UPDATE.MODE = 'AUTO' OR V_UPDATE.MODE = 'START' OR V_UPDATE.MODE = 'STARTWAIT' THEN ; * TM_111129
            V_ERROR = 'Invalid syntax - Cannot START/STARTWAIT/AUTO all tSAs' ; * TM_140123
            GOTO EXIT.PROGRAM
        END ELSE
            V_TSA.UPDATE.LIST = V_TSA.LIST

            LOCATE 'TSM' IN V_TSA.UPDATE.LIST<1> SETTING TSM.POS THEN
                DEL V_TSA.UPDATE.LIST<TSM.POS>
            END
            LOCATE 'OLTP' IN V_TSA.UPDATE.LIST<1> SETTING TSM.POS THEN ; * TM_140123 s
                DEL V_TSA.UPDATE.LIST<TSM.POS>
            END ; * TM_140123 e
        END

    END ELSE

        I = 1
        LOOP
            I += 1
        WHILE SENTENCE(I) NE '' DO
            V_TSA.UPDATE.LIST<-1> = SENTENCE(I)
        REPEAT

        V_NUMBER.OF.ARGUMENTS = DCOUNT ( V_TSA.UPDATE.LIST, @FM )

        IF ( V_NUMBER.OF.ARGUMENTS LT 1 ) THEN
            V_ERROR = 'Invalid Syntax - Missing argument 3. No tSA id given.'
            GOTO EXIT.PROGRAM
        END

        CONVERT @FM TO @VM IN V_TSA.LIST        ;* to allow user of MATCHES function

        I = 1
        FOR I = 1 TO V_NUMBER.OF.ARGUMENTS

            IF NOT ( V_TSA.UPDATE.LIST<I> MATCHES V_TSA.LIST ) THEN
                V_ERROR = 'Invalid Syntax - Invalid TSA.SERVICE id = ':V_TSA.UPDATE.LIST<I>
            END

        NEXT I
    END

    IF V_ERROR NE '' THEN
        GOTO EXIT.PROGRAM
    END

    RETURN


! update tSA/tSAs with relevant status

*----------
UPDATE.TSA:
*----------

    V_ERROR               = ''
    V_NUMBER.OF.ARGUMENTS = DCOUNT ( V_TSA.UPDATE.LIST, @FM )

    FOR I = 1 TO V_NUMBER.OF.ARGUMENTS

        V_ID.TSA.SERVICE = V_TSA.UPDATE.LIST<I>
        R.TSA.SERVICE    = ''
        V_ERROR          = ''
        IF INDEX(V_UPDATE.MODE, @FM, 1) THEN ; * TM_140123 s
            V_TSA.UPDATE.MODE = V_UPDATE.MODE<I>
        END ELSE
            V_TSA.UPDATE.MODE = V_UPDATE.MODE
        END
        IF V_TSA.UPDATE.MODE = "" THEN
            CONTINUE
        END ; * TM_140123 e

        READU R.TSA.SERVICE FROM F.TSA.SERVICE, V_ID.TSA.SERVICE LOCKED

            V_ERROR<-1> = 'TSA.SERVICE Record ':V_ID.TSA.SERVICE:' is locked by another process'

        END THEN

            IF (( V_ID.TSA.SERVICE = 'TSM' ) OR ( V_ID.TSA.SERVICE = 'COB' )) AND ( V_TSA.UPDATE.MODE = 'AUTO' ) THEN ; * TM_140123

                V_ERROR<-1> = 'Invalid Syntax - Cannot update ':V_ID.TSA.SERVICE:' to ':V_TSA.UPDATE.MODE ; * TM_140123

            END ELSE

                V_OLD.STATUS = R.TSA.SERVICE<TS.TSM.SERVICE.CONTROL> ; * TM_140123 s
                IF ( V_OLD.STATUS NE V_TSA.UPDATE.MODE ) THEN

                    IF V_OLD.STATUS THEN
                        V_TSA.MODE.PREC<I> = V_OLD.STATUS
                    END ELSE
                        V_TSA.MODE.PREC<I> = "STOP"
                    END ; * TM_140123 e

                    R.TSA.SERVICE<TS.TSM.SERVICE.CONTROL> = V_TSA.UPDATE.MODE ; * TM_140123

                    WRITE R.TSA.SERVICE TO F.TSA.SERVICE, V_ID.TSA.SERVICE ON ERROR
                        V_ERROR<-1> = 'Unable to update TSA.SERVICE id = ':V_ID.TSA.SERVICE
                        CONTINUE
                    END

                    PRINT 'Updated ':V_ID.TSA.SERVICE:' Old Status = ':V_OLD.STATUS:' New Status = ':V_TSA.UPDATE.MODE ; * TM_140123
                END ELSE
                    V_TSA.MODE.PREC<I> = "" ; * TM_140123

                    RELEASE F.TSA.SERVICE, V_ID.TSA.SERVICE
                END

            END

        END ELSE

            V_ERROR<-1> = 'Invalid TSA.SERVICE record id = ':V_ID.TSA.SERVICE

        END

    NEXT I

    IF V_ERROR NE '' THEN
        GOTO EXIT.PROGRAM
    END

    RETURN

! Attend que le TSA.SERVICE passe a STOP

WAIT.TSA.STOP: ; * TM_111129 s, TM_140123 s

    V_NUMBER.OF.ARGUMENTS = DCOUNT ( V_TSA.UPDATE.LIST, @FM ) ; * TM_140127
    LOOP
        ALL.TSA.STOP = 1
        FOR I = 1 TO V_NUMBER.OF.ARGUMENTS WHILE ALL.TSA.STOP
            V_ID.TSA.SERVICE = V_TSA.UPDATE.LIST<I>
            READ R.TSA.SERVICE FROM F.TSA.SERVICE, V_ID.TSA.SERVICE THEN
                IF R.TSA.SERVICE<TS.TSM.SERVICE.CONTROL> # "STOP" THEN
                    ALL.TSA.STOP = 0
                END
            END
        NEXT I
    UNTIL ALL.TSA.STOP DO
        SLEEP 5
    REPEAT

    RETURN ; * TM_111129 e, TM_140123 e

! Attend que les agents soient arretes

WAIT.AGENT.END: ; * TM_140123 s

    LOOP
        ALL.AGENT.END = 1
        SELECT F.TSA.STATUS TO LISTE.SEL.AGENT
        LOOP
            REMOVE TSA.ID FROM LISTE.SEL.AGENT SETTING POS.SEL
        WHILE TSA.ID : POS.SEL DO
            IF TSA.ID MATCH '1N0N' THEN
                READ R.TSA.STATUS FROM F.TSA.STATUS, TSA.ID THEN
                    V_ID.TSA.SERVICE = R.TSA.STATUS<TS.TSS.CURRENT.SERVICE>
                    IF V_ID.TSA.SERVICE AND R.TSA.STATUS<TS.TSS.AGENT.STATUS> = "RUNNING" THEN
                        LOCATE V_ID.TSA.SERVICE IN V_TSA.UPDATE.LIST<1> SETTING POS.TSA THEN
                            ALL.AGENT.END = 0
                        END
                    END
                END
            END
        WHILE ALL.AGENT.END DO
        REPEAT
    UNTIL ALL.AGENT.END DO
        SLEEP 5
    REPEAT

    RETURN ; * TM_140123 e

! display the tSA status

*------------------
DISPLAY.TSA.STATUS:
*------------------

    V_ID = ''

    LOOP

        REMOVE V_ID FROM V_TSA.UPDATE.LIST SETTING POS.SEL ; * TM_140123

    UNTIL V_ID = '' AND NOT(POS.SEL) DO ; * TM_140123

        R.TSA.SERVICE = ''

        READ R.TSA.SERVICE FROM F.TSA.SERVICE, V_ID THEN

            V_STOPPED = 1

            IF R.TSA.SERVICE<TS.TSM.SERVICE.CONTROL> NE 'STOP' THEN

                PRINT V_ID:',':R.TSA.SERVICE<TS.TSM.SERVICE.CONTROL>

            END ELSE

                SELECT.COMMAND = 'SELECT F.TSA.STATUS WITH CURRENT.SERVICE = "':V_ID:'" '

                EXECUTE SELECT.COMMAND CAPTURING RESULT

                LOOP

                    READNEXT TSA.ID ELSE TSA.ID = ''

                UNTIL TSA.ID = '' DO

                    READ R.TSA.STATUS FROM F.TSA.STATUS, TSA.ID THEN

                        IF ( R.TSA.STATUS<TS.TSS.AGENT.STATUS> ) AND ( R.TSA.STATUS<TS.TSS.AGENT.STATUS> NE 'STOPPED' ) THEN

                            V_STOPPED = 0

                        END ELSE
                            V_LAST.CONTACT = R.TSA.STATUS<TS.TSS.LAST.CONTACT>
                            CONVERT ':' TO '' IN V_LAST.CONTACT
                            CURR_TIME = DATE()
                            PRINT 'CURRENT TIME = ':CURR_TIME
                        END
                    END
                REPEAT

                IF V_STOPPED THEN
                    PRINT V_ID:',STOP'
                END ELSE
                    PRINT V_ID:',STOPPING'
                END
            END

        END ELSE
            V_ERROR<-1> = 'Unable to read TSA.SERVICE id = ':V_ID
        END

    REPEAT

    RETURN



! exit the program

*------------
EXIT.PROGRAM:
*------------

    V_ERROR<-1> = 'Version 1.0'
    V_ERROR<-1> = 'Usage Syntax:'
    V_ERROR<-1> = '              SEL.TSA.UPDATE <STOP>      ALL_TSA'
    V_ERROR<-1> = '              SEL.TSA.UPDATE <STOP>      <TSA.SERVICE.ID>'
    V_ERROR<-1> = '              SEL.TSA.UPDATE <STOPWAIT>  ALL_TSA' ; * TM_140123
    V_ERROR<-1> = '              SEL.TSA.UPDATE <STOPWAIT>  <TSA.SERVICE.ID> [<TSA.SERVICE.ID> [<TSA.SERVICE.ID> etc. ]]' ; * TM_140123
    V_ERROR<-1> = '              SEL.TSA.UPDATE <START>     <TSA.SERVICE.ID> [<TSA.SERVICE.ID> [<TSA.SERVICE.ID> etc. ]]'
    V_ERROR<-1> = '              SEL.TSA.UPDATE <STARTWAIT> <TSA.SERVICE.ID> [<TSA.SERVICE.ID> [<TSA.SERVICE.ID> etc. ]]' ; * TM_111129
    V_ERROR<-1> = '              SEL.TSA.UPDATE <RESTART>   ALL_TSA' ; * TM_140123
    V_ERROR<-1> = '              SEL.TSA.UPDATE <RESTART>   <TSA.SERVICE.ID> [<TSA.SERVICE.ID> [<TSA.SERVICE.ID> etc. ]]' ; * TM_140123
    V_ERROR<-1> = '              SEL.TSA.UPDATE <AUTO>      <TSA.SERVICE.ID> [<TSA.SERVICE.ID> [<TSA.SERVICE.ID> etc. ]]'
    V_ERROR<-1> = '              SEL.TSA.UPDATE <STATUS>    ALL_TSA'
    V_ERROR<-1> = '              SEL.TSA.UPDATE <STATUS>    <TSA.SERVICE.ID>'

    ARRAY.SIZE = DCOUNT ( V_ERROR, @FM )

    FOR I =  1 TO ARRAY.SIZE
        PRINT V_ERROR<I>
    NEXT I

    STOP
