* Version 1 13/04/00  GLOBUS Release No. 200508 30/06/05
*-----------------------------------------------------------------------------
* <Rating>0</Rating>
*-----------------------------------------------------------------------------
      SUBROUTINE TOOL.PERF.TEST.READ.LOAD
*-----------------------------------------------------------------------------
* Load routine to setup the common area for the multi-threaded TOOL.PERF.TEST.READ
*-----------------------------------------------------------------------------
$INSERT I_COMMON
$INSERT I_EQUATE
$INSERT I_TOOL.PERF.TEST.READ.COMMON
*-----------------------------------------------------------------------------
* Open files to be used in the XX.EOD routine as well as standard variables.

    FN.TOOL.TEST.PERF.TABLE = 'F.TOOL.TEST.PERF.TABLE'
    F.TOOL.TEST.PERF.TABLE  = ''; 
    CALL OPF(FN.TOOL.TEST.PERF.TABLE, F.TOOL.TEST.PERF.TABLE)
    
    RETURN
END
