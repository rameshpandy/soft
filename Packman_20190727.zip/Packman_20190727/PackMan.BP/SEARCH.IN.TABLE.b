*-----------------------------------------------------------------------------
* <Rating>-1</Rating>
*-----------------------------------------------------------------------------
    PROGRAM SEARCH.IN.TABLE

    $INSERT I_COMMON
    $INSERT I_EQUATE
    $INSERT I_F.CATEGORY

    CRT 'TEXT TO SEARCH='
    INPUT W.SEARCH.TXT

	
    CRT 'TABLE NAME='

    INPUT SEARCH.TABLE
    FN.SEARCH.TABLE  = 'F.' : SEARCH.TABLE
    F.SEARCH.TABLE  = ''

	CALL OPF(FN.SEARCH.TABLE, F.SEARCH.TABLE)

    SEL.CMD = "SELECT " : FN.SEARCH.TABLE
    Y.RECS.SELECTED = 0
    CALL EB.READLIST(SEL.CMD,Y.LIST,"",Y.RECS.SELECTED,"")
    LOOP
        REMOVE Y.ID FROM Y.LIST SETTING ID
    WHILE Y.ID : ID
        
		R.SEARCH.TABLE = ""
        CALL F.READ(FN.SEARCH.TABLE, Y.ID, R.SEARCH.TABLE, F.SEARCH.TABLE, E.SEARCH.TABLE)

        FINDSTR W.SEARCH.TXT IN R.SEARCH.TABLE SETTING POS1,POS2 THEN
		    CRT Y.ID : " | " : POS1 : " | " : POS2 
		END

    REPEAT

    RETURN
