@ECHO OFF
rem installT24Pack

SET /A ARGS_COUNT=0    
FOR %%A in (%*) DO SET /A ARGS_COUNT+=1    

if %ARGS_COUNT%==1 GOTO PROCESS
echo One parameter required: pack name
GOTO EXIT0

:PROCESS
set USER=INPUTTER
set NOM_PAQUET=%1
REM set PACKAGE_DIR=C:\T24Dev\LeumiDev\T24\UD\LEUMI.PACKS
set PACKAGE_DIR=%~dp0..\..\T24\UD\LEUMI.PACKS
set PACKAGE_PATH=%PACKAGE_DIR%\%NOM_PAQUET%
set RESTORE_OK=1
set REINSTALL=
REM set CHANGELOG=C:\T24Dev\LeumiDev\T24\UD\LEUMI.PACKS\%NOM_PAQUET%.changelog
set CHANGELOG=%~dp0..\..\T24\UD\LEUMI.PACKS\%NOM_PAQUET%.changelog

IF EXIST %PACKAGE_PATH% GOTO CHECK.CHANGELOG 
echo missing pack %PACKAGE_PATH%
GOTO EXIT0

:CHECK.CHANGELOG 
IF EXIST %CHANGELOG% GOTO T24PACK.PROCESS
echo missing changelog file %CHANGELOG%
GOTO EXIT0

:T24PACK.PROCESS

:AVR1
set VARREC=0
for /f %%i in ('call tRun SEL.INSTALL.ACTION.EXEC %USER% AVR1 %PACKAGE_PATH%^|findstr /X "RETURN.CODE=1"') do (set VARREC=1)
IF %VARREC%==%RESTORE_OK% GOTO RESTORE1
echo "Failure during AVR1"
GOTO EXIT0

:RESTORE1
set VARREC=0
echo %NOM_PAQUET% action AVR1 done.
for /F %%i in ('call tRun PACK.MAN.LAUNCHER %USER% RESTORE1 %NOM_PAQUET% %REINSTALL%^|findstr /ir "Process.successfully"') do (set VARREC=1)
IF %VARREC%==%RESTORE_OK% GOTO R1R2
echo "Failure during RESTORE1 : error report by PACK.MAN - Please check &SAVEDLISTS& or &COMO&"
GOTO EXIT0

:R1R2
set VARREC=0
echo %NOM_PAQUET% RESTORE1 done
for /f %%i in ('call tRun SEL.INSTALL.ACTION.EXEC %USER% R1R2 %PACKAGE_PATH%^|findstr /X "RETURN.CODE=1"') do (set VARREC=1)
IF %VARREC%==%RESTORE_OK% GOTO RESTORE2
echo "Failure during R1R2"
GOTO EXIT0

:RESTORE2
set VARREC=0
echo %NOM_PAQUET% action R1R2 done.
for /f %%i in ('call tRun PACK.MAN.LAUNCHER %USER% RESTORE2 %NOM_PAQUET%^|findstr /ir "Process.successfully"') do (set VARREC=1)
IF %VARREC%==%RESTORE_OK% GOTO R2R3
echo "Failure during RESTORE2: error report by PACK.MAN - Please check &SAVEDLISTS& or &COMO&"
GOTO EXIT0

:R2R3
set VARREC=0
echo %NOM_PAQUET% RESTORE2 done
for /f %%i in ('call tRun SEL.INSTALL.ACTION.EXEC %USER% R2R3 %PACKAGE_PATH%^|findstr /X "RETURN.CODE=1"') do (set VARREC=1)
IF %VARREC%==%RESTORE_OK% GOTO RESTORE3
echo "Failure during R2R3"
GOTO EXIT0

:RESTORE3
set VARREC=0
echo %NOM_PAQUET% action R2R3 done.
for /f %%i in ('call tRun PACK.MAN.LAUNCHER %USER% RESTORE3 %NOM_PAQUET%^|findstr /ir "Process.successfully"') do (set VARREC=1)
IF %VARREC%==%RESTORE_OK% GOTO APR3
echo "Failure during RESTORE3: error report by PACK.MAN - Please check &SAVEDLISTS& or &COMO&"
GOTO EXIT0

:APR3
set VARREC=0
echo %NOM_PAQUET% RESTORE3 done
for /f %%i in ('call tRun SEL.INSTALL.ACTION.EXEC %USER% APR3 %PACKAGE_PATH%^|findstr /X "RETURN.CODE=1"') do (set VARREC=1)
IF %VARREC%==%RESTORE_OK% GOTO APR3DONE
echo "Failure during APR3"
GOTO EXIT0

:APR3DONE
echo %NOM_PAQUET% action APR3 done.

set errorlevel=1
EXIT /B %errorlevel%

:EXIT0
set errorlevel=2
EXIT /B %errorlevel%