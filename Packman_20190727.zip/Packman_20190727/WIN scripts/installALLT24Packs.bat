@ECHO OFF
rem installT24Pack

:PROCESS
REM set PACKAGE_DIR=C:\T24Dev\LeumiDev\T24\UD\LEUMI.PACKS\*
set PACKAGE_DIR=%~dp0..\..\T24\UD\LEUMI.PACKS\*
cd %PACKAGE_DIR%
for /D %%D in (TAF*) do call :installpack %%D
echo %%D
goto :EXITALL


:installpack
 if DEFINED filenameold del /f %filenameold%
 if DEFINED packnameold rmdir /s %packnameold%
 set packname=%1
 REM set filename=C:\T24Dev\LeumiDev\T24\UD\LEUMI.PACKS\%packname%.changelog
 set filename=%~dp0..\..\T24\UD\LEUMI.PACKS\%packname%.changelog
 START notepad++ "%filename%"
 call installT24Pack %packname% 
 pause 
 set filenameold=%filename%
REM set packnameold=C:\T24Dev\LeumiDev\T24\UD\LEUMI.PACKS\%packname%
 set packnameold=%~dp0..\..\T24\UD\LEUMI.PACKS\%packname%
 
 goto :EXITALL
  
:EXITALL



rem echo %%D
rem  set packname=%D
rem  set filename=C:\T24Dev\LeumiDev\T24\UD\LEUMI.PACKS\%packname%.changelog
rem  echo %filename%
rem  START "%filename%"
rem  pause
rem  installT24Pack %%D 
rem  echo "%errorlevel%"
rem  rem if "%errorlevel%" EQU "2" goto EXITALL
rem 
rem )
